"""End-to-end check: clicks through both guided stories (controller, then crew extension) in a real browser.

Serve the repo root first, e.g.  python3 -m http.server 8766
Then:  python demo/tests/e2e_story.py                      # desktop, built single file
       python demo/tests/e2e_story.py --mobile             # 390 x 844 phone viewport
       python demo/tests/e2e_story.py --url http://127.0.0.1:8766/demo/index.html   # dev version (needs npm install)
Prints every coach step, the final task states and any page errors; saves screenshots to --out.
Needs: pip install playwright && playwright install chromium
"""
import argparse, asyncio, os, sys, json
from playwright.async_api import async_playwright
ap = argparse.ArgumentParser()
ap.add_argument("--url", default="http://127.0.0.1:8766/SafetyWindow-v2.html")
ap.add_argument("--mobile", action="store_true")
ap.add_argument("--out", default="e2e-shots")
A = ap.parse_args()
OUT = A.out.rstrip("/") + "/"; os.makedirs(OUT, exist_ok=True)
ARGS=["--use-gl=angle","--use-angle=swiftshader","--enable-unsafe-swiftshader","--ignore-gpu-blocklist"]   # software WebGL for headless runs
MOBILE = A.mobile
URL = A.url
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(args=ARGS)
        vp = {"width":390,"height":844} if MOBILE else {"width":1440,"height":900}
        pg = await b.new_page(viewport=vp, device_scale_factor=2 if MOBILE else 1, is_mobile=MOBILE, has_touch=MOBILE)
        errs=[]
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append(m.text) if m.type=="error" else None)
        await pg.goto(URL)
        await pg.wait_for_timeout(2500)
        await pg.evaluate("window.__sw.speed = 2")
        async def coach():
            return await pg.evaluate("(()=>{const c=document.querySelector('#coach'); return c.hidden? null : c.querySelector('.step').textContent+' | '+c.querySelector('h4').textContent + ' | ' + (c.querySelector('[data-act=coach]')?.textContent||c.querySelector('.wait')?.textContent)})()")
        async def click(sel):
            el = await pg.query_selector(sel)
            box = await el.bounding_box()
            if MOBILE: await pg.tap(sel)
            else: await pg.mouse.click(box['x']+box['width']/2, box['y']+box['height']/2)
        shots = 0; pre = 'm' if MOBILE else 'd'
        last=None; same=0
        for step in range(60):
            c = await coach()
            t = await pg.evaluate("window.__sw.world.t")
            if c!=last: print(f"t={t:.1f} {c}"); last=c; same=0
            else: same+=1
            if same>20: print("STUCK"); break
            if c is None: break
            if 'Both stories complete' in c:
                await pg.screenshot(path=OUT+f"{pre}3-{shots:02d}.png"); shots+=1; break
            btn = await pg.query_selector("#coach [data-act=coach][data-arg='1']")
            if btn:
                await pg.screenshot(path=OUT+f"{pre}3-{shots:02d}.png"); shots+=1
                b2 = await pg.query_selector("#coach [data-act=coach][data-arg='2']")
                if b2 and 'Acknowledge' in (await b2.text_content()):
                    await click("#coach [data-act=coach][data-arg='2']")
                    await pg.wait_for_timeout(900)
                    if 'Restore' in c or (await coach()) == c:
                        await click("#coach [data-act=coach][data-arg='1']")
                else:
                    await click("#coach [data-act=coach][data-arg='1']")
                await pg.wait_for_timeout(1500)
            else:
                await pg.wait_for_timeout(2000)
        state = await pg.evaluate("JSON.stringify({story: window.__sw.storyName, tasks: Object.fromEntries(Object.entries(window.__sw.wf.tasks).map(([k,v])=>[k,v.state])), msgsToA: window.__sw.wf.messages.filter(m=>m.to==='A').map(m=>m.level)})")
        print(state)
        print("\n".join(errs[:20]) or "no errors")
        await b.close()
asyncio.run(main())
