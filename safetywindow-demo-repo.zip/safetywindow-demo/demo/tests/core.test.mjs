import { test } from 'node:test';
import assert from 'node:assert/strict';
import { PLAN, OPTIONS } from '../js/plan.js';
import { World } from '../js/sim/world.js';
import { Sensors } from '../js/core/sensors.js';
import { evaluate, SETS } from '../js/core/rules.js';
import { forecast } from '../js/core/forecast.js';
import { compareOptions } from '../js/core/options.js';
import { Workflow } from '../js/core/workflow.js';
import * as fs from 'node:fs';

function site(phase = 'packdown', opts = {}) {
  const w = new World(PLAN, { phase, ...opts }); const s = new Sensors();
  const run = (sec) => { for (let i = 0; i < Math.round(sec * 10); i++) { w.step(0.1); s.sample(w); } };
  return { w, s, run, obs: () => s.observe(w) };
}

test('each phase uses its own condition set', () => {
  assert.notDeepEqual(SETS.packdown.B, SETS.work.B);
  assert.notDeepEqual(SETS.install.B, SETS.packdown.B);
  assert.ok(SETS.packdown.B.includes('GAP') && !SETS.work.B.includes('GAP'));
  assert.ok(SETS.work.B.includes('IN_AREA') && !SETS.packdown.B.includes('IN_AREA'));
});

test('pack-down starts with every monitored condition met', () => {
  const S = site(); S.run(5);
  const ev = evaluate(S.obs(), PLAN);
  for (const p of Object.values(ev.people)) assert.equal(p.status, 'MET', p.id + ' ' + JSON.stringify(p.conditions.filter((c) => c.status !== 'MET')));
});

test('shadow vehicle repositioning: workers stand still, forecast flags the gap before it fails', () => {
  const S = site(); S.run(5);
  const xB = S.w.people.C.x;
  S.w.inject('tmaReposition'); S.run(3);
  const obs = S.obs();
  const ev = evaluate(obs, PLAN);
  assert.equal(ev.people.C.status, 'MET');
  const fc = forecast(obs, PLAN, { horizon: 30 });
  const gap = fc.issues.find((i) => i.kind === 'gap');
  assert.ok(gap, 'gap issue forecast');
  assert.ok(gap.inS > 5 && gap.inS < 30, 'fails inside the horizon: ' + gap.inS);
  assert.ok(gap.people.includes('C'));
  assert.equal(S.w.people.C.x, xB, 'C did not move');
  assert.ok(gap.assumptions.length >= 1 && gap.reason.includes('GPS'));
});

test('forecast never reads scripted future events (only the observation)', () => {
  const src = fs.readFileSync(new URL('../js/core/forecast.js', import.meta.url), 'utf8');
  assert.ok(!src.includes('/sim/') && !/new World|\bworld\b|traffic\./.test(src), 'forecast.js must not import the simulator');
  const S = site(); S.run(5);
  const obs = S.obs();
  const before = JSON.stringify(forecast(obs, PLAN, { horizon: 30 }).issues);
  S.w.inject('tmaReposition'); // happens in the world, but the observation was taken before
  assert.equal(JSON.stringify(forecast(obs, PLAN, { horizon: 30 }).issues), before);
});

test('options: keep-current vs handover use the same inputs; handover is feasible, keep is not', () => {
  const S = site(); S.run(5); S.w.inject('tmaReposition'); S.run(3);
  const obs = S.obs(); const ev = evaluate(obs, PLAN);
  const cmp = compareOptions(obs, PLAN, OPTIONS, ev, { horizon: 30 });
  assert.ok(cmp.keep.unmet.some((u) => u.id === 'GAP'));
  const h = cmp.options.find((o) => o.option.id === 'HANDOVER');
  assert.ok(h && h.feasible, JSON.stringify(h && h.after));
  assert.equal(h.fc.horizon, cmp.keep.horizon);
  assert.equal(h.fc.t, cmp.keep.t);
  assert.ok(h.ops.total > 0 && h.ops.people.includes('TMA'));
});

test('no feasible option -> supervisor must reassess (never forced)', () => {
  const S = site(); S.run(5); S.w.inject('tmaReposition'); S.run(3);
  const obs = S.obs(); const ev = evaluate(obs, PLAN);
  const broken = OPTIONS.map((o) => (o.id === 'HANDOVER' ? { ...o } : o));
  const plan2 = { ...PLAN, tma: { ...PLAN.tma, positions: { ...PLAN.tma.positions, T2: -60 } } }; // T2 too far for the restart point
  const cmp = compareOptions(obs, plan2, broken, ev, { horizon: 30 });
  assert.equal(cmp.options.find((o) => o.option.id === 'HANDOVER').feasible, false);
  assert.equal(cmp.reassess, true);
});

test('GPS dropout -> cannot confirm, and no forecast for the gap', () => {
  const S = site(); S.run(5); S.w.inject('gpsDropout'); S.run(3);
  const obs = S.obs(); const ev = evaluate(obs, PLAN);
  assert.equal(ev.people.B.status, 'UNKNOWN');
  assert.ok(ev.people.B.conditions.find((c) => c.id === 'GAP').detail.includes('GPS'));
  const fc = forecast(obs, PLAN, { horizon: 30 });
  assert.equal(fc.reliable, false);
  assert.ok(fc.unreliable.some((u) => u.kind === 'gap'));
});

test('traffic surge builds a real queue and the forecast sees it coming', () => {
  const S = site('work'); S.run(20); S.w.inject('trafficSurge');
  let flagged = null, failed = null;
  for (let k = 0; k < 120 && failed === null; k++) {
    S.run(2);
    const obs = S.obs(); const ev = evaluate(obs, PLAN);
    const q = ev.people.A.conditions.find((c) => c.id === 'QUEUE');
    if (q.status === 'NOT_MET') failed = obs.t;
    if (flagged === null && forecast(obs, PLAN, { horizon: 60 }).issues.some((i) => i.kind === 'queue')) flagged = obs.t;
  }
  assert.ok(failed !== null, 'queue passes the warned range');
  assert.ok(flagged !== null && flagged < failed, `forecast ${flagged} before failure ${failed}`);
  assert.ok(S.w.traffic.queue().lengthM > 50);
});

test('faster approach speeds cut the controller warning time', () => {
  const S = site('work'); S.run(40);
  assert.equal(evaluate(S.obs(), PLAN).people.A.conditions.find((c) => c.id === 'WARN_TIME').status, 'MET');
  S.w.inject('speedUp'); S.run(70);
  const c = evaluate(S.obs(), PLAN).people.A.conditions.find((x) => x.id === 'WARN_TIME');
  assert.equal(c.status, 'NOT_MET', c.detail);
});

test('plant entry: announced path conflicts with C before the plant moves', () => {
  const S = site('work'); S.run(5); S.w.inject('plantEntry'); S.run(2);
  const fc = forecast(S.obs(), PLAN, { horizon: 30 });
  const pl = fc.issues.find((i) => i.kind === 'plant');
  assert.ok(pl && pl.people.includes('C'), JSON.stringify(fc.issues));
});

test('workflow: forecast -> supervisor only; confirm -> role messages; ack does not resume; resume needs conditions + confirmations', () => {
  const S = site(); const sent = [];
  const wf = new Workflow(PLAN, OPTIONS, { send: (m) => sent.push(m) });
  const tick = () => { const obs = S.obs(); const ev = evaluate(obs, PLAN, { paused: wf.paused() }); const fc = forecast(obs, PLAN, { horizon: 30, paused: wf.paused() }); wf.update(obs, ev, fc, obs.t); return { obs, ev, fc }; };
  S.run(5); tick();
  S.w.inject('tmaReposition'); wf.noteEvent(S.w.t, 'reposition');
  S.run(3); tick(); S.run(0.5); tick();
  const inc = wf.open().find((i) => i.type === 'forecast');
  assert.ok(inc);
  assert.deepEqual([...new Set(sent.map((m) => m.to))], ['SUP'], 'forecast goes to the supervisor only');
  tick(); tick();
  assert.equal(sent.filter((m) => m.incidentId === inc.id).length, 1, 'no duplicate push');
  const cmds = wf.confirmOption(inc.id, 'HANDOVER', S.w.t);
  for (const c of cmds) S.w.order(c.who, c.action, c.arg);
  assert.ok(sent.some((m) => m.to === 'B') && sent.some((m) => m.to === 'C') && sent.some((m) => m.to === 'TMA'));
  assert.equal(wf.tasks.B.state, 'PAUSED');
  // acknowledgements alone never resume
  wf.ack('B', S.w.t); wf.ack('C', S.w.t);
  const rel = wf.ack('TMA', S.w.t);
  for (const c of rel.commands) S.w.order(c.who, c.action, c.arg);
  S.run(2); tick();
  assert.notEqual(wf.tasks.B.state, 'ACTIVE');
  assert.equal(wf.resume('B', S.obs(), S.w.t).ok, false);
  // let the TMA finish and the driver confirm
  for (let i = 0; i < 40; i++) { S.run(1); tick(); }
  assert.equal(wf.resume('B', S.obs(), S.w.t).ok, false, 'driver has not confirmed yet');
  S.w.driverInPosition(); S.run(1); tick();
  assert.equal(wf.tasks.B.state, 'READY', JSON.stringify(wf.tasks.B.check));
  const r = wf.resume('B', S.obs(), S.w.t);
  assert.ok(r.ok);
  for (const c of r.commands) S.w.order(c.who, c.action, c.arg);
  const r2 = wf.resume('C', S.obs(), S.w.t); assert.ok(r2.ok);
  for (const c of r2.commands) S.w.order(c.who, c.action, c.arg);
  S.run(20); const { ev } = tick();
  assert.equal(ev.people.B.status, 'MET');
  assert.equal(inc.status, 'resolved');
  const pr = wf.progress(inc);
  assert.ok(pr.detected <= pr.confirmed && pr.confirmed <= pr.acked && pr.acked <= pr.restored && pr.restored <= pr.resumed, JSON.stringify(pr));
  // finally: GPS dropout -> cannot confirm -> affected people + supervisor, immediately
  sent.length = 0;
  S.w.inject('gpsDropout'); wf.noteEvent(S.w.t, 'gps'); S.run(3); tick();
  assert.equal(wf.tasks.B.state, 'PAUSED');
  assert.ok(sent.some((m) => m.to === 'B' && m.level === 'stop') && sent.some((m) => m.to === 'SUP'));
  assert.ok(wf.open().some((i) => i.type === 'unknown'));
});

// ---- controller-first additions -------------------------------------------------------------
function runWf(S, wf, sec) {
  for (let i = 0; i < Math.round(sec * 10); i++) {
    S.w.step(0.1); S.s.sample(S.w);
    if (i % 5 === 4) { const o = S.obs(); const e = evaluate(o, PLAN, { paused: wf.paused() }); wf.update(o, e, forecast(o, PLAN, { horizon: 30, paused: wf.paused() }), o.t); }
  }
}

test('driver fails to stop: flagged before reaching A, only A (and the supervisor) told, no false flags before', () => {
  for (const seed of [11, 23, 37]) {
    const S = site('work', { seed }); const sent = [];
    const wf = new Workflow(PLAN, OPTIONS, { send: (m) => sent.push(m) });
    runWf(S, wf, 10);
    // normal STOP/SLOW traffic: nothing flagged
    assert.ok(!sent.some((m) => m.to === 'A' && m.level === 'stop'), 'no stop before the scenario');
    S.w.inject('failToStop');
    let flaggedAt = null, detail = null, fid = null, carId = null;
    for (let k = 0; k < 60 && flaggedAt === null; k++) {
      runWf(S, wf, 0.5);
      if (S.w.traffic.flagged != null) fid = S.w.traffic.flagged;
      const c = evaluate(S.obs(), PLAN).people.A.conditions.find((x) => x.id === 'VEH_STOP');
      if (c.status === 'NOT_MET') { flaggedAt = c.value; detail = c.detail; carId = c.carId; }
    }
    assert.equal(carId, fid, 'the car flagged is the one that does not stop (no false flags on compliant cars)');
    assert.ok(flaggedAt !== null && flaggedAt > 2.5, `seed ${seed}: flagged with ${flaggedAt} s to A (${detail})`);
    const toA = sent.filter((m) => m.to === 'A' && m.level === 'stop');
    assert.equal(toA.length, 1); assert.ok(toA[0].body.startsWith('STOP-3'));
    assert.ok(!sent.some((m) => ['B', 'C'].includes(m.to)), 'B and C are not told');
  }
});

test('camera moved to K2: A cannot resume until the supervisor checks the camera view', () => {
  const S = site('work', { seed: 11 });
  const wf = new Workflow(PLAN, OPTIONS, {});
  runWf(S, wf, 5); S.w.inject('speedUp');
  for (let k = 0; k < 80 && wf.tasks.A.state === 'ACTIVE'; k++) runWf(S, wf, 0.5);
  const inc = wf.open().find((i) => i.key === 'now:A');
  wf.confirmOption(inc.id, 'CAM_K2', S.w.t, S.obs()).forEach((c) => S.w.order('EQ', c.action, c.arg));
  wf.ack('A', S.w.t);
  runWf(S, wf, 25);
  assert.equal(S.w.equip.camera, 'K2');
  assert.notEqual(wf.tasks.A.state, 'READY');
  assert.ok(wf.canResume('A', S.obs()).missing.some((m) => /camera view/.test(m)));
  S.w.checkCamera(); runWf(S, wf, 3);
  assert.equal(wf.tasks.A.state, 'READY');
});

test('fatigue reminder goes to the supervisor only, and closes when a relief is arranged', () => {
  const S = site('work', { seed: 11 }); const sent = [];
  const wf = new Workflow(PLAN, OPTIONS, { send: (m) => sent.push(m) });
  runWf(S, wf, 30);
  const f = wf.find('notice:FATIGUE');
  assert.ok(f, 'reminder raised');
  const msgs = sent.filter((m) => m.incidentId === f.id);
  assert.deepEqual([...new Set(msgs.map((m) => m.to))], ['SUP']);
  S.w.arrangeRelief(); runWf(S, wf, 1);
  assert.ok(!wf.find('notice:FATIGUE'));
});
