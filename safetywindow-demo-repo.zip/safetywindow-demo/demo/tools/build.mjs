// Single-file build: dist/SafetyWindow-v2.html (double-click or host anywhere; no server needed).
import { build } from 'esbuild';
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
const root = new URL('../', import.meta.url);
const r = await build({
  entryPoints: [new URL('js/app.js', root).pathname], bundle: true, format: 'iife', minify: true, write: false, target: 'es2020',
  alias: { 'three/addons': new URL('node_modules/three/examples/jsm', root).pathname },
});
const js = r.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const css = readFileSync(new URL('css/app.css', root), 'utf8');
let html = readFileSync(new URL('index.html', root), 'utf8');
html = html.replace(/<link rel="stylesheet" href="css\/app.css">/, `<style>\n${css}\n</style>`);
html = html.replace(/<script type="importmap">[\s\S]*?<\/script>\n?/, '');
html = html.replace(/<script type="module" src="js\/app.js"><\/script>/, () => `<script>\n${js}\n</script>`);
mkdirSync(new URL('dist/', root), { recursive: true });
writeFileSync(new URL('dist/SafetyWindow-v2.html', root), html);
console.log(`dist/SafetyWindow-v2.html ${(html.length / 1024).toFixed(0)} KB`);
