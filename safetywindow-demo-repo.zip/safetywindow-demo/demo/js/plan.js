// Sample traffic management plan (TMP) for the demo site.
// EVERY number here is a demo parameter chosen for illustration. None of it has been reviewed by a road
// authority, and SafetyWindow never invents distances or rules outside this file: candidate adjustments,
// operating instructions, gap ranges and response times are all read from here.
//
// Coordinates: x runs along the road in the eastbound (EB) travel direction (metres), y across the road.
// Australia drives on the left, so the EB lanes are on +y: median lane y 0..3.5, kerb lane y 3.5..7.
// The westbound (WB) lane is y -3.5..0. The EB verge / footpath is y 7..11.

export const PLAN = {
  id: 'TMP-A',
  title: 'Sample plan TMP-A · kerb-lane closure, eastbound',
  disclaimer: 'Demo example only - not reviewed or approved by any road authority.',

  road: { xMin: -720, xMax: 260, laneW: 3.5, kerbY: 7, vergeY: 11, wbY: -3.5 },
  lanes: { median: 1.75, kerb: 5.25, wb: -1.75 },
  speedZone: { x: -90, kmh: 40 },          // work-zone speed limit applies downstream of x
  merge: { gateX: -50, shiftFrom: -95, headway: 3.2 }, // zipper merge; 3.2 s => ~1125 veh/h capacity
  taper: { x0: -80, x1: -35 },
  closure: { x0: -35, x1: 150 },            // lane-line cones along y = 3.5
  workArea: { x0: 20, x1: 125, y0: 3.7, y1: 6.9 },
  refuge: { x0: -30, x1: 140, y0: 7.6, y1: 10.2 },
  openLaneEdge: 3.5,                        // worker must stay at y >= edge + margin
  openLaneMargin: 0.3,

  // Equipment with pre-approved alternative positions (the only positions options may move them to)
  vms: { positions: { P1: -170, P2: -380 }, y: 9.5, leadM: 50 },       // queue tail must stay >= leadM past the VMS
  camera: { positions: { K1: -100, K2: -150 }, y: 9.0, sightM: 30 },   // upstream camera sees sightM beyond itself
  tma: { positions: { T1: 2, T2: -21 }, y: 5.25, L: 8, gap: [20, 60] }, // x = centre; gap from TMA front to worker
  resumeMarkerX: 35,                                                    // pack-down section S2 restart point
  plant: { gate: { x: 92, y: 13 }, path: [[92, 13], [86, 8.2], [72, 5.3], [44, 5.3]], speed: 2.2, clearance: 4, announceS: 12 },

  timing: { latency: 0.5, buffer: 1.0, responseS: { stand: 3.5, bend: 5.5 }, staleAfter: 2.0 },
  // stop/slow: when A shows STOP, cars that would need more than commitDecel to stop are let through (committed);
  // any other car that needs more than flagDecel to stop at the line but is not braking enough is flagged
  stopLine: { commitDecel: 3.0, flagDecel: 2.0, reactS: 1.0, minStopM: 60 },
  // sample fatigue plan: relief for the controller after 2 h on the bat; remind the supervisor 10 min before
  fatigue: { reliefAfterS: 7200, remindBeforeS: 600 },

  // Pre-configured operating instructions (demo wording)
  instructions: {
    'PD-3': 'PD-3 Handover: stop retrieving, step to the verge refuge, wait for "resume" at marker S2.',
    'PD-3D': 'PD-3 Handover (driver): continue to position T2, stop, arrow board on, then tap "In position".',
    'STOP-1': 'STOP-1: stop work and step to the verge refuge now.',
    'STOP-2': 'STOP-2: step back from the kerb and stop directing traffic until the warning time is restored.',
    'STOP-3': 'STOP-3: a car is not stopping for your STOP bat. Step back from the kerb now.',
    'PL-2': 'PL-2 Plant hold: plant stays at the gate until the supervisor releases it.',
    'PL-3': 'PL-3 Pause for plant: leave the plant path, wait at the refuge until the plant is parked.',
    'EQ-1': 'EQ-1 Relocate the VMS trailer to pre-approved position P2 and confirm the message is on.',
    'EQ-2': 'EQ-2: tow the camera trailer to pre-approved position K2. SafetyWindow confirms when it streams from K2.',
    'HOLD-A': 'HOLD-A: stay stepped back from the kerb while the camera is moved; wait for "resume".',
  },
};

// Which phase uses which condition set (see rules.js). Different phases deliberately use different rules.
export const PHASES = [
  { id: 'prestart', name: 'Pre-start', blurb: 'Load the plan; confirm crew, equipment and data are live.' },
  { id: 'install', name: 'Install', blurb: 'Signs, then shadow vehicle, then taper and lane cones.' },
  { id: 'work', name: 'Works', blurb: 'Monitor people, plant, approach speed and the queue.' },
  { id: 'adjust', name: 'Adjust', blurb: 'A change on site: forecast, compare options, confirm, notify, re-verify.' },
  { id: 'packdown', name: 'Pack-down', blurb: 'Retrieve cones in reverse order behind the shadow vehicle.' },
];

// Candidate adjustments. The system can only pick from this list.
export const OPTIONS = [
  {
    id: 'HANDOVER', title: 'Pause retrieval and complete the shadow-vehicle handover',
    for: ['gap', 'tma'], phases: ['packdown', 'install'],
    pause: ['B', 'C'], instructionFor: { B: 'PD-3', C: 'PD-3', TMA: 'PD-3D' },
    moves: ['Shadow vehicle: finish move to T2 (front at x -17 m)', 'Workers B, C: to verge refuge', 'Restart point: marker S2 (x 35 m)'],
    confirmations: ['Driver: "In position"', 'Supervisor: resume'],
    restore: ['tmaAtTarget', 'arrowOn', 'driverConfirmed', 'gapAtMarker'],
  },
  {
    id: 'VMS_P2', title: 'Move the VMS trailer to pre-approved position P2 (-380 m)',
    for: ['queue'], phases: ['work', 'packdown', 'install'],
    pause: [], instructionFor: { A: 'EQ-1' },
    moves: ['VMS trailer: P1 (-170 m) to P2 (-380 m)'],
    confirmations: ['Controller A: "VMS relocated"'],
    restore: ['queueWarned'],
  },
  {
    id: 'CAM_K2', title: 'Move the upstream camera to pre-approved position K2 (-150 m)',
    for: ['warning'], phases: ['work', 'packdown', 'install'],
    pause: ['A'], instructionFor: { A: 'HOLD-A', SUP: 'EQ-2' },
    moves: ['Camera trailer: K1 (-100 m) to K2 (-150 m), towed by the supervisor'],
    confirmations: ['Camera GPS at K2 and streaming', 'Supervisor: camera view checked (aim and calibration)', 'Supervisor: resume A'],
    restore: ['warningTime'],
  },
  {
    id: 'HOLD_PLANT', title: 'Hold the plant at the gate until C has left the plant path',
    for: ['plant'], phases: ['work', 'packdown'],
    pause: [], instructionFor: { PLANT: 'PL-2', A: 'PL-2' },
    moves: ['Plant: stays at the gate'],
    confirmations: ['Plant driver: "Holding"'],
    restore: ['plantClear'],
  },
  {
    id: 'PAUSE_C', title: "Pause C's task; C waits at the refuge while the plant enters",
    for: ['plant'], phases: ['work', 'packdown'],
    pause: ['C'], instructionFor: { C: 'PL-3', PLANT: 'PL-2' },
    moves: ['Worker C: to verge refuge', 'Plant: enters after C is clear'],
    confirmations: ['Worker C: "At refuge"', 'Supervisor: release plant'],
    restore: ['plantClear'],
  },
];

export const ROLES = {
  A: { name: 'A · Stop/slow traffic controller', short: 'Controller A' },
  B: { name: 'B · Cone operator', short: 'Worker B' },
  C: { name: 'C · Site worker', short: 'Worker C' },
  TMA: { name: 'Shadow-vehicle driver', short: 'TMA driver' },
  PLANT: { name: 'Plant driver', short: 'Plant driver' },
  SUP: { name: 'Supervisor', short: 'Supervisor' },
};
