// Guided stories. Every state change still comes from the simulation and rules; the coach only suggests the
// next action and waits for the system to reach the right state.
//   controller - the main story: A, the stop/slow traffic controller, when drivers speed up
//   crew       - the extension: the same loop protecting B and C while the shadow vehicle repositions

const helpers = (app) => ({
  inc: (type) => app.wf.open().find((i) => i.type === type),
  ready: (ids) => ids.every((id) => app.wf.tasks[id].state === 'READY'),
  active: (ids) => ids.every((id) => app.wf.tasks[id].state === 'ACTIVE'),
  acked: (roles) => { const i = app.focusIncident(); return i && roles.every((r) => i.recipients[r] && i.recipients[r].ackAt != null); },
  warn: () => { const c = app.ev && app.ev.people.A.conditions.find((x) => x.id === 'WARN_TIME'); return c && c.status !== 'UNKNOWN' && c.value != null ? c.value : null; },
  need: () => { const T = app.plan.timing; return T.responseS.stand + T.latency + T.buffer; },
});

export const STORY_NAMES = { controller: 'Stop/slow controller', crew: 'Extension · crew' };

export function makeControllerStory(app) {
  const h = helpers(app);
  const camAt = (pos) => { const g = app.obs && app.obs.src.equipGps; return g && g.camera === pos; };
  const warnTxt = () => { const v = h.warn(); return v == null ? 'cannot be confirmed' : `${v.toFixed(1)} s`; };
  const veh = () => app.ev && app.ev.people.A.conditions.find((x) => x.id === 'VEH_STOP');
  const vehInc = () => app.wf.open().find((i) => i.key === 'now:A' && (i.conds || []).includes('VEH_STOP'));
  const passed = () => app.world.events.some((e) => /ran the STOP/.test(e.text) && e.t >= (app._ftsAt || 0));
  return [
    { title: 'Meet A, the stop/slow traffic controller', text: `A stands at the work-zone entrance with the stop/slow bat, facing live traffic. Every 0.5 s SafetyWindow checks A's own conditions: does the camera layout give A enough warning time, can approaching cars stop at A's STOP, is A on the verge, is the queue inside the warned range. All are met. Workers B and C are 80 m further on (Top view shows everyone).`,
      cta: 'Drivers speed up (+30 km/h)', act: () => app.inject('speedUp'), hl: '[data-ev="speedUp"]' },
    { title: 'Approach speeds are rising', text: 'The upstream camera measures v85, the speed 85% of drivers stay under. The faster they come, the less warning A gets from this camera position. Meanwhile the supervisor (not A) gets a relief reminder: A has been on the bat for 1 h 50 min.',
      wait: 'Watching approach speeds', until: () => app.wf.tasks.A.state !== 'ACTIVE', hl: '#paneForecast' },
    { title: () => `Layout warning time ${warnTxt()} < ${h.need().toFixed(1)} s needed`, text: 'This fails now, so nobody waits for approval: SafetyWindow flags it in the same 0.5 s check and A\'s phone gets STOP-2, step back from the kerb (delivery time to a real phone is measured separately). Only A is told; B and C keep working.',
      cta: 'Compare options', act: () => app.openOptions('CAM_K2'), hl: '#right .card' },
    { title: 'Same inputs: keep vs move the camera', text: 'Keep current: the layout still gives A too little warning. CAM_K2 from the sample plan: move the camera trailer 50 m upstream so fast cars are seen earlier. The blue ghost shows K2.',
      cta: 'Supervisor: confirm CAM_K2', act: () => app.confirm(), hl: '#paneOptions', until: () => { const i = app.focusIncident(); return i && i.option; } },
    { title: 'One instruction per role', text: 'A: HOLD-A, stay stepped back while the camera moves. Supervisor: EQ-2, tow the camera trailer to K2. B and C get nothing. Acknowledging only records that A read it. It never restarts A.',
      cta: 'Open the phones', act: () => app.openPhones(), cta2: 'Acknowledge as A', act2: () => app.ack('A'), hl: '#btnPhones', until: () => h.acked(['A']) },
    { title: 'Acknowledged ≠ moved ≠ restored', text: 'Three separate records: A has read it; the trailer GPS must show K2; fresh speeds from K2 must show enough warning time. While the camera is offline A\'s warning time is "Cannot confirm", so A stays back.',
      wait: 'Camera trailer moving to K2 (offline while moving)', until: () => camAt('K2') },
    { title: 'Camera at K2: is it pointing the right way?', text: 'GPS says the trailer is at K2, but a moved camera also needs its view checked (aim and calibration) before its speeds count. The supervisor confirms.',
      cta: 'Supervisor: camera view checked', act: () => app.cameraChecked(), until: () => h.ready(['A']) },
    { title: () => `Restored: ${warnTxt()} available, ${h.need().toFixed(1)} s needed`, text: 'Warning time holds at A\'s position, A has acknowledged and the camera view is checked. Only now does the supervisor\'s Resume button unlock.',
      cta: 'Supervisor: resume A', act: () => app.resume('A'), hl: '.resume', until: () => h.active(['A']) },
    { title: 'Fatigue: the supervisor plans a relief', text: 'The sample fatigue plan relieves A after 2 h on the bat. SafetyWindow reminded the supervisor 10 min before, without interrupting A. No biometrics: it only counts time on the bat.',
      cta: 'Supervisor: relief arranged', act: () => app.reliefArranged(), hl: '#btnPhones', until: () => !app.wf.find('notice:FATIGUE') },
    { title: 'A shows STOP. The next driver will not stop', text: 'The radar on the VMS trailer tracks each approaching car. A car that should already be braking hard for A\'s STOP but is not gets flagged.',
      cta: 'Driver fails to stop', act: () => { app._ftsAt = app.world.t; app.inject('failToStop'); }, hl: '[data-ev="failToStop"]' },
    { title: 'Watching the approaching cars', text: 'Cars that were too close to stop when A showed STOP are let through. Everyone else must brake.', wait: 'Waiting for the next car', until: () => !!vehInc() || passed() },
    { title: () => { const c = veh(); return c && c.status === 'NOT_MET' ? `Car not stopping: ${c.value.toFixed(1)} s to A` : 'Car not stopping: A steps back'; }, text: 'STOP-3 goes straight to A: step back from the kerb now. Nothing to compare or approve. Detection can only start once a normal driver would already be braking, so at these speeds it comes about 4 s before the car reaches A. That is why taking A out of live traffic (portable lights) is the next step.',
      wait: 'Car approaching', until: passed },
    { title: 'Car gone: re-verify, then resume', text: 'The car ran the STOP; A had stepped back (see the timeline). Before A goes back to the kerb: A acknowledges, the radar shows no car failing to stop, and the supervisor resumes.',
      cta: 'Supervisor: resume A', act: () => app.resume('A'), cta2: 'Acknowledge as A', act2: () => app.ack('A'), hl: '.resume', until: () => h.active(['A']) },
    { title: 'Controller story complete', text: 'A was interrupted only when A had to act: once for the camera layout, once for a car that would not stop. The supervisor handled the rest: options, the camera check and the relief. Next, the same loop protects the crew.',
      cta: 'Next: crew extension', act: () => app.startStory('crew'), cta2: 'Free play', act2: () => app.setMode('free') },
  ];
}

export function makeCrewStory(app) {
  const h = helpers(app);
  const tmaAtT2 = () => { const g = app.obs && app.obs.src.tmaGps; return g && g.age < 2 && Math.abs(g.x - app.plan.tma.positions.T2) < 1.5 && Math.abs(g.v) < 0.05; };
  return [
    { title: 'Extension: pack-down in progress', text: 'B retrieves lane-line cones, C loads the cone truck, A controls traffic at the entrance. The shadow vehicle protects the crew at T1. Every monitored condition is met.',
      cta: 'Shadow vehicle starts repositioning', act: () => app.inject('tmaReposition'), hl: '[data-ev="tmaReposition"]' },
    { title: 'Watching the change', text: 'The shadow vehicle is moving. B and C have not moved. The forecast re-runs every 0.5 s from GPS and camera data…', wait: 'Waiting for the forecast', until: () => !!h.inc('forecast') },
    { title: () => `Forecast: C's protection gap leaves the plan range in ~${Math.round(h.inc('forecast') ? h.inc('forecast').inS : 0)} s`, text: 'Nothing has failed yet, so nobody on the road is interrupted - not even A. Only the supervisor is notified, with the reason and the assumptions. Next: compare the preset options.',
      cta: 'Compare options', act: () => app.openOptions('HANDOVER'), hl: '#paneForecast' },
    { title: 'Same traffic inputs, same horizon', text: 'Keep current: C\'s gap is not met inside the horizon. Handover (from the sample plan): no conflict, but 3 moves and 2 confirmations. The blue ghost shows T2 and the restart marker.',
      cta: 'Confirm the handover option', act: () => app.confirm(), hl: '#paneOptions', until: () => { const i = app.focusIncident(); return i && i.option; } },
    { title: 'Instructions sent by role', text: 'B and C: step to the refuge (PD-3). Driver: continue to T2 and confirm. Supervisor: list of pending items. A gets nothing - A\'s conditions are unaffected.',
      cta: 'Open the phones', act: () => app.openPhones(), cta2: 'Acknowledge as B, C and the driver', act2: () => { ['B', 'C', 'TMA'].forEach((r) => app.ack(r)); }, hl: '#btnPhones', until: () => h.acked(['B', 'C', 'TMA']) },
    { title: 'Re-verifying the new set-up', text: 'Acknowledged is not restored. The system checks the shadow vehicle\'s GPS position, that it has stopped, the arrow board and the driver\'s confirmation.', wait: 'Shadow vehicle moving to T2', until: tmaAtT2 },
    { title: 'Shadow vehicle stopped at T2', text: 'Position and stop are verified from GPS, but B and C stay paused: the driver has not confirmed "In position" yet.',
      cta: 'Driver: tap "In position"', act: () => app.driverInPosition(), until: () => h.ready(['B', 'C']) },
    { title: 'Conditions hold at restart marker S2', text: 'Gap, arrow board and driver confirmation are all in. Only now does the supervisor\'s Resume button unlock.',
      cta: 'Supervisor: resume B and C', act: () => { app.resume('B'); app.resume('C'); }, hl: '.resume', until: () => h.active(['B', 'C']) },
    { title: 'Last test: the GPS drops out', text: 'Protection now depends on data the system can no longer see.', cta: 'Cut the shadow-vehicle GPS', act: () => app.inject('gpsDropout'), hl: '[data-ev="gpsDropout"]' },
    { title: 'Cannot confirm', text: 'After 2 s without GPS, B and C are paused at once - no approval needed - and the forecast says it cannot predict the gap. Stale data is never treated as "normal".', wait: 'Waiting for the data to go stale', until: () => !!h.inc('unknown') },
    { title: 'Cannot confirm → paused', text: 'B and C were told to step off; the supervisor knows which data is stale. Nothing resumes until fresh data proves the conditions again and B and C have acknowledged.', cta: 'Restore the GPS', act: () => app.restore('tmaGps'), cta2: 'Acknowledge as B and C', act2: () => { app.ack('B'); app.ack('C'); }, until: () => h.ready(['B', 'C']) },
    { title: 'Data back and re-verified', text: 'Fresh GPS shows the gap is inside the plan range again. The supervisor resumes the tasks.', cta: 'Resume B and C', act: () => { app.resume('B'); app.resume('C'); }, until: () => h.active(['B', 'C']) },
    { title: 'Both stories complete', text: 'Now change the site yourself: raise traffic, speed up the approach, send the plant in, or drag people and equipment in Top view. Everything is re-checked by the same rules.',
      cta: 'Free play', act: () => app.setMode('free'), cta2: 'Replay the controller story', act2: () => app.startStory('controller') },
  ];
}

export const STORIES = { controller: makeControllerStory, crew: makeCrewStory };
