// 3D site view (three.js). Presentation only: it draws the simulated world and the decision state it is given.
// Road coordinates (x along the road, y across; EB lanes on +y) map to three.js as (x, height, -y).
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { CSS2DRenderer, CSS2DObject } from 'three/addons/renderers/CSS2DRenderer.js';

const P = (x, y, h = 0) => new THREE.Vector3(x, h, -y);
export const STATE_COLORS = { MET: '#2e9d5b', PREDICTED: '#e0a100', NOT_MET: '#e0442c', UNKNOWN: '#8a8f96', PAUSED: '#3b6fd8', READY: '#3b6fd8', NA: '#b8c0c8' };
const CAR_COLORS = ['#c8322a', '#2f5d9b', '#e8e8e8', '#3c3f44', '#8a9aa8', '#1f6f5c', '#c9a227', '#7b2d3b'];

const mat = (color, extra = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.8, metalness: 0.05, ...extra });
function flat(w, d, color, opacity = 1) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshBasicMaterial({ color, transparent: opacity < 1, opacity, depthWrite: opacity >= 1 }));
  m.rotation.x = -Math.PI / 2;
  return m;
}
function textTexture(lines, { w = 512, h = 256, bg = '#111', fg = '#ffb000', font = 'bold 60px sans-serif' } = {}) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d');
  g.fillStyle = bg; g.fillRect(0, 0, w, h);
  g.fillStyle = fg; g.font = font; g.textAlign = 'center'; g.textBaseline = 'middle';
  lines.forEach((ln, i) => g.fillText(ln, w / 2, (h / (lines.length + 1)) * (i + 1)));
  const tx = new THREE.CanvasTexture(c); tx.colorSpace = THREE.SRGBColorSpace; return tx;
}
function label(text, cls) { const d = document.createElement('div'); d.className = 'lbl ' + cls; d.textContent = text; return new CSS2DObject(d); }
function labelAt(text, cls, x, y, z) { const l = label(text, cls); l.position.set(x, y, z); return l; }
function rng(seed) { let a = seed; return () => { a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
function stripeTexture() {
  const c = document.createElement('canvas'); c.width = 128; c.height = 64; const g = c.getContext('2d');
  g.fillStyle = '#ffd400'; g.fillRect(0, 0, 128, 64); g.fillStyle = '#111';
  for (let i = -64; i < 128; i += 24) { g.beginPath(); g.moveTo(i, 64); g.lineTo(i + 12, 64); g.lineTo(i + 76, 0); g.lineTo(i + 64, 0); g.fill(); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
function arrowTexture() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 150; const g = c.getContext('2d');
  g.fillStyle = '#111'; g.fillRect(0, 0, 256, 150); g.fillStyle = '#ffb000';
  for (let i = 0; i < 5; i++) { g.beginPath(); g.arc(215 - i * 36, 75, 9, 0, Math.PI * 2); g.fill(); }
  g.beginPath(); g.moveTo(50, 40); g.lineTo(15, 75); g.lineTo(50, 110); g.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export class View3D {
  constructor(container, plan, cb = {}) {
    this.container = container; this.plan = plan; this.cb = cb;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#dbe6ee');
    this.scene.fog = new THREE.Fog('#dbe6ee', 320, 900);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    this.renderer.shadowMap.enabled = true;
    container.appendChild(this.renderer.domElement);
    this.labels = new CSS2DRenderer(); this.labels.domElement.className = 'labels-layer'; container.appendChild(this.labels.domElement);
    this.persp = new THREE.PerspectiveCamera(38, 1, 0.5, 3000);
    this.ortho = new THREE.OrthographicCamera(-100, 100, 50, -50, 0.1, 1000);
    this.camera = this.persp;
    this.controls = new OrbitControls(this.persp, this.renderer.domElement);
    this.controls.enableDamping = true; this.controls.maxPolarAngle = Math.PI * 0.46;
    this.orthoControls = new OrbitControls(this.ortho, this.renderer.domElement);
    Object.assign(this.orthoControls, { enableRotate: false, screenSpacePanning: true, enabled: false });
    this.orthoControls.mouseButtons = { LEFT: THREE.MOUSE.PAN, MIDDLE: THREE.MOUSE.DOLLY, RIGHT: THREE.MOUSE.PAN };
    this.scene.add(new THREE.HemisphereLight('#ffffff', '#6b7d5a', 1.15));
    const sun = new THREE.DirectionalLight('#fff4e0', 1.5);
    sun.position.set(-60, 140, 90); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
    Object.assign(sun.shadow.camera, { left: -160, right: 180, top: 80, bottom: -80, near: 10, far: 500 });
    this.scene.add(sun); this.scene.add(sun.target); sun.target.position.set(20, 0, 0);
    this.static = new THREE.Group(); this.dyn = new THREE.Group(); this.ghosts = new THREE.Group();
    this.scene.add(this.static, this.dyn, this.ghosts);
    this.cars = new Map(); this.people = new Map(); this.selected = null; this.view = 'work';
    this.raycaster = new THREE.Raycaster(); this.pointer = new THREE.Vector2();
    this._bindPointer();
    this._resize();
    new ResizeObserver(() => this._resize()).observe(container);
    this._build();
    this.setView('work');
  }

  // ------------------------------------------------------------------ static scene
  _build() {
    const L = this.plan, S = this.static;
    const { xMin, xMax } = L.road, len = xMax - xMin, cx = (xMin + xMax) / 2;
    const grass = flat(len + 400, 400, '#a3ba8e'); grass.position.set(cx, -0.03, 0); grass.receiveShadow = true; S.add(grass);
    const road = flat(len, 10.5, '#3b3f44'); road.position.copy(P(cx, 1.75, 0)); road.receiveShadow = true; S.add(road);
    const verge = flat(len, 4.2, '#b9b6ab'); verge.position.copy(P(cx, 9.1, 0.004)); verge.receiveShadow = true; S.add(verge);
    const vergeW = flat(len, 3, '#b9b6ab'); vergeW.position.copy(P(cx, -5, 0.004)); S.add(vergeW);
    const white = new THREE.MeshBasicMaterial({ color: '#f4f4f0' });
    const line = (x0, x1, y, w = 0.14) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(x1 - x0, w), white); m.rotation.x = -Math.PI / 2; m.position.copy(P((x0 + x1) / 2, y, 0.02)); S.add(m); };
    line(xMin, xMax, 7.0); line(xMin, xMax, -3.5);
    const yellow = new THREE.MeshBasicMaterial({ color: '#f2c230' });
    for (const dy of [-0.12, 0.12]) { const m = new THREE.Mesh(new THREE.PlaneGeometry(len, 0.1), yellow); m.rotation.x = -Math.PI / 2; m.position.copy(P(cx, dy, 0.02)); S.add(m); }
    for (let x = xMin; x < xMax; x += 12) line(x, x + 3, 3.5, 0.13);
    // zones: work area, refuge, open-lane keep-out margin
    const wa = L.workArea;
    const work = flat(wa.x1 - wa.x0, wa.y1 - wa.y0, '#ff8a3d', 0.22); work.position.copy(P((wa.x0 + wa.x1) / 2, (wa.y0 + wa.y1) / 2, 0.03)); S.add(work);
    const wl = label('WORK AREA (plan)', 'lbl-equip'); wl.position.copy(P(wa.x1 - 12, wa.y1 - 0.6, 0.3)); S.add(wl);
    const rf = L.refuge;
    const refuge = flat(rf.x1 - rf.x0, rf.y1 - rf.y0, '#2fb36b', 0.25); refuge.position.copy(P((rf.x0 + rf.x1) / 2, (rf.y0 + rf.y1) / 2, 0.035)); S.add(refuge);
    const rl = label('REFUGE', 'lbl-equip'); rl.position.copy(P(rf.x1 - 6, (rf.y0 + rf.y1) / 2, 0.3)); S.add(rl);
    const keep = flat(L.closure.x1 - L.taper.x1, 0.35, '#e0442c', 0.55); keep.position.copy(P((L.closure.x1 + L.taper.x1) / 2, 3.68, 0.04)); S.add(keep);
    // cones (instanced) and signs
    this.coneList = [];
    const coneGeo = new THREE.ConeGeometry(0.24, 0.8, 10); coneGeo.translate(0, 0.4, 0);
    this.coneMesh = new THREE.InstancedMesh(coneGeo, mat('#ff6a00'), 80); this.coneMesh.castShadow = true; S.add(this.coneMesh);
    this.signs = new THREE.Group(); S.add(this.signs);
    for (const [x, txt] of [[-300, ['ROAD', 'WORK', 'AHEAD']], [-150, ['LEFT LANE', 'CLOSED']]]) {
      const g = new THREE.Group();
      const post = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.2), mat('#777')); post.position.y = 1.1;
      const board = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.6), new THREE.MeshBasicMaterial({ map: textTexture(txt, { w: 256, h: 256, bg: '#ffb000', fg: '#111', font: 'bold 38px sans-serif' }), side: THREE.DoubleSide }));
      board.position.y = 2.6; board.rotation.set(0, -Math.PI / 2, Math.PI / 4);
      g.add(post, board); g.position.copy(P(x, 8.2)); this.signs.add(g);
    }
    // trees away from the road
    const r = rng(7);
    for (let i = 0; i < 110; i++) {
      const x = xMin + r() * len, y = r() < 0.5 ? -9 - r() * 40 : 14 + r() * 40;
      const t = new THREE.Group();
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.3, 2), mat('#6b4f35')); trunk.position.y = 1;
      const crown = new THREE.Mesh(new THREE.ConeGeometry(1.6 + r(), 4 + r() * 2, 8), mat('#4d7a45')); crown.position.y = 4; crown.castShadow = true;
      t.add(trunk, crown); t.position.copy(P(x, y)); S.add(t);
    }
    this.ticks = new THREE.Group(); S.add(this.ticks);
    for (let x = -220; x <= 140; x += 20) { const l = label(`${x} m`, 'lbl-tick'); l.position.copy(P(x, -6.5, 0.1)); this.ticks.add(l); }
    // equipment
    this.vms = this._vms(); this.dyn.add(this.vms);
    this.cam = this._cameraTrailer(); this.dyn.add(this.cam);
    this.cov = flat(1, 7, '#27b3e0', 0.22); this.dyn.add(this.cov);
    this.covLabel = label('camera view', 'lbl-cov'); this.dyn.add(this.covLabel);
    this.tma = this._truck('#f2f2f2', 8, 2.5, { attenuator: true, arrow: true });
    this.tma.add(labelAt('Shadow vehicle', 'lbl-equip', 0, 5, 0));
    this.tma.userData = { kind: 'TMA', drag: true };
    this.dyn.add(this.tma);
    this.rollAhead = flat(20, 3.3, '#e0442c', 0.3); this.dyn.add(this.rollAhead);
    this.rollLabel = label('roll-ahead · no-go', 'lbl-warn'); this.dyn.add(this.rollLabel);
    this.coneTruck = this._truck('#f08a24', 7, 2.4, { cones: true }); this.dyn.add(this.coneTruck);
    this.plant = this._plant(); this.plant.userData = { kind: 'PLANT', drag: true }; this.dyn.add(this.plant);
    this.plantPath = this._pathLine(L.plant.path, '#f2b705'); this.dyn.add(this.plantPath);
    this.queueLabel = label('', 'lbl-queue'); this.dyn.add(this.queueLabel);
    // A's STOP line at the merge gate (red while A shows STOP) and the tag on a car the radar says is not stopping
    this.stopLine = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 7), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.55, depthWrite: false }));
    this.stopLine.rotation.x = -Math.PI / 2; this.stopLine.position.copy(P(this.plan.merge.gateX, 3.5, 0.06)); this.dyn.add(this.stopLine);
    this.flagLabel = label('', 'lbl-warn'); this.flagLabel.visible = false; this.dyn.add(this.flagLabel);
    for (const id of ['A', 'B', 'C']) { const g = this._person(id); this.people.set(id, g); this.dyn.add(g); }
  }

  _vms() {
    const g = new THREE.Group();
    const t = new THREE.Mesh(new THREE.BoxGeometry(2.2, 0.6, 1.6), mat('#e8e8e8')); t.position.y = 0.5;
    const p = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 2.6), mat('#555')); p.position.y = 1.9;
    this.vmsBoardOn = textTexture(['QUEUE AHEAD', 'PREPARE TO STOP'], { w: 512, h: 272, font: 'bold 50px monospace' });
    this.vmsBoardOff = textTexture([''], { w: 64, h: 32, bg: '#222' });
    const b = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 1.7), new THREE.MeshBasicMaterial({ map: this.vmsBoardOn, side: THREE.DoubleSide }));
    b.position.set(0, 3.6, 0); b.rotation.y = -Math.PI / 2;
    g.add(t, p, b); g.userData = { kind: 'VMS', drag: true, board: b };
    g.add(labelAt('RPM VMS', 'lbl-equip', 0, 5.3, 0));
    return g;
  }
  _cameraTrailer() {
    const g = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.8, 1.6), mat('#f2f2f2')); body.position.y = 0.6; body.castShadow = true;
    const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 5.2), mat('#6d6d6d')); mast.position.y = 3.4;
    const head = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.35, 0.35), mat('#222')); head.position.set(-0.3, 6.0, 0);
    this.camLed = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 10), new THREE.MeshBasicMaterial({ color: '#22d36b' })); this.camLed.position.set(-0.3, 6.4, 0);
    g.add(body, mast, head, this.camLed);
    g.add(labelAt('RPM camera trailer', 'lbl-equip', 0, 7.2, 0));
    g.userData = { kind: 'CAMERA', drag: true };
    return g;
  }
  _truck(color, Lv, W, { attenuator = false, arrow = false, cones = false } = {}) {
    const g = new THREE.Group();
    const cab = new THREE.Mesh(new THREE.BoxGeometry(2.0, 2.3, W), mat(color)); cab.position.set(Lv / 2 - 1.0, 1.45, 0); cab.castShadow = true;
    const win = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.8, W * 0.85), mat('#1d2733', { metalness: 0.5 })); win.position.set(Lv / 2 + 0.01, 1.9, 0);
    const bed = new THREE.Mesh(new THREE.BoxGeometry(Lv - 2.2, 1.0, W), mat('#e9e9e4')); bed.position.set(-1.1, 0.9, 0); bed.castShadow = true;
    g.add(cab, win, bed);
    for (const [dx, dz] of [[Lv / 2 - 1.2, -W / 2], [Lv / 2 - 1.2, W / 2], [-Lv / 2 + 1.2, -W / 2], [-Lv / 2 + 1.2, W / 2]]) {
      const w = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.3, 14), mat('#111')); w.rotation.x = Math.PI / 2; w.position.set(dx, 0.45, dz); g.add(w);
    }
    if (attenuator) { const a = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.2, W * 0.95), new THREE.MeshStandardMaterial({ map: stripeTexture(), roughness: 0.7 })); a.position.set(-Lv / 2 - 1.1, 1.0, 0); a.castShadow = true; g.add(a); }
    if (arrow) { const b = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 1.3), new THREE.MeshBasicMaterial({ map: arrowTexture(), side: THREE.DoubleSide })); b.position.set(-Lv / 2 + 0.6, 3.1, 0); b.rotation.y = -Math.PI / 2; g.add(b); g.userData.arrow = b; }
    if (cones) for (let i = 0; i < 6; i++) { const c = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.75, 10), mat('#ff6a00')); c.position.set(-2.5 + i * 0.7, 1.8, i % 2 ? 0.4 : -0.4); g.add(c); }
    return g;
  }
  _plant() {
    const g = new THREE.Group();
    const cab = new THREE.Mesh(new THREE.BoxGeometry(2.2, 2.4, 2.5), mat('#f2b705')); cab.position.set(2.6, 1.6, 0); cab.castShadow = true;
    const tub = new THREE.Mesh(new THREE.BoxGeometry(4.6, 1.6, 2.5), mat('#d69d00')); tub.position.set(-1.0, 1.7, 0); tub.castShadow = true;
    g.add(cab, tub);
    for (const dx of [2.4, -0.6, -2.4]) for (const dz of [-1.25, 1.25]) { const w = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 0.5, 0.35, 14), mat('#111')); w.rotation.x = Math.PI / 2; w.position.set(dx, 0.5, dz); g.add(w); }
    g.add(labelAt('Plant (tipper)', 'lbl-equip', 0, 4.2, 0));
    return g;
  }
  _pathLine(path, color) {
    const pts = path.map(([x, y]) => P(x, y, 0.08));
    const geo = new THREE.BufferGeometry().setFromPoints(pts);
    const l = new THREE.Line(geo, new THREE.LineDashedMaterial({ color, dashSize: 1.2, gapSize: 0.8, linewidth: 2 }));
    l.computeLineDistances();
    return l;
  }
  _person(id) {
    const g = new THREE.Group();
    const vest = id === 'A' ? '#ffd21f' : '#ff7a00';
    const body = new THREE.Group();
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.3, 1.0, 12), mat(vest)); torso.position.y = 1.05; torso.castShadow = true;
    const legs = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.2, 0.6, 10), mat('#2b3a55')); legs.position.y = 0.3;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 16), mat('#e9c3a0')); head.position.y = 1.75;
    const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.23, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2), mat(id === 'A' ? '#ffffff' : '#ffd21f')); helmet.position.y = 1.8;
    const upper = new THREE.Group(); upper.add(torso, head, helmet);
    body.add(upper, legs);
    if (id === 'A') {
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.9), mat('#444')); pole.position.set(0.4, 1.0, 0);
      this.batTex = { STOP: textTexture(['STOP'], { w: 128, h: 128, bg: '#d0021b', fg: '#fff', font: 'bold 40px sans-serif' }), SLOW: textTexture(['SLOW'], { w: 128, h: 128, bg: '#f5c400', fg: '#1b2430', font: 'bold 40px sans-serif' }) };
      const disc = new THREE.Mesh(new THREE.CircleGeometry(0.35, 24), new THREE.MeshBasicMaterial({ map: this.batTex.SLOW, side: THREE.DoubleSide }));
      disc.position.set(0.4, 2.1, 0); disc.rotation.y = -Math.PI / 2; body.add(pole, disc); g.userData.disc = disc;
    }
    g.add(body);
    const ring = new THREE.Mesh(new THREE.RingGeometry(1.25, 1.55, 48), new THREE.MeshBasicMaterial({ color: STATE_COLORS.MET, transparent: true, opacity: 0.95, depthWrite: false }));
    ring.rotation.x = -Math.PI / 2; ring.position.y = 0.07;
    const disk = new THREE.Mesh(new THREE.CircleGeometry(1.25, 48), new THREE.MeshBasicMaterial({ color: STATE_COLORS.MET, transparent: true, opacity: 0.2, depthWrite: false }));
    disk.rotation.x = -Math.PI / 2; disk.position.y = 0.06;
    g.add(ring, disk);
    const l = label({ A: 'A · Controller', B: 'B · Cones', C: 'C · Site' }[id], 'lbl-person'); l.position.set(0, { A: 2.9, B: 2.7, C: 3.5 }[id], 0); g.add(l);
    g.userData = { ...g.userData, kind: id, drag: true, ring, disk, labelEl: l.element, upper };
    return g;
  }

  // ------------------------------------------------------------------ per-frame update
  update(world, display) {
    const L = this.plan;
    // cones
    const m = new THREE.Matrix4();
    let i = 0;
    for (const c of world.cones.taper) { m.makeTranslation(c.x, 0, -c.y); if (!c.placed) m.makeScale(0, 0, 0); this.coneMesh.setMatrixAt(i++, m); }
    for (const c of world.cones.lane) { m.makeTranslation(c.x, 0, -3.5); if (!c.placed) m.makeScale(0, 0, 0); this.coneMesh.setMatrixAt(i++, m); }
    this.coneMesh.count = i; this.coneMesh.instanceMatrix.needsUpdate = true;
    this.signs.visible = world.cones.signs;
    // equipment (interpolate while relocating)
    const eq = world.equip;
    const lerpPos = (k, key, list) => {
      const mv = eq.moving[k];
      if (!mv) return eq[key];
      const dur = k === 'vms' ? 20 : 15, u = 1 - Math.max(0, mv.until - world.t) / dur;
      return eq[key] + (list[mv.to] - eq[key]) * u;
    };
    const vx = lerpPos('vms', 'vmsX', L.vms.positions), cxp = lerpPos('camera', 'cameraX', L.camera.positions);
    this.vms.position.copy(P(vx, L.vms.y));
    this.vms.userData.board.material.map = eq.vmsOn ? this.vmsBoardOn : this.vmsBoardOff;
    this.cam.position.copy(P(cxp, L.camera.y));
    const camLive = world.sensors.upstreamCam && eq.cameraOn;
    this.camLed.material.color.set(camLive ? '#22d36b' : '#ff3b1f');
    this.cov.scale.x = L.camera.sightM; this.cov.position.copy(P(cxp - L.camera.sightM / 2, 1.75, 0.045));
    this.cov.material.color.set(camLive ? '#27b3e0' : '#6b7178'); this.cov.material.opacity = camLive ? 0.22 : 0.35;
    this.covLabel.position.copy(P(cxp - L.camera.sightM, -1.2, 0.3));
    this.covLabel.element.textContent = camLive ? `camera sees ${L.camera.sightM} m upstream` : 'CAMERA OFFLINE';
    this.covLabel.element.className = 'lbl ' + (camLive ? 'lbl-cov' : 'lbl-warn');
    // shadow vehicle + roll-ahead no-go zone
    const tm = world.tma;
    this.tma.position.copy(P(tm.x, tm.y));
    if (this.tma.userData.arrow) this.tma.userData.arrow.visible = tm.arrow && Math.floor(world.t * 2) % 2 === 0;
    const front = tm.x + tm.L / 2, inLane = Math.abs(tm.y - L.lanes.kerb) < 1.2;
    this.rollAhead.visible = this.rollLabel.visible = inLane;
    this.rollAhead.position.copy(P(front + L.tma.gap[0] / 2, L.lanes.kerb, 0.05)); this.rollAhead.scale.x = L.tma.gap[0] / 20;
    this.rollLabel.position.copy(P(front + L.tma.gap[0] / 2, 3.9, 0.4));
    this.coneTruck.position.copy(P(world.coneTruck.x, world.coneTruck.y));
    // plant
    const pl = world.plant;
    this.plant.position.copy(P(pl.x, pl.y)); this.plant.rotation.y = pl.heading;
    this.plantPath.visible = pl.state === 'requested' || pl.state === 'moving';
    // queue marker from the observation (what the radar reports)
    const q = display.queue;
    this.queueLabel.visible = !!(q && q.lengthM > 8);
    if (this.queueLabel.visible) { this.queueLabel.position.copy(P(q.tailX, 12.5, 0.5)); this.queueLabel.element.textContent = q.beyond ? 'queue tail beyond VMS' : `queue tail · ${Math.round(q.lengthM)} m`; }
    // traffic
    const seen = new Set();
    for (const v of world.traffic.all()) {
      seen.add(v.id);
      let g = this.cars.get(v.id);
      if (!g) { g = this._car(v); this.cars.set(v.id, g); this.dyn.add(g); }
      g.position.copy(P(v.x - (v.dir > 0 ? v.L / 2 : -v.L / 2), v.y));
      g.rotation.y = v.dir > 0 ? 0 : Math.PI;
    }
    for (const [id, g] of this.cars) if (!seen.has(id)) { this.dyn.remove(g); this.cars.delete(id); }
    const stop = display.signal === 'STOP';
    this.stopLine.material.color.set(stop ? '#e0442c' : '#ffffff'); this.stopLine.material.opacity = stop ? 0.9 : 0.35;
    const fl = display.flagged, fcar = fl && world.traffic.all().find((v) => v.id === fl.id);
    this.flagLabel.visible = !!fcar;
    if (fcar) { this.flagLabel.position.copy(P(fcar.x - fcar.L / 2, fcar.y, 3.2)); this.flagLabel.element.textContent = `not stopping · ${fl.tA.toFixed(1)} s to A`; }
    // people
    for (const [id, g] of this.people) {
      const p = world.people[id];
      g.position.copy(P(p.x, p.y));
      const st = display.people[id] || 'MET';
      const col = STATE_COLORS[st] || STATE_COLORS.MET;
      g.userData.ring.material.color.set(col); g.userData.disk.material.color.set(col);
      const urgent = st === 'NOT_MET';
      g.userData.ring.scale.setScalar(urgent ? 1 + 0.18 * Math.sin(performance.now() / 110) : 1);
      g.userData.labelEl.dataset.state = st;
      g.userData.labelEl.classList.toggle('sel', this.selected === id);
      const bending = p.posture === 'bend' && p.mode === 'work';
      g.userData.upper.rotation.z = bending ? 0.75 : 0;
      g.userData.upper.position.y = bending ? -0.25 : 0;
      g.visible = !p.inCab;
      if (g.userData.disc && this.batTex) g.userData.disc.material.map = this.batTex[display.signal === 'STOP' ? 'STOP' : 'SLOW'];
    }
  }

  _car(v) {
    const g = new THREE.Group();
    const color = v.truck ? '#d9d9d9' : CAR_COLORS[Math.floor(v.color * CAR_COLORS.length)];
    if (v.truck) {
      const cab = new THREE.Mesh(new THREE.BoxGeometry(2, 2.4, v.W), mat('#2f5d9b')); cab.position.set(v.L / 2 - 1, 1.5, 0);
      const box = new THREE.Mesh(new THREE.BoxGeometry(v.L - 2.2, 2.8, v.W), mat(color)); box.position.set(-1.1, 1.8, 0); box.castShadow = true;
      g.add(cab, box);
    } else {
      const body = new THREE.Mesh(new THREE.BoxGeometry(v.L, 0.75, v.W), mat(color, { metalness: 0.3, roughness: 0.5 })); body.position.y = 0.6; body.castShadow = true;
      const cabin = new THREE.Mesh(new THREE.BoxGeometry(v.L * 0.5, 0.6, v.W * 0.92), mat('#1d2733', { metalness: 0.5, roughness: 0.3 })); cabin.position.set(-v.L * 0.05, 1.2, 0);
      g.add(body, cabin);
    }
    return g;
  }

  // Semi-transparent preview of a candidate option
  setGhost(opt) {
    const id = opt ? opt.id : null;
    if (id === this._ghostId) return;
    this._ghostId = id;
    // nested CSS2D labels do not get the 'removed' event, so drop their DOM nodes by hand
    this.ghosts.traverse((o) => { if (o.isCSS2DObject && o.element.parentNode) o.element.parentNode.removeChild(o.element); });
    this.ghosts.clear();
    if (!opt) return;
    const L = this.plan;
    const ghostify = (obj) => { const lbls = []; obj.traverse((o) => { if (o.isCSS2DObject) lbls.push(o); }); lbls.forEach((l) => l.parent.remove(l)); obj.traverse((o) => { if (o.material && !o.isCSS2DObject) { o.material = o.material.clone(); o.material.transparent = true; o.material.opacity = 0.35; o.material.depthWrite = false; if (o.material.color) o.material.color.lerp(new THREE.Color('#3b6fd8'), 0.45); } }); return obj; };
    const tag = (obj, text, h) => { const l = label(text, 'lbl-ghost'); l.position.set(0, h, 0); obj.add(l); };
    if (opt.id === 'HANDOVER') {
      const t = ghostify(this._truck('#f2f2f2', 8, 2.5, { attenuator: true }));
      t.position.copy(P(L.tma.positions.T2, L.tma.y)); tag(t, 'T2 · proposed', 4.4); this.ghosts.add(t);
      for (const [id, x, y] of [['B', L.resumeMarkerX, 4.15], ['C', L.resumeMarkerX + 4, 6.3]]) {
        const mk = new THREE.Mesh(new THREE.RingGeometry(1.0, 1.4, 36), new THREE.MeshBasicMaterial({ color: '#3b6fd8', transparent: true, opacity: 0.8, depthWrite: false }));
        mk.rotation.x = -Math.PI / 2; mk.position.copy(P(x, y, 0.09)); this.ghosts.add(mk);
        const l = label(`${id} restart · S2`, 'lbl-ghost'); l.position.copy(P(x, y, 2.2)); this.ghosts.add(l);
      }
      const band = flat(L.tma.gap[1] - L.tma.gap[0], 3.3, '#3b6fd8', 0.12);
      band.position.copy(P(L.tma.positions.T2 + L.tma.L / 2 + (L.tma.gap[0] + L.tma.gap[1]) / 2, L.lanes.kerb, 0.055)); this.ghosts.add(band);
    }
    if (opt.id === 'VMS_P2') { const v = ghostify(this._vms()); v.position.copy(P(L.vms.positions.P2, L.vms.y)); tag(v, 'VMS at P2 · proposed', 6.3); this.ghosts.add(v); }
    if (opt.id === 'CAM_K2') {
      const c = ghostify(this._cameraTrailer()); c.position.copy(P(L.camera.positions.K2, L.camera.y)); tag(c, 'Camera at K2 · proposed', 8.2); this.ghosts.add(c);
      const cv = flat(L.camera.sightM, 7, '#3b6fd8', 0.18); cv.position.copy(P(L.camera.positions.K2 - L.camera.sightM / 2, 1.75, 0.05)); this.ghosts.add(cv);
    }
    if (opt.id === 'HOLD_PLANT') { const s = new THREE.Mesh(new THREE.RingGeometry(3, 3.6, 36), new THREE.MeshBasicMaterial({ color: '#3b6fd8', transparent: true, opacity: 0.8 })); s.rotation.x = -Math.PI / 2; s.position.copy(P(L.plant.gate.x, L.plant.gate.y, 0.1)); this.ghosts.add(s); const l = label('Plant holds at gate', 'lbl-ghost'); l.position.copy(P(L.plant.gate.x, L.plant.gate.y, 3)); this.ghosts.add(l); }
    if (opt.id === 'PAUSE_C') { const mk = new THREE.Mesh(new THREE.RingGeometry(1.0, 1.4, 36), new THREE.MeshBasicMaterial({ color: '#3b6fd8', transparent: true, opacity: 0.8 })); mk.rotation.x = -Math.PI / 2; mk.position.copy(P(46, 8.9, 0.09)); this.ghosts.add(mk); const l = label('C waits here', 'lbl-ghost'); l.position.copy(P(46, 8.9, 2.2)); this.ghosts.add(l); }
  }

  // ------------------------------------------------------------------ cameras & interaction
  setView(name) {
    this.view = name;
    if (name === 'top') {
      this.camera = this.ortho; this.controls.enabled = false; this.orthoControls.enabled = true;
      this.ortho.position.set(35, 200, -2); this.ortho.up.set(0, 0, -1); this.ortho.lookAt(35, 0, -2);
      this.orthoControls.target.set(35, 0, -2); this.ortho.zoom = 1; this.ortho.updateProjectionMatrix(); this.orthoControls.update();
    } else {
      this.camera = this.persp; this.controls.enabled = true; this.orthoControls.enabled = false;
      const narrow = (this.container.clientWidth || 800) < 600; // phones: step back so the whole work zone fits
      if (name === 'approach') { this.persp.position.set(narrow ? -380 : -330, narrow ? 95 : 70, narrow ? 170 : 120); this.controls.target.set(-120, 0, -6); }
      else {
        const fx = this.focusX ?? 24;
        if (fx < -50) { // controller area: entrance, camera trailer (K1 and K2) and the approach in one frame
          if (narrow) { this.persp.position.set(fx + 6, 84, 140); this.controls.target.set(fx + 6, 0, -3); } else { this.persp.position.set(fx - 6, 66, 118); this.controls.target.set(fx - 2, 0, 16); }
        } else if (narrow) { this.persp.position.set(fx - 1, 34, 60); this.controls.target.set(fx - 1, 0, -6); } else { this.persp.position.set(fx - 8, 34, 50); this.controls.target.set(fx, 0, -7); }
      }
      this.controls.update();
    }
    this.ticks.visible = name === 'top';
    this._resize();
  }
  setSelected(id) { this.selected = id; }
  setFocus(x) { this.focusX = x; }

  _resize() {
    const w = this.container.clientWidth || 800, h = this.container.clientHeight || 500;
    this.renderer.setSize(w, h, false);
    this.renderer.domElement.style.width = '100%'; this.renderer.domElement.style.height = '100%';
    this.labels.setSize(w, h);
    this.persp.aspect = w / h; this.persp.updateProjectionMatrix();
    const spanX = w < 600 ? 130 : 210, spanY = spanX * (h / w);
    Object.assign(this.ortho, { left: -spanX / 2, right: spanX / 2, top: spanY / 2, bottom: -spanY / 2 });
    this.ortho.updateProjectionMatrix();
  }

  _hit(e) {
    const el = this.renderer.domElement, r = el.getBoundingClientRect();
    this.pointer.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const targets = [...this.people.values(), this.tma, this.plant, this.vms, this.cam];
    const hit = this.raycaster.intersectObjects(targets, true)[0];
    if (!hit) return null;
    let o = hit.object; while (o && !(o.userData && o.userData.kind)) o = o.parent;
    return o;
  }
  _ground(e) {
    const el = this.renderer.domElement, r = el.getBoundingClientRect();
    this.pointer.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
    this.raycaster.setFromCamera(this.pointer, this.camera);
    const pt = new THREE.Vector3();
    return this.raycaster.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), pt) ? { x: pt.x, y: -pt.z } : null;
  }
  _bindPointer() {
    const el = this.renderer.domElement;
    el.addEventListener('pointerdown', (e) => {
      const o = this._hit(e);
      if (!o) return;
      if (this.cb.onPick) this.cb.onPick(o.userData.kind);
      if (this.view === 'top' && o.userData.drag && this.cb.canDrag && this.cb.canDrag(o.userData.kind)) {
        this.dragging = o.userData.kind; this.orthoControls.enabled = false; el.setPointerCapture(e.pointerId); e.preventDefault();
      }
    });
    el.addEventListener('pointermove', (e) => {
      if (!this.dragging) { if (this.view === 'top') { const o = this._hit(e); el.style.cursor = o && o.userData.drag ? 'grab' : ''; } return; }
      const g = this._ground(e);
      if (g && this.cb.onDrag) this.cb.onDrag(this.dragging, g.x, g.y);
    });
    const end = (e) => { if (this.dragging) { if (this.cb.onDragEnd) this.cb.onDragEnd(this.dragging); this.dragging = null; this.orthoControls.enabled = this.view === 'top'; try { el.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ } } };
    el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
  }

  render() {
    if (this.controls.enabled) this.controls.update();
    if (this.orthoControls.enabled) this.orthoControls.update();
    this.renderer.render(this.scene, this.camera);
    this.labels.render(this.scene, this.camera);
  }
}
