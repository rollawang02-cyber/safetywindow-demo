// Small forecast chart: observed history (solid) + forecast (dashed) on one axis, with the plan limit shaded.
// One unit per chart, <= 2 series, direct labels at the line ends, crosshair tooltip on hover.

const INK = '#3a4552', MUTED = '#8a939c', GRID = '#eef0f3';
export const SERIES_COLORS = ['#1f4e79', '#1f8a8a'];

export class ForecastChart {
  constructor(wrap) {
    this.wrap = wrap;
    this.canvas = document.createElement('canvas');
    this.tip = document.createElement('div'); this.tip.className = 'tip'; this.tip.hidden = true;
    wrap.append(this.canvas, this.tip);
    this.spec = null;
    this.canvas.addEventListener('mousemove', (e) => this._hover(e));
    this.canvas.addEventListener('mouseleave', () => { this.hoverX = null; this.tip.hidden = true; this.draw(this.spec); });
  }

  // spec: { unit, series:[{key,label}], history:[{t, v:{key:val}}], forecast:[{t, v:{key:val}}], now, lo, hi, limitLabel, yMin, yMax }
  draw(spec) {
    this.spec = spec;
    const c = this.canvas, dpr = Math.min(2, window.devicePixelRatio || 1);
    const W = this.wrap.clientWidth, H = this.wrap.clientHeight;
    if (!W || !H) return;
    c.width = W * dpr; c.height = H * dpr;
    const g = c.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
    if (!spec) return;
    const pad = { l: 34, r: 34, t: 8, b: 18 };
    const pts = [...spec.history, ...spec.forecast];
    const vals = pts.flatMap((p) => spec.series.map((s) => p.v[s.key])).filter((v) => v != null && isFinite(v));
    let y0 = spec.yMin ?? Math.min(0, ...vals, spec.lo ?? Infinity), y1 = spec.yMax ?? Math.max(...vals, spec.hi ?? -Infinity, (spec.lo ?? 0) * 1.3);
    if (!isFinite(y0)) y0 = 0; if (!isFinite(y1) || y1 <= y0) y1 = y0 + 10;
    y1 += (y1 - y0) * 0.08;
    const t0 = spec.now - 30, t1 = spec.now + spec.horizon;
    const X = (t) => pad.l + ((t - t0) / (t1 - t0)) * (W - pad.l - pad.r);
    const Y = (v) => H - pad.b - ((v - y0) / (y1 - y0)) * (H - pad.t - pad.b);
    this._geom = { X, Y, t0, t1, pad, W, H };
    // limit band / lines
    g.fillStyle = 'rgba(46,157,91,0.08)';
    const lo = spec.lo, hi = spec.hi;
    if (lo != null || hi != null) {
      const a = Y(hi != null ? Math.min(hi, y1) : y1), b = Y(lo != null ? Math.max(lo, y0) : y0);
      g.fillRect(pad.l, a, W - pad.l - pad.r, b - a);
    }
    g.strokeStyle = MUTED; g.setLineDash([4, 3]); g.lineWidth = 1;
    for (const v of [lo, hi]) if (v != null && v >= y0 && v <= y1) { g.beginPath(); g.moveTo(pad.l, Y(v)); g.lineTo(W - pad.r, Y(v)); g.stroke(); }
    g.setLineDash([]);
    // axes
    g.fillStyle = MUTED; g.font = '10px system-ui, sans-serif'; g.textAlign = 'right'; g.textBaseline = 'middle';
    const ticks = niceTicks(y0, y1, 4);
    for (const v of ticks) { g.strokeStyle = GRID; g.beginPath(); g.moveTo(pad.l, Y(v)); g.lineTo(W - pad.r, Y(v)); g.stroke(); g.fillText(`${v}`, pad.l - 5, Y(v)); }
    g.textAlign = 'center'; g.textBaseline = 'top';
    for (const dt of [-30, 0, spec.horizon / 2, spec.horizon]) g.fillText(dt === 0 ? 'now' : `${dt > 0 ? '+' : ''}${dt}s`, X(spec.now + dt), H - pad.b + 4);
    g.fillText(spec.unit, pad.l - 18, 0);
    // now line + forecast shading
    g.fillStyle = 'rgba(19,32,43,0.03)'; g.fillRect(X(spec.now), pad.t, X(t1) - X(spec.now), H - pad.t - pad.b);
    g.strokeStyle = '#c3cad1'; g.beginPath(); g.moveTo(X(spec.now), pad.t); g.lineTo(X(spec.now), H - pad.b); g.stroke();
    if (spec.limitLabel) { g.fillStyle = '#2e7d4f'; g.textAlign = 'left'; g.textBaseline = 'bottom'; g.fillText(spec.limitLabel, pad.l + 4, Y(hi != null ? Math.min(hi, y1) : lo) - 1); }
    // series
    spec.series.forEach((s, i) => {
      const col = SERIES_COLORS[i];
      g.strokeStyle = col; g.lineWidth = 2;
      const line = (arr, dash) => {
        g.setLineDash(dash); g.beginPath(); let on = false;
        for (const p of arr) { const v = p.v[s.key]; if (v == null || !isFinite(v) || p.t < t0) { on = false; continue; } const x = X(p.t), y = Y(Math.max(y0, Math.min(y1, v))); if (!on) { g.moveTo(x, y); on = true; } else g.lineTo(x, y); }
        g.stroke(); g.setLineDash([]);
      };
      line(spec.history, []);
      line([spec.history[spec.history.length - 1], ...spec.forecast].filter(Boolean), [5, 4]);
      // direct label at the forecast end
      const last = [...spec.forecast].reverse().find((p) => p.v[s.key] != null && isFinite(p.v[s.key]));
      if (last) { g.fillStyle = INK; g.font = '600 10.5px system-ui, sans-serif'; g.textAlign = 'left'; g.textBaseline = 'middle'; g.fillText(s.label, X(last.t) + 4, Y(Math.max(y0, Math.min(y1, last.v[s.key]))) + i * 2); }
    });
    // crosshair
    if (this.hoverX != null) {
      g.strokeStyle = '#9aa4ae'; g.beginPath(); g.moveTo(this.hoverX, pad.t); g.lineTo(this.hoverX, H - pad.b); g.stroke();
    }
  }

  _hover(e) {
    if (!this.spec || !this._geom) return;
    const r = this.canvas.getBoundingClientRect();
    const x = e.clientX - r.left;
    const { t0, t1, pad, W } = this._geom;
    const t = t0 + ((x - pad.l) / (W - pad.l - pad.r)) * (t1 - t0);
    const pts = [...this.spec.history, ...this.spec.forecast];
    if (!pts.length) return;
    const p = pts.reduce((a, b) => (Math.abs(b.t - t) < Math.abs(a.t - t) ? b : a));
    this.hoverX = this._geom.X(p.t);
    const rel = p.t - this.spec.now;
    const vals = this.spec.series.map((s) => `${s.label} ${p.v[s.key] == null || !isFinite(p.v[s.key]) ? '—' : Math.round(p.v[s.key] * 10) / 10}${this.spec.unit === 's' ? ' s' : ' m'}`).join(' · ');
    this.tip.textContent = `${rel >= 0 ? 'forecast +' : ''}${Math.round(rel)} s · ${vals}`;
    this.tip.style.left = `${this.hoverX}px`; this.tip.style.top = `${e.clientY - r.top}px`; this.tip.hidden = false;
    this.draw(this.spec);
  }
}

function niceTicks(a, b, n) {
  const span = b - a, step0 = span / n, mag = Math.pow(10, Math.floor(Math.log10(step0)));
  const step = [1, 2, 5, 10].map((m) => m * mag).find((s) => span / s <= n) || 10 * mag;
  const out = [];
  for (let v = Math.ceil(a / step) * step; v <= b + 1e-9; v += step) out.push(Math.round(v * 100) / 100);
  return out;
}
