// SafetyWindow v2 - site assurance lab. Wires simulation -> sensors -> rules -> forecast -> options -> workflow -> UI.
import { PLAN, PHASES, OPTIONS, ROLES } from './plan.js';
import { World } from './sim/world.js';
import { Sensors, SOURCE_NAMES } from './core/sensors.js';
import { evaluate, STATUS_LABEL } from './core/rules.js';
import { forecast } from './core/forecast.js';
import { compareOptions } from './core/options.js';
import { Workflow } from './core/workflow.js';
import { loadSettings, saveSettings, push } from './core/notify.js';
import { View3D } from './ui/view3d.js';
import { ForecastChart } from './ui/chart.js';
import { STORIES, STORY_NAMES } from './ui/story.js';

const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const fmt = (t) => (t == null ? '—' : `${Math.round(t)} s`);
const DT = 0.1, DECIDE = 0.5;
const SHORT = { VEH_STOP: 'car not stopping', GAP: 'gap out of range', BARRIER: 'roll-ahead gap', TMA_IN_LANE: 'shadow vehicle not in place', OUT_OF_LANE: 'in open-lane margin', ON_VERGE: 'off the verge', IN_AREA: 'outside work area', WARN_TIME: 'warning time short', QUEUE: 'queue beyond warning', PLANT_CLEAR: 'plant path conflict', ARROW: 'arrow board off', VMS_ON: 'no advance warning' };
const setHTML = (el, html) => { if (el._html !== html) { el._html = html; el.innerHTML = html; } };

const EVENTS = [
  { id: 'tmaReposition', icon: '🚚', name: 'Shadow vehicle repositions', desc: 'It starts moving to T2; the workers stay put', phases: ['packdown', 'work'] },
  { id: 'trafficSurge', icon: '🚗', name: 'Traffic surge', desc: 'Arrivals jump to 2400 veh/h; a queue builds at the merge', phases: ['work', 'packdown', 'install'] },
  { id: 'speedUp', icon: '⚡', name: 'Faster approach speeds', desc: 'Drivers want +30 km/h; warning time shrinks', phases: ['work', 'packdown', 'install'] },
  { id: 'plantEntry', icon: '🚜', name: 'Plant vehicle entry', desc: "Tipper announces entry across C's work area", phases: ['work', 'packdown'] },
  { id: 'gpsDropout', icon: '📡', name: 'Shadow-vehicle GPS dropout', desc: 'Positions stop updating', toggle: 'tmaGps', phases: ['packdown', 'install', 'work', 'prestart'] },
  { id: 'cameraDropout', icon: '📷', name: 'Upstream camera dropout', desc: 'Approach speeds stop updating', toggle: 'upstreamCam', phases: ['packdown', 'install', 'work', 'prestart'] },
  { id: 'failToStop', icon: '🛑', name: 'Driver fails to stop', desc: "A shows STOP; the next driver doesn't brake", phases: ['work'] },
];

class App {
  constructor() {
    this.plan = PLAN;
    this.horizon = 30; this.speed = 1; this.playing = true; this.mode = 'story';
    this.settings = loadSettings();
    this.mtab = 'status'; document.body.dataset.mtab = 'status';
    this.selected = 'B'; this.chartKind = null; this.focusId = null; this.optionId = null; this.preview = true;
    this.history = [];
    this.view = new View3D($('#stage'), PLAN, {
      onPick: (k) => { if (['A', 'B', 'C'].includes(k)) { this.selected = k; this.view.setSelected(k); this.renderRight(); } },
      canDrag: () => this.mode === 'free',
      onDrag: (k, x, y) => this.drag(k, x, y),
      onDragEnd: (k) => { const w = this.world, p = w.people[k]; const x = p ? p.x : k === 'TMA' ? w.tma.x : k === 'VMS' ? w.equip.vmsX : k === 'CAMERA' ? w.equip.cameraX : w.plant.x; w.log(`${ROLES[k] ? ROLES[k].short : k === 'VMS' ? 'VMS trailer' : k === 'CAMERA' ? 'Camera trailer' : k === 'PLANT' ? 'Plant' : k} moved by drag to x ${Math.round(x)} m`, 'drag'); },
    });
    this.chart = new ForecastChart(document.createElement('div'));
    this.bind();
    this.startStory('controller');
    this.last = performance.now(); this.acc = 0; this.decAcc = 0;
    requestAnimationFrame((t) => this.frame(t));
    window.__sw = this;
  }

  // ---------------------------------------------------------------- lifecycle
  reset(phase) {
    this.world = new World(PLAN, { phase, flowVph: 800, speedKmh: 60 });
    this.sensors = new Sensors();
    this.wf = new Workflow(PLAN, OPTIONS, { send: (m) => this.onSend(m) });
    this.history = []; this.focusId = null; this.optionId = null; this.cmp = null; this.view.setGhost(null);
    this.logSeen = 0;
    this.view.setFocus(phase === 'prestart' ? -140 : phase === 'install' ? -95 : 24); if (this.view.view === 'work') this.view.setView('work');
    for (let i = 0; i < 5; i++) { this.world.step(DT); this.sensors.sample(this.world); }
    this.decide();
    this.renderAll();
  }
  frame(now) {
    const dt = Math.min(0.25, (now - this.last) / 1000); this.last = now;
    if (this.playing) {
      this.acc += dt * this.speed;
      while (this.acc >= DT) {
        this.acc -= DT;
        this.world.step(DT); this.sensors.sample(this.world);
        this.decAcc += DT;
        if (this.decAcc >= DECIDE - 1e-9) { this.decAcc = 0; this.decide(); }
      }
    }
    this.view.update(this.world, this.display());
    this.view.render();
    if (now - (this.uiAt || 0) > 250) { this.uiAt = now; this.renderAll(); }
    requestAnimationFrame((t) => this.frame(t));
  }

  decide() {
    const w = this.world;
    // judge events enter the timeline as "occurred" (for the progress panel only - the logic never reads them)
    for (const e of w.events.slice(this.logSeen)) if (e.kind === 'event') this.wf.noteEvent(e.t, e.text);
    this.logSeen = w.events.length;
    this.obs = this.sensors.observe(w);
    const paused = this.wf.paused();
    this.ev = evaluate(this.obs, PLAN, { paused });
    this.fc = forecast(this.obs, PLAN, { horizon: this.horizon, paused });
    const nInc = this.wf.incidents.length;
    this.wf.update(this.obs, this.ev, this.fc, this.obs.t);
    const fresh = this.wf.incidents.slice(nInc).find((i) => i.people && i.people.length);
    if (fresh) { this.selected = fresh.people[0]; this.view.setSelected(this.selected); }
    this.record();
    // options for the incident in focus (recomputed with the same observation + horizon for every option)
    const inc = this.focusIncident();
    if (inc && !inc.option && (inc.type === 'forecast' || inc.type === 'current' || inc.type === 'unknown')) {
      this.cmp = compareOptions(this.obs, PLAN, OPTIONS, this.ev, { horizon: this.horizon, paused });
      const ids = this.cmp.options.map((o) => o.option.id);
      if (!ids.includes(this.optionId)) this.optionId = ids[0] || null;
    } else if (!inc) this.cmp = null;
    this.view.setGhost(this.preview && this.cmp && inc && !inc.option ? OPTIONS.find((o) => o.id === this.optionId) : null);
    // guided story auto-advance
    const st = this.story && this.story[this.storyStep];
    if (this.mode === 'story' && st && st.until && st.until()) { this.storyStep++; this.renderCoach(); }
    else if (this.mode === 'story' && st && st.wait) this.renderCoach();
  }

  record() {
    const o = this.obs, S = o.src, t = o.t;
    const g = (pid) => { const c = this.ev.people[pid].conditions.find((x) => x.id === 'GAP' || x.id === 'BARRIER'); return c && c.value != null && c.status !== 'UNKNOWN' ? c.value : null; };
    const q = this.ev.people.A.conditions.find((x) => x.id === 'QUEUE');
    const wt = this.ev.people.A.conditions.find((x) => x.id === 'WARN_TIME');
    const pd = (pid) => { const pl = S.plantApp, me = S.workerCam && S.workerCam.people[pid]; return pl && me && pl.state === 'moving' ? Math.hypot(pl.x - me.x, pl.y - me.y) : null; };
    this.history.push({ t, v: { gapB: g('B'), gapC: g('C'), queue: q && q.status !== 'UNKNOWN' ? q.value : null, warnA: wt && wt.status !== 'UNKNOWN' ? wt.value : null, plantB: pd('B'), plantC: pd('C') } });
    this.history = this.history.filter((h) => t - h.t <= 32);
  }

  // ---------------------------------------------------------------- actions
  inject(id) {
    const ev = EVENTS.find((e) => e.id === id);
    if (ev && ev.toggle && !this.world.sensors[ev.toggle]) { this.restore(ev.toggle); return; }
    this.world.inject(id);
    this.decide(); this.renderAll();
  }
  restore(key) { this.world.restoreSensor(key); this.renderAll(); }
  drag(kind, x, y) {
    const w = this.world, L = PLAN;
    if (kind === 'VMS') { w.equip.vmsX = Math.max(-600, Math.min(L.merge.gateX - 20, x)); w.equip.vms = 'custom'; }
    else if (kind === 'CAMERA') { w.equip.cameraX = Math.max(-400, Math.min(L.merge.gateX, x)); w.equip.camera = 'custom'; }
    else w.place(kind, x, Math.max(-8, Math.min(12, y)));
    this.sensors.nextAt = {}; this.sensors.sample(w); this.decide();
  }
  focusIncident() {
    const open = this.wf.open().filter((i) => ['forecast', 'current', 'unknown'].includes(i.type) || i.option);
    let inc = open.find((i) => i.id === this.focusId);
    if (!inc) {
      // prefer an incident still waiting for a decision, then one being executed
      inc = open.find((i) => !i.option && i.type === 'forecast') || open.find((i) => !i.option) || open.find((i) => i.option) || null;
      this.focusId = inc ? inc.id : null;
    }
    return inc;
  }
  isMobile() { return window.matchMedia('(max-width: 760px)').matches; }
  setTab(tab) {
    this.mtab = tab; document.body.dataset.mtab = tab;
    document.querySelectorAll('#tabbar button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
    if (tab === 'forecast') { const p = $('#paneForecast'); p._html = null; this.renderForecast(); }
    this.renderAll();
  }
  openOptions(id) { this.preview = true; if (id) this.optionId = id; this.decide(); if (this.isMobile()) this.setTab('options'); this.renderAll(); if (!this.isMobile()) $('#paneOptions').scrollIntoView({ block: 'nearest' }); }
  confirm() {
    const inc = this.focusIncident();
    if (!inc || !this.optionId) return;
    const cmds = this.wf.confirmOption(inc.id, this.optionId, this.world.t, this.obs);
    this.exec(cmds);
    this.view.setGhost(null);
    this.decide(); this.renderAll();
  }
  exec(cmds) {
    for (const c of cmds) {
      if (c.action === 'tmaTo') this.world.order('TMA', 'tmaTo', c.arg);
      else if (['moveVms', 'moveCamera', 'plantHold', 'plantRelease'].includes(c.action)) this.world.order('EQ', c.action, c.arg);
      else this.world.order(c.who, c.action, c.arg);
    }
  }
  ack(role) { const r = this.wf.ack(role, this.world.t); this.exec(r.commands); this.decide(); this.renderAll(); }
  driverInPosition() { this.world.driverInPosition(); this.decide(); this.renderAll(); }
  cameraChecked() { this.world.checkCamera(); this.decide(); this.renderAll(); }
  reliefArranged() { this.world.arrangeRelief(); this.decide(); this.renderAll(); }
  resume(pid) {
    const r = this.wf.resume(pid, this.obs, this.world.t);
    if (r.ok) this.exec(r.commands);
    this.decide(); this.renderAll();
    return r;
  }
  releasePlant() { this.world.order('EQ', 'plantRelease'); this.world.log('Supervisor releases the plant', 'confirm'); }
  openPhones() { if (this.isMobile()) { this.setTab('phones'); return; } $('#phones').hidden = false; this.renderPhones(); }
  setMode(m) {
    this.mode = m;
    document.querySelectorAll('#modeSeg button').forEach((b) => b.classList.toggle('on', b.dataset.mode === m));
    if (m === 'story') { this.startStory(this.storyName || 'controller'); return; }
    this.renderCoach(); this.renderAll();
  }
  // start a guided story from its own phase and camera framing
  startStory(name) {
    this.storyName = name; this.story = STORIES[name](this); this.storyStep = 0; this.mode = 'story';
    document.querySelectorAll('#modeSeg button').forEach((b) => b.classList.toggle('on', b.dataset.mode === 'story'));
    document.querySelectorAll('#viewSeg button').forEach((b) => b.classList.toggle('on', b.dataset.view === 'work'));
    $('#dragTip').hidden = true; $('#phones').hidden = true;
    const ctl = name === 'controller';
    this.reset(ctl ? 'work' : 'packdown');
    this.selected = ctl ? 'A' : 'B'; this.view.setSelected(this.selected);
    this.chartKind = ctl ? 'warning' : null;
    this.view.setFocus(ctl ? -96 : 24); this.view.setView('work');
    if (this.isMobile()) this.setTab('status');
    this.renderCoach(); this.renderAll();
  }
  onSend(m) {
    m.via = this.settings.enabled ? 'ntfy: sending…' : 'Simulated notification';
    if (m.level === 'stop' && ['A', 'B', 'C'].includes(m.to) && m.to !== 'A') this.world.order(m.to, 'refuge');
    if (m.level === 'stop' && m.to === 'A' && m.body.startsWith('STOP-3')) this.world.order('A', 'stepBack'); // a car is not stopping: A steps back from the kerb
    if (this.settings.enabled) {
      const body = m.body + (m.needsAck ? ' (Acknowledge in the SafetyWindow app.)' : '');
      push(this.settings, m.to, { title: `SafetyWindow: ${m.title}`, message: body, priority: m.level === 'stop' || m.level === 'escalate' ? 5 : 4, tags: m.level === 'stop' ? 'rotating_light' : 'warning' })
        .then((r) => { m.via = r.ok ? `sent via ntfy (${r.ms} ms)` : r.skipped ? 'Simulated notification' : `ntfy failed${r.status ? ' ' + r.status : ''} - shown in app`; });
    }
  }

  // ---------------------------------------------------------------- display state
  displayState(pid) {
    const task = this.wf.tasks[pid];
    if (task.state === 'READY') return 'READY';
    if (task.state === 'PAUSED') return 'PAUSED';
    const p = this.ev.people[pid];
    if (!p.conditions.length || p.status === 'NA') return 'NA';
    if (p.status === 'NOT_MET' || p.status === 'UNKNOWN') return p.status;
    if (this.fc.issues.some((i) => i.people.includes(pid))) return 'PREDICTED';
    return 'MET';
  }
  display() {
    const rd = this.obs && this.obs.src.vmsRadar;
    return {
      people: Object.fromEntries(['A', 'B', 'C'].map((k) => [k, this.displayState(k)])),
      queue: rd && rd.age < 3 ? { tailX: rd.beyondVms ? rd.x - 10 : rd.queueTailX, lengthM: rd.queueLengthM, beyond: rd.beyondVms } : null,
      flagged: (() => { const c = this.ev && this.ev.people.A.conditions.find((x) => x.id === 'VEH_STOP'); return c && c.status === 'NOT_MET' ? { id: c.carId, tA: c.value } : null; })(),
      signal: this.world.traffic.signal,
    };
  }

  // ---------------------------------------------------------------- binding
  bind() {
    $('#modeSeg').onclick = (e) => { const b = e.target.closest('button'); if (b) this.setMode(b.dataset.mode); };
    $('#viewSeg').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; document.querySelectorAll('#viewSeg button').forEach((x) => x.classList.toggle('on', x === b)); this.view.setView(b.dataset.view); $('#dragTip').hidden = !(b.dataset.view === 'top' && this.mode === 'free'); };
    $('#speedSeg').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; this.speed = +b.dataset.s; document.querySelectorAll('#speedSeg button').forEach((x) => x.classList.toggle('on', x === b)); };
    $('#horizonSeg').onclick = (e) => { const b = e.target.closest('button'); if (!b) return; this.horizon = +b.dataset.h; document.querySelectorAll('#horizonSeg button').forEach((x) => x.classList.toggle('on', x === b)); this.decide(); this.renderAll(); };
    $('#btnPlay').onclick = () => this.togglePlay();
    $('#tabbar').onclick = (e) => { const b = e.target.closest('button'); if (b) this.setTab(b.dataset.tab); };
    window.matchMedia('(max-width: 760px)').addEventListener('change', () => { this.view.setView(this.view.view); this.renderAll(); });
    $('#btnReset').onclick = () => { if (this.mode === 'story') { this.startStory(this.storyName); return; } this.reset(this.world.phase); };
    $('#btnPhones').onclick = () => { const d = $('#phones'); d.hidden = !d.hidden; this.renderPhones(); };
    $('#flow').oninput = (e) => { this.world.setFlow(+e.target.value); this.renderLeft(); };
    $('#speed').oninput = (e) => { this.world.setSpeed(+e.target.value); this.renderLeft(); };
    window.addEventListener('keydown', (e) => {
      if (e.target.tagName === 'INPUT') return;
      if (e.key === ' ') { e.preventDefault(); this.togglePlay(); }
    });
    // settings
    const dlg = $('#dlgSettings');
    $('#btnSettings').onclick = () => { $('#setEnabled').checked = this.settings.enabled; $('#setServer').value = this.settings.server; $('#setPrefix').value = this.settings.prefix; $('#topicList').textContent = ['SUP', 'A', 'B', 'C', 'TMA', 'PLANT'].map((r) => `${this.settings.prefix}-${r}`).join(', '); dlg.showModal(); };
    dlg.addEventListener('click', (e) => { if (e.target.dataset.close !== undefined || e.target === dlg) dlg.close(); });
    const save = () => { this.settings.enabled = $('#setEnabled').checked; this.settings.server = $('#setServer').value.trim() || 'https://ntfy.sh'; this.settings.prefix = $('#setPrefix').value.trim() || this.settings.prefix; this.settings.bound = { A: true, B: true, C: true, SUP: true, TMA: true, PLANT: true }; saveSettings(this.settings); $('#topicList').textContent = ['SUP', 'A', 'B', 'C', 'TMA', 'PLANT'].map((r) => `${this.settings.prefix}-${r}`).join(', '); };
    ['#setEnabled', '#setServer', '#setPrefix'].forEach((s) => $(s).addEventListener('change', save));
    $('#btnTest').onclick = async () => { save(); const r = await push({ ...this.settings, enabled: true }, 'SUP', { title: 'SafetyWindow test', message: 'Supervisor topic works.' }); $('#testResult').textContent = r.ok ? `delivered to ntfy (${r.ms} ms)` : `failed ${r.status || r.error || ''}`; };
    // delegated clicks
    // act on pointerdown: panels re-render several times a second, and a click could land on a replaced node
    const handler = (e) => {
      if (e.type === 'pointerdown' && e.button !== 0) return;
      if (e.type === 'click' && e.detail !== 0) return; // mouse clicks were handled on pointerdown; keyboard clicks come here
      const a = e.target.closest('[data-act]');
      if (!a || a.disabled) return;
      const { act, arg } = a.dataset;
      if (act === 'phase') this.goPhase(arg);
      if (act === 'event') this.inject(arg);
      if (act === 'select') { this.selected = arg; this.view.setSelected(arg); }
      if (act === 'resume') this.resume(arg);
      if (act === 'focus') { this.focusId = +arg; this.decide(); }
      if (act === 'option') { this.optionId = arg; this.preview = true; this.decide(); }
      if (act === 'preview') { this.preview = !this.preview; this.decide(); }
      if (act === 'confirm') this.confirm();
      if (act === 'ack') this.ack(arg);
      if (act === 'inpos') this.driverInPosition();
      if (act === 'camcheck') this.cameraChecked();
      if (act === 'relief') this.reliefArranged();
      if (act === 'release') this.releasePlant();
      if (act === 'checkin') { this.world.checkins[arg] = true; this.world.log(`${ROLES[arg].short} checked in`, 'confirm'); this.decide(); }
      if (act === 'startInstall') this.goPhase('install');
      if (act === 'skipWorks') this.goPhase('work');
      if (act === 'closePhones') $('#phones').hidden = true;
      if (act === 'chart') { this.chartKind = arg; }
      if (act === 'coach') { const story = this.story, st = story[this.storyStep]; (arg === '2' ? st.act2 : st.act)(); if (!st.until && this.story === story && this.mode === 'story') this.storyStep++; this.renderCoach(); }
      if (act === 'coachSkip') { this.setMode('free'); }
      if (act === 'topview') { document.querySelectorAll('#viewSeg button').forEach((x) => x.classList.toggle('on', x.dataset.view === 'top')); this.view.setView('top'); $('#dragTip').hidden = this.mode !== 'free'; }
      this.renderAll();
    };
    document.body.addEventListener('pointerdown', handler);
    document.body.addEventListener('click', handler);
  }
  togglePlay() { this.playing = !this.playing; $('#btnPlay').textContent = this.playing ? '❚❚' : '▶'; }
  goPhase(id) {
    if (id === 'adjust') return;
    if (this.mode === 'story') { this.mode = 'free'; document.querySelectorAll('#modeSeg button').forEach((b) => b.classList.toggle('on', b.dataset.mode === 'free')); this.renderCoach(); }
    this.reset(id);
  }

  // ---------------------------------------------------------------- rendering
  renderAll() { this.renderLeft(); this.renderRight(); this.renderForecast(); this.renderOptions(); this.renderProgress(); if (!$('#phones').hidden || (this.isMobile() && this.mtab === 'phones')) this.renderPhones(); this.renderTop(); }

  renderTop() {
    $('#clock').textContent = `t ${this.world.t.toFixed(0)} s`;
    const n = this.wf.messages.filter((m) => m.needsAck && !m.ackAt).length;
    $('#phoneBadge').hidden = !n; $('#phoneBadge').textContent = n;
    $('#tabBadge').hidden = !n; $('#tabBadge').textContent = n;
    // controller framing leaves B and C off-screen: say where they are and how they are doing
    const off = this.view.view === 'work' && (this.view.focusX ?? 24) < -50;
    $('#offHint').hidden = !off;
    if (off) { const L = { MET: 'Met', PREDICTED: 'Adjust likely', NOT_MET: 'Not met', UNKNOWN: 'Cannot confirm', PAUSED: 'Paused', READY: 'Ready', NA: 'Not exposed' }; $('#offHintSt').textContent = `80 m ahead · B ${L[this.displayState('B')]} · C ${L[this.displayState('C')]}`; }
  }

  renderCoach() {
    const c = $('#coach');
    document.querySelectorAll('.pulse').forEach((e) => e.classList.remove('pulse'));
    const st = this.mode === 'story' && this.story && this.story[this.storyStep];
    if (!st) { c.hidden = true; return; }
    c.hidden = false;
    const title = typeof st.title === 'function' ? st.title() : st.title;
    const acts = st.cta ? `<button class="btn primary" data-act="coach" data-arg="1">${esc(st.cta)}</button>${st.cta2 ? `<button class="btn small" data-act="coach" data-arg="2">${esc(st.cta2)}</button>` : ''}` : `<span class="wait">${esc((typeof st.wait === 'function' ? st.wait() : st.wait) || 'Waiting…')}</span>`;
    c.innerHTML = `<div class="step">Guided story · ${esc(STORY_NAMES[this.storyName] || '')} · step ${this.storyStep + 1} of ${this.story.length}</div><h4>${esc(title)}</h4><p>${esc(st.text)}</p><div class="acts">${acts}<button class="skip" data-act="coachSkip">Skip to free play</button></div>`;
    if (st.hl) document.querySelectorAll(st.hl).forEach((e) => e.classList.add('pulse'));
  }

  renderLeft() {
    const w = this.world, adjust = this.wf.open().some((i) => i.option || i.type === 'forecast');
    setHTML($('#phases'), PHASES.map((p, i) => {
      const on = p.id === w.phase;
      const cls = p.id === 'adjust' ? `auto${adjust ? ' live' : ''}` : on ? 'on' : '';
      return `<li class="${cls}" data-act="phase" data-arg="${p.id}" title="${esc(p.blurb)}"><span class="n">${i + 1}</span>${esc(p.name)}${p.id === 'adjust' ? `<small>${adjust ? 'active' : 'on change'}</small>` : ''}</li>`;
    }).join(''));
    $('#phaseBlurb').textContent = PHASES.find((p) => p.id === (adjust ? 'adjust' : w.phase)).blurb;
    let extra = '';
    if (w.phase === 'prestart' && this.ev.site) {
      extra = `<ul class="check">${this.ev.site.conditions.map((c) => `<li><i class="dot ${c.status}"></i><span><b>${esc(c.name)}</b><br><span class="fine">${esc(c.detail)}</span></span></li>`).join('')}</ul>
        <div class="row" style="flex-wrap:wrap;justify-content:flex-start">${['A', 'B', 'C'].filter((k) => !w.checkins[k]).map((k) => `<button class="btn small" data-act="checkin" data-arg="${k}">Check in ${k}</button>`).join('')}</div>
        <button class="btn primary" style="margin-top:8px;width:100%" data-act="startInstall" ${this.ev.site.status === 'MET' ? '' : 'disabled'}>Start install</button>`;
    }
    if (w.phase === 'install' && w.install) extra = `<p class="fine">Install step: <b>${esc({ signs: '1/4 advance signs & VMS', tma: '2/4 shadow vehicle into position', taper: '3/4 taper cones', lane: '4/4 lane-line cones', done: 'complete' }[w.install.step])}</b></p><button class="btn small" data-act="skipWorks">Go to works</button>`;
    if (w.phase === 'packdown') extra = `<p class="fine">${w.cones.lane.filter((c) => c.placed).length} lane-line cones left · retrieval moves upstream</p>`;
    setHTML($('#phaseExtra'), extra);
    const evHtml = EVENTS.map((e) => {
      const off = e.toggle && !w.sensors[e.toggle];
      const ok = e.phases.includes(w.phase);
      return `<button class="ev${off ? ' active' : ''}" data-act="event" data-arg="${e.id}" data-ev="${e.id}" title="${esc(e.desc)}" ${ok ? '' : 'disabled'}><span class="i">${e.icon}</span><b>${off ? `Restore ${esc(e.name.replace(' dropout', ''))}` : esc(e.name)}</b><span>${off ? 'Currently offline' : esc(e.desc)}</span></button>`;
    }).join('');
    if ($('#events')._html !== evHtml) { setHTML($('#events'), evHtml); if (this.mode === 'story') this.renderCoach(); }
    $('#flow').value = w.traffic.flowVph; $('#flowOut').textContent = `${w.traffic.flowVph} veh/h`;
    $('#speed').value = w.traffic.speedKmh; $('#speedOut').textContent = `${w.traffic.speedKmh} km/h`;
  }

  renderRight() {
    const ev = this.ev, wf = this.wf;
    const cards = ['A', 'B', 'C'].map((pid) => {
      const st = this.displayState(pid);
      const lbl = { MET: 'Met', PREDICTED: 'Adjust likely', NOT_MET: 'Not met', UNKNOWN: 'Cannot confirm', PAUSED: 'Paused', READY: 'Ready', NA: 'Not exposed' }[st];
      return `<button class="pcard${this.selected === pid ? ' sel' : ''}" data-act="select" data-arg="${pid}"><b>${esc(ROLES[pid].short)}</b><small>${esc(ev.people[pid].task.label)}</small><span class="chip ${st}">${esc(lbl)}</span></button>`;
    }).join('');
    const pid = this.selected, p = ev.people[pid], task = wf.tasks[pid], st = this.displayState(pid);
    const issue = this.fc.issues.find((i) => i.people.includes(pid));
    const bad = p.conditions.filter((c) => c.status === 'NOT_MET' || c.status === 'UNKNOWN');
    let why;
    if (task.state !== 'ACTIVE') { const inc = wf.incidents.find((i) => i.id === task.incident); why = `<b>Paused</b> ${inc ? `by “${esc(inc.title)}”` : ''}. ${inc ? esc(inc.reason) : ''}`; }
    else if (bad.length) why = `<b>${esc(STATUS_LABEL[p.status])}:</b> ${bad.map((c) => `${esc(c.name)} - ${esc(c.detail)}`).join('; ')}`;
    else if (issue) why = `<b>Adjustment likely needed:</b> ${esc(issue.reason)}`;
    else if (!p.conditions.length) why = 'No lane exposure in this phase - the crew is on the verge.';
    else if (p.status === 'NA') why = 'Not exposed right now.';
    else why = `All ${p.conditions.length} monitored conditions for this task are met. Re-checked every ${DECIDE} s.`;
    let resume = '';
    if (task.state !== 'ACTIVE') {
      const chk = task.check || { ok: false, missing: ['checking…'] };
      resume = `<div class="resume card" style="padding:10px"><b>Supervisor · resume ${pid}</b>${chk.ok ? '<p class="fine">Conditions hold at the restart position and the confirmations are in.</p>' : `<ul>${chk.missing.slice(0, 5).map((m) => `<li>${esc(m)}</li>`).join('')}</ul>`}<button class="btn blue small" data-act="resume" data-arg="${pid}" ${chk.ok ? '' : 'disabled'}>Resume ${esc(ROLES[pid].short)}</button></div>`;
    }
    const lbl = st === 'PAUSED' ? 'Paused' : st === 'READY' ? 'Ready to resume' : STATUS_LABEL[st];
    void lbl;
    const conds = p.conditions.length ? `<ul class="conds">${p.conditions.map((c) => `<li class="${c.status}"><i class="dot ${c.status}"></i><span>${esc(c.name)}</span><span class="d">${esc(c.detail)}</span></li>`).join('')}</ul>` : '<p class="fine">No lane conditions in this phase.</p>';
    const incs = wf.open().filter((i) => i.type !== 'notice' || i.key.startsWith('notice:'));
    const incHtml = incs.length ? incs.map((i) => `<div class="card inc"><h4><span class="tag ${i.type}">${{ forecast: 'FORECAST', current: 'NOT MET', unknown: 'CANNOT CONFIRM', notice: 'NOTICE' }[i.type]}</span>${esc(i.title)}</h4><div class="meta">detected ${fmt(i.detectedAt)}${i.people.length ? ` · affects ${i.people.map((x) => ROLES[x].short).join(', ')}` : ''}${i.option ? ` · option: ${esc(i.option.id)}` : ''}</div><div class="fine">${esc(i.reason)}</div>${i.type !== 'notice' ? `<button class="btn small" style="margin-top:6px" data-act="focus" data-arg="${i.id}">${i.option ? 'Show progress' : 'Compare options'}</button>` : ''}</div>`).join('') : '';
    const mleg = `<div class="mlegend"><span><i class="dot MET"></i>Met</span><span><i class="dot PREDICTED"></i>Adjust likely</span><span><i class="dot NOT_MET"></i>Not met</span><span><i class="dot UNKNOWN"></i>Cannot confirm</span><span><i class="dot PAUSED"></i>Paused</span></div>`;
    setHTML($('#right'), `${mleg}<div class="people">${cards}</div>
      <section class="card"><h3>${esc(ROLES[pid].name)} <span class="chip ${st}">${esc(lbl)}</span></h3><div class="task">Task: ${esc(p.task.label)}${task.state !== 'ACTIVE' ? ' · <b>paused</b>' : ''}${pid === 'A' && this.world.phase === 'work' ? ` · bat shows <b>${this.world.traffic.signal}</b>${p.task.onBatS != null ? ` · on the bat ${Math.floor(p.task.onBatS / 3600)} h ${Math.floor((p.task.onBatS % 3600) / 60)} min (relief by ${PLAN.fatigue.reliefAfterS / 3600} h, sample plan)` : ''}` : ''}</div><div class="why">${why}</div>${conds}${resume}</section>
      ${incHtml ? `<h3 style="margin:2px 2px -4px">Open items</h3>${incHtml}` : ''}`);
  }

  renderForecast() {
    const fc = this.fc, h = this.horizon;
    const kinds = { gap: 'Protection gap', queue: 'Queue tail', warning: 'Warning time', plant: 'Plant distance' };
    const phase = this.world.phase;
    const auto = fc.issues[0] ? fc.issues[0].kind : phase === 'work' ? 'queue' : 'gap';
    const kind = this.chartKind && kinds[this.chartKind] ? this.chartKind : (kinds[auto] ? auto : 'gap');
    const seg = `<div class="seg small">${Object.entries(kinds).map(([k, n]) => `<button data-act="chart" data-arg="${k}" class="${k === kind ? 'on' : ''}">${n}</button>`).join('')}</div>`;
    const pane = $('#paneForecast');
    if (!pane.dataset.built) {
      pane.innerHTML = `<h3><span>Forecast · next <span id="fcH"></span> s <span class="hint">demo parameter</span></span><span id="fcRel"></span></h3><div id="fcSeg"></div><div class="chartwrap" id="fcChart"></div><div class="body" id="fcBody"></div>`;
      this.chart = new ForecastChart($('#fcChart')); pane.dataset.built = '1';
    }
    $('#fcH').textContent = h;
    setHTML($('#fcRel'), fc.reliable ? '<span class="hint">inputs current</span>' : '<span class="chip UNKNOWN">cannot reliably forecast</span>');
    setHTML($('#fcSeg'), seg);
    // chart data
    const now = this.obs.t;
    let spec;
    const hist = (keys) => this.history.map((x) => ({ t: x.t, v: Object.fromEntries(keys.map(([k, src]) => [k, x.v[src]])) }));
    const fut = (fn) => fc.series.filter((s) => s.tau > 0).map((s) => ({ t: now + s.tau, v: fn(s) }));
    if (kind === 'gap') spec = { unit: 'm', series: [{ key: 'B', label: 'B' }, { key: 'C', label: 'C' }], history: hist([['B', 'gapB'], ['C', 'gapC']]), forecast: fc.reliable || !fc.unreliable.some((u) => u.kind === 'gap') ? fut((s) => ({ B: s.gap.B, C: s.gap.C })) : [], lo: PLAN.tma.gap[0], hi: phase === 'work' ? null : PLAN.tma.gap[1], limitLabel: phase === 'work' ? `min ${PLAN.tma.gap[0]} m` : `plan range ${PLAN.tma.gap[0]}–${PLAN.tma.gap[1]} m`, yMin: 0 };
    if (kind === 'queue') spec = { unit: 'm', series: [{ key: 'q', label: 'tail past VMS' }], history: hist([['q', 'queue']]), forecast: fut((s) => ({ q: s.tailPastVms })), lo: PLAN.vms.leadM, hi: null, limitLabel: `≥ ${PLAN.vms.leadM} m past the VMS` };
    if (kind === 'warning') spec = { unit: 's', series: [{ key: 'a', label: 'A available' }], history: hist([['a', 'warnA']]), forecast: [], lo: PLAN.timing.responseS.stand + PLAN.timing.latency + PLAN.timing.buffer, hi: null, limitLabel: 'needed', yMin: 0 };
    if (kind === 'plant') spec = { unit: 'm', series: [{ key: 'B', label: 'B' }, { key: 'C', label: 'C' }], history: hist([['B', 'plantB'], ['C', 'plantC']]), forecast: fut((s) => s.plantDist || {}), lo: PLAN.plant.clearance, hi: null, limitLabel: `keep ≥ ${PLAN.plant.clearance} m`, yMin: 0, yMax: 60 };
    spec.now = now; spec.horizon = h;
    this.chart.draw(spec);
    const issue = fc.issues.find((i) => i.kind === kind) || fc.issues[0];
    const unrel = fc.unreliable.filter((u) => ['gap', 'queue', 'plant', 'warning'].includes(u.kind));
    const body = (unrel.length ? `<div class="unrel"><b>Cannot reliably forecast</b> ${unrel.map((u) => `${u.kind} (${u.sources.map((s) => SOURCE_NAMES[s]).join(', ')} not current)`).join('; ')}.</div>` : '')
      + (issue ? `<p class="reason"><span class="chip PREDICTED">Adjustment likely needed</span> ${esc(issue.reason)}</p><details><summary>Main assumptions</summary><ul>${issue.assumptions.map((a) => `<li>${esc(a)}</li>`).join('')}</ul></details>`
        : kind === 'warning' ? (() => { const c = this.ev.people.A.conditions.find((x) => x.id === 'WARN_TIME'); return `<p class="reason">Warning time is checked on current measured speeds, not forecast. ${c ? `Controller A now: ${c.status === 'UNKNOWN' ? '<b>cannot confirm</b> (speed data not current)' : `<b>${esc(c.detail)}</b>`}.` : ''}</p>`; })()
        : `<p class="reason">No monitored condition is forecast to fail in the next ${h} s.</p>`);
    setHTML($('#fcBody'), body);
  }

  renderOptions() {
    const inc = this.focusIncident();
    let html = '<h3>Options <span class="hint">pre-configured in the sample plan</span></h3>';
    if (!inc) html += '<div class="empty">No change needs a decision.<br>Use “Change the site” to create one.</div>';
    else if (inc.option) {
      const o = inc.option, pend = [];
      for (const [r, v] of Object.entries(inc.recipients)) if (r !== 'SUP' && !v.ackAt) pend.push(`${ROLES[r].short}: acknowledge`);
      if (o.id === 'HANDOVER' && !this.obs.confirmations.driverInPosition) pend.push('Driver: “In position”');
      if (o.id === 'CAM_K2') pend.push(this.world.equip.camera !== 'K2' ? 'Camera trailer: reach K2 and stream' : !this.world.cameraChecked ? 'Supervisor: check the camera view (aim, calibration)' : 'Camera view checked ✓');
      for (const [pid, t] of Object.entries(this.wf.tasks)) if (t.optionIncident === inc.id) pend.push(`${ROLES[pid].short}: ${t.state === 'READY' ? 'ready - supervisor to resume' : 'conditions being re-verified'}`);
      if (o.id === 'HOLD_PLANT' || o.id === 'PAUSE_C') pend.push('Supervisor: release the plant when the path is clear');
      html += `<div class="banner blue">Confirmed at ${fmt(inc.confirmedAt)}: <b>${esc(o.title)}</b></div><div class="body"><p class="fine" style="margin:0 0 4px">Still pending:</p><ul class="fine" style="margin:0 0 6px 16px;padding:0">${pend.map((x) => `<li>${esc(x)}</li>`).join('') || '<li>nothing - waiting for conditions</li>'}</ul>${o.id === 'HOLD_PLANT' || o.id === 'PAUSE_C' ? '<button class="btn small" data-act="release">Release the plant</button>' : ''}</div>`;
    } else if (inc.type === 'unknown') {
      const stale = [...new Set((this.ev ? Object.values(this.ev.people) : []).flatMap((p) => p.conditions.flatMap((c) => c.staleSources || [])))];
      html += `<div class="banner blue">Data problem, not a site change: no layout option is needed.</div><div class="body"><p class="why1"><b>What happens now:</b> the affected tasks stay paused (they were told at once, without waiting for approval). Stale data is never used for a normal judgement.</p><p class="why1"><b>To resume:</b> restore ${esc(stale.map((k) => SOURCE_NAMES[k]).join(', ') || 'the data source')}; fresh data must re-verify every condition at the work position, the people must acknowledge, then the supervisor resumes.</p></div>`;
    } else if (this.cmp) {
      const cmp = this.cmp, keep = cmp.keep;
      const sel = cmp.options.find((o) => o.option.id === this.optionId);
      const affected = [...new Set([...inc.people])].map((x) => ROLES[x].short).join(', ') || 'site traffic';
      const selo = cmp.options.find((o) => o.option.id === this.optionId);
      const who = selo ? selo.ops.people.map((r) => ROLES[r].short).join(', ') : inc.people.length ? `${inc.people.map((r) => ROLES[r].short).join(', ')} (already told)` : 'Supervisor';
      html += `<div class="why1"><b>Why:</b> ${esc(inc.title.replace(/^Forecast: /, ''))} (${esc(affected)}). <b>Who acts:</b> ${esc(who)}.</div>`;
      if (cmp.reassess) html += '<div class="banner red">No preset option meets all conditions - the supervisor must reassess on site.</div>';
      if (!cmp.options.length && inc.type === 'current' && inc.people.length) html += '<div class="banner blue">The stop was sent to the affected people at once. No layout option in the plan is needed for this: the task resumes after its conditions are re-verified at the work position and the supervisor confirms.</div>';
      else if (!cmp.options.length) html += '<div class="banner red">No preset option applies to this change - the supervisor must reassess on site.</div>';
      html += `<div class="optlist">${cmp.options.map((o) => `<button class="${o.option.id === this.optionId ? 'on' : ''}" data-act="option" data-arg="${o.option.id}">${o.feasible ? '<span class="ok">✓</span>' : '<span class="no">✗</span>'} ${esc(o.option.title)}</button>`).join('')}</div>`;
      if (sel) {
        const conflictsTxt = (list) => (list.length ? `<span class="bad">${list.length}</span> · ${esc(list.slice(0, 2).map((c) => `${c.pid} ${SHORT[c.cond] || c.name.toLowerCase()} +${Math.round(c.from)} s`).join(', '))}` : '<span class="good">0</span>');
        const unmetK = keep.unmet.length ? `<span class="bad">${esc(keep.unmet.map((u) => SHORT[u.id] || u.name).join(', '))}</span>` : '<span class="good">none</span>';
        const unmetO = sel.after.length || sel.conflicts.length ? `<span class="bad">${esc([...new Set([...sel.conflicts.map((c) => SHORT[c.cond] || c.name), ...sel.after.map((a) => `${SHORT[a.id] || a.name} (${a.detail})`)])].join(', '))}</span>` : '<span class="good">none after the adjustment</span>';
        const unk = sel.unknownWhile.length ? `<br><span class="fine">cannot confirm for up to ${Math.round(sel.option.id === 'VMS_P2' ? 20 : 15)} s while relocating</span>` : '';
        html += `<div class="body"><table class="cmp"><tr><th></th><th>Keep current</th><th>${esc(sel.option.id)}</th></tr>
          <tr><td>Queue (max)</td><td>${Math.round(keep.queueMaxM)} m</td><td>${Math.round(sel.fc.queueMaxM)} m</td></tr>
          <tr><td>Task conflicts</td><td>${conflictsTxt(keep.conflicts)}</td><td>${conflictsTxt(sel.conflicts)}</td></tr>
          <tr><td>Conditions not met</td><td>${unmetK}</td><td>${unmetO}${unk}</td></tr>
          <tr><td>Extra work</td><td>none</td><td title="${esc(sel.option.moves.join('; '))}">${sel.ops.moves} move${sel.ops.moves === 1 ? '' : 's'}, ${sel.ops.confirmations} confirmation${sel.ops.confirmations === 1 ? '' : 's'} · ${sel.ops.people.length} people</td></tr></table>
          <p class="fine" style="margin:3px 0 0">Same observation (t ${Math.round(cmp.t)} s), same ${cmp.horizon} s horizon · ${esc(sel.option.moves.join(' · '))}</p></div>
          <div class="optacts"><button class="btn primary small" data-act="confirm">Supervisor: confirm ${esc(sel.option.id)}</button><button class="btn small" data-act="preview">${this.preview ? 'Hide' : 'Show'} 3D preview</button></div>`;
      }
    }
    setHTML($('#paneOptions'), html);
  }

  renderProgress() {
    const inc = this.focusIncident() || this.wf.incidents.filter((i) => i.type !== 'notice').slice(-1)[0];
    let html = '<h3>Handling progress <span class="hint">demo seconds</span></h3>';
    if (inc) {
      const pr = this.wf.progress(inc);
      const base = pr.occurred ?? pr.detected;
      const steps = [['Change', pr.occurred], ['Detected', pr.detected], ['Decided', pr.confirmed], ['Acked', pr.acked], ['Restored', pr.restored], ['Resumed', pr.resumed]];
      const firstMissing = steps.findIndex(([, t]) => t == null);
      html += `<div class="fine" style="margin:-4px 0 4px"><b>${esc(inc.title)}</b></div><div class="steps">${steps.map(([n, t], i) => `<div class="${t != null ? 'done' : i === firstMissing ? 'now' : ''}"><i></i>${n}<b>${t != null ? `+${Math.round(t - base)} s` : '—'}</b></div>`).join('')}</div>
        <div class="fine" style="margin-bottom:4px">People involved: ${pr.involved}${pr.pendingAcks.length ? ` · waiting for: ${pr.pendingAcks.map((r) => ROLES[r].short).join(', ')}` : ''}</div>`;
    }
    const items = [...this.world.events.filter((e) => e.kind !== 'phase').map((e) => ({ t: e.t, text: e.text, k: e.kind === 'event' || e.kind === 'drag' ? 'event' : 'world' })),
      ...this.wf.incidents.flatMap((i) => i.history.map((h) => ({ t: h.t, text: h.text, k: 'sys' })))].sort((a, b) => b.t - a.t).slice(0, 40);
    html += `<div class="body"><ul class="timeline">${items.map((x) => `<li class="k-${x.k}"><span>${x.t.toFixed(0)} s</span>${esc(x.text)}</li>`).join('')}</ul></div>`;
    setHTML($('#paneProgress'), html);
  }

  renderPhones() {
    const roles = ['SUP', 'B', 'C', 'A', 'TMA', 'PLANT'];
    const html = `<div class="drawer-h"><b>Phones</b><span class="fine">${this.settings.enabled ? 'ntfy on - also pushed to real phones' : 'ntfy off - Simulated notifications'}</span><button class="icon" data-act="closePhones">✕</button></div><div class="list">${roles.map((r) => {
      const msgs = this.wf.messages.filter((m) => m.to === r).slice(-4).reverse();
      const needs = msgs.some((m) => m.needsAck && !m.ackAt);
      const inpos = r === 'TMA' && this.wf.messages.some((m) => m.to === 'TMA' && m.level === 'plan') && !this.world.driverConfirmed;
      const camcheck = r === 'SUP' && this.world.equip.camera === 'K2' && !this.world.cameraChecked;
      const relief = r === 'SUP' && !!this.wf.find('notice:FATIGUE');
      return `<div class="phone"><div class="phone-h"><b>${esc(ROLES[r].name)}</b><span>${needs ? `<button class="btn small blue" data-act="ack" data-arg="${r}">Acknowledge</button>` : ''} ${inpos ? '<button class="btn small" data-act="inpos">In position</button>' : ''}${camcheck ? '<button class="btn small" data-act="camcheck">Camera view checked</button>' : ''}${relief ? '<button class="btn small" data-act="relief">Relief arranged</button>' : ''}</span></div>
        ${msgs.length ? msgs.map((m) => `<div class="msg ${m.level.split('-')[0]}"><div class="mt">${esc(m.title)}<span>${m.t.toFixed(0)} s</span></div>${esc(m.body)}<div class="via">${esc(m.via || '')}${m.needsAck ? (m.ackAt != null ? ` · <span class="acked">acknowledged ${m.ackAt.toFixed(0)} s</span>` : ' · not yet acknowledged') : ''}</div></div>`).join('') : '<div class="fine">No messages.</div>'}</div>`;
    }).join('')}</div>`;
    setHTML($('#phones'), html);
  }
}

try { new App(); } catch (e) { console.error(e); const n = document.getElementById('nogl'); n.hidden = false; n.textContent = 'Could not start the 3D view: ' + e.message; }
