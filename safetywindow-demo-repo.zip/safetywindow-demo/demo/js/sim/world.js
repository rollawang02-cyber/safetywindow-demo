// Ground truth of the demo site: people, shadow vehicle (TMA), plant, equipment, cones, traffic.
// This is the SIMULATION layer. The decision logic never reads it directly - it only sees what
// sensors.js reports (with timestamps and dropouts), so it can later be fed by real cameras / GPS.
import { Traffic } from './traffic.js';
import { pathPoint, pathLength } from '../core/geom.js';

const REACT_S = 1.5;      // people start moving 1.5 s after an instruction reaches their phone
const WALK = 1.4;         // m/s to the refuge
const RETRIEVE = 0.28;    // m/s while retrieving lane-line cones (pack-down)
const INSTALL = 1.4;      // m/s cone-truck deploy speed (install)

export class World {
  constructor(plan, opts = {}) {
    this.plan = plan;
    this.opts = { seed: 11, flowVph: 800, speedKmh: 60, ...opts };
    this.reset(opts.phase || 'packdown');
  }

  reset(phase = 'packdown') {
    const P = this.plan;
    this.t = 0;
    this.phase = phase;
    this.events = [];
    this.pendingOrders = [];
    this.traffic = new Traffic(P, { seed: this.opts.seed, flowVph: this.opts.flowVph, speedKmh: this.opts.speedKmh });
    for (let i = 0; i < 500; i++) this.traffic.step(0.2); // warm-up: the road is already busy when the demo opens
    this.equip = { vms: 'P1', vmsX: P.vms.positions.P1, vmsOn: true, camera: 'K1', cameraX: P.camera.positions.K1, cameraOn: true, moving: {} };
    this.sensors = { tmaGps: true, arrowTele: true, workerCam: true, upstreamCam: true, vmsRadar: true };
    this.driverConfirmed = false; this.cameraChecked = true; this.reliefArranged = false; this.signal = 'SLOW'; this.signalSince = 0;
    this.tma = { x: P.tma.positions.T1, y: P.tma.y, v: 0, target: null, arrow: true, L: P.tma.L };
    this.plant = { state: 'parked', x: P.plant.gate.x, y: P.plant.gate.y, s: 0, hold: false, requestAt: null, heading: Math.PI };
    this.coneTruck = { x: 60, y: 5.3 };
    this.cones = { lane: [], taper: [], signs: true };
    for (let x = P.closure.x0 + 5; x <= P.closure.x1; x += 5) this.cones.lane.push({ x, placed: true });
    for (let i = 0; i <= 8; i++) this.cones.taper.push({ x: P.taper.x0 + ((P.taper.x1 - P.taper.x0) * i) / 8, y: P.road.kerbY - (3.5 * i) / 8, placed: true });
    const person = (id, role, x, y, posture, task) => ({ id, role, x, y, vx: 0, vy: 0, posture, task, mode: 'work', home: { x, y }, target: null });
    this.people = {
      A: person('A', 'controller', -45, 8.6, 'stand', { id: 'control', label: 'Stop/slow at the work-zone entrance' }),
      B: person('B', 'cones', 40, 4.15, 'bend', { id: 'retrieve', label: 'Retrieve lane-line cones' }),
      C: person('C', 'site', 46, 6.3, 'stand', { id: 'load', label: 'Load cones onto the cone truck' }),
    };
    this.install = null;
    this.checkins = { A: true, B: true, C: true };
    if (phase === 'work') this._presetWork();
    if (phase === 'install') this._presetInstall();
    if (phase === 'prestart') this._presetPrestart();
    this.log('Phase: ' + phase, 'phase');
  }

  _presetWork() {
    const { people: p } = this;
    Object.assign(p.B, { x: 34, y: 6.2, posture: 'stand', task: { id: 'cones', label: 'Cone maintenance & spotting' } });
    Object.assign(p.C, { x: 62, y: 5.4, posture: 'bend', task: { id: 'pit', label: 'Pit repair in the work area' } });
    for (const k of 'ABC') p[k].home = { x: p[k].x, y: p[k].y };
    this.coneTruck = { x: 100, y: 5.3 };
    // A has been on the stop/slow bat since the start of the shift (demo: relief reminder is due ~20 s in)
    p.A.onBatSince = -(this.plan.fatigue.reliefAfterS - this.plan.fatigue.remindBeforeS - 20);
  }
  _presetInstall() {
    const P = this.plan;
    this.cones.lane.forEach((c) => (c.placed = false));
    this.cones.taper.forEach((c) => (c.placed = false));
    this.equip.vmsOn = false; this.cones.signs = false;
    this.tma.x = P.taper.x0 - 40;
    const { people: p } = this;
    Object.assign(p.B, { x: P.taper.x0 - 4, y: 8.6, posture: 'bend', task: { id: 'place', label: 'Place taper & lane-line cones' } });
    Object.assign(p.C, { x: P.taper.x0 - 8, y: 5.3, posture: 'stand', task: { id: 'drive', label: 'Drive the cone truck (in cab)' }, inCab: true });
    Object.assign(p.A, { x: -210, y: 9.2, task: { id: 'signs', label: 'Place advance signs, switch VMS on' } });
    for (const k of 'ABC') p[k].home = { x: p[k].x, y: p[k].y };
    this.coneTruck = { x: P.taper.x0 - 7, y: 5.3 };
    this.install = { step: 'signs', progress: 0 };
  }
  _presetPrestart() {
    this._presetInstall();
    this.install = null;
    this.checkins = { A: false, B: false, C: false };
    const { people: p } = this;
    Object.assign(p.A, { x: -150, y: 9.4 }); Object.assign(p.B, { x: -146, y: 9.8, posture: 'stand' }); Object.assign(p.C, { x: -142, y: 9.4, inCab: false });
    this.tma.x = -165; this.tma.y = 9.3; this.coneTruck = { x: -130, y: 9.3 };
  }

  log(text, kind = 'event') { this.events.push({ t: this.t, text, kind }); }

  // ---------------------------------------------------------------- judge events (change the site)
  inject(name) {
    const P = this.plan;
    switch (name) {
      case 'trafficSurge': this.setFlow(2400); this.traffic.prefill(-700, -260); this.log('Traffic surge: arrivals rise to 2400 veh/h', 'event'); break;
      case 'speedUp': this.setSpeed(Math.min(100, this.traffic.speedKmh + 30)); this.log(`Drivers approach faster: desired speed ${this.traffic.speedKmh} km/h`, 'event'); break;
      case 'plantEntry':
        if (this.plant.state !== 'parked') return;
        Object.assign(this.plant, { state: 'requested', requestAt: this.t, hold: false });
        this.log(`Plant requests entry - driver's app announces departure in ${P.plant.announceS} s`, 'event'); break;
      case 'tmaReposition':
        this.tma.target = P.tma.positions.T2; this.driverConfirmed = false;
        this.log('Shadow vehicle starts repositioning towards T2 (workers stay where they are)', 'event'); break;
      case 'gpsDropout': this.sensors.tmaGps = false; this.log('Shadow-vehicle GPS stops reporting', 'event'); break;
      case 'cameraDropout': this.sensors.upstreamCam = false; this.log('Upstream camera stops streaming', 'event'); break;
      case 'failToStop':
        if (this.traffic.signal === 'STOP' || this.traffic.stopRequest) return;
        this.traffic.requestFailToStop(); this._flagLogged = false; this._passLogged = false;
        this.log('A will show STOP to the next car - and its driver will not stop (scenario)', 'event'); break;
      default: throw new Error('unknown event ' + name);
    }
  }
  restoreSensor(key) { this.sensors[key] = true; this.log(`${{ tmaGps: 'Shadow-vehicle GPS', upstreamCam: 'Upstream camera', workerCam: 'Worker camera', arrowTele: 'Arrow-board telemetry', vmsRadar: 'VMS radar' }[key] || key} reporting again`, 'event'); }
  setFlow(v) { this.traffic.flowVph = v; }
  setSpeed(v) { this.traffic.speedKmh = v; }

  // ---------------------------------------------------------------- commands from confirmed decisions / phones
  order(who, action, arg) { this.pendingOrders.push({ at: this.t + REACT_S, who, action, arg }); }
  _apply({ who, action, arg }) {
    const P = this.plan;
    const p = this.people[who];
    if (action === 'refuge' && p) { p.mode = 'toRefuge'; p.target = { x: Math.min(P.refuge.x1, Math.max(P.refuge.x0, p.x)), y: 8.9 }; }
    if (action === 'stepBack' && p) { p.mode = 'toRefuge'; p.target = { x: p.x, y: P.road.vergeY - 0.2 }; }
    if (action === 'resume' && p) {
      const to = arg && typeof arg === 'object' ? { x: arg.x, y: arg.y } : { ...p.home };
      p.mode = 'toWork'; p.target = to; p.home = { ...to };
    }
    if (action === 'tmaTo') { this.tma.target = P.tma.positions[arg]; }
    if (action === 'tmaHold') { this.tma.target = null; this.tma.v = 0; }
    if (action === 'plantHold') this.plant.hold = true;
    if (action === 'plantRelease') { this.plant.hold = false; if (this.plant.state === 'requested' || this.plant.state === 'held') { this.plant.state = 'requested'; this.plant.requestAt = this.t - P.plant.announceS; } }
    if (action === 'moveVms') { this.equip.vmsOn = false; this.equip.moving.vms = { to: arg, until: this.t + 20 }; }
    if (action === 'moveCamera') { this.equip.cameraOn = false; this.cameraChecked = false; this.equip.moving.camera = { to: arg, until: this.t + 15 }; }
  }
  driverInPosition() { this.driverConfirmed = true; this.log('TMA driver taps "In position"', 'confirm'); }
  checkCamera() { this.cameraChecked = true; this.log('Supervisor checks the camera view at its new position (aim and calibration)', 'confirm'); }
  arrangeRelief() { this.reliefArranged = true; this.log('Supervisor arranges a relief controller for A', 'confirm'); }

  // Drag from the 3D view (free play): place an object; people hold where they are dropped.
  place(kind, x, y) {
    const P = this.plan;
    if (this.people[kind]) { const p = this.people[kind]; Object.assign(p, { x, y, mode: 'held', target: null, vx: 0, vy: 0 }); }
    if (kind === 'TMA') { Object.assign(this.tma, { x, y, target: null, v: 0 }); }
    if (kind === 'PLANT' && this.plant.state === 'parked') Object.assign(this.plant, { x, y });
    void P;
  }

  // ---------------------------------------------------------------- time step
  step(dt) {
    const P = this.plan;
    this.t += dt;
    this.traffic.countX = this.equip.cameraX - this.plan.camera.sightM; // speed measured at the far edge of the camera view
    this.traffic.radarX = this.equip.vmsX;
    // before the closure exists, kerb-lane traffic merges upstream of the shadow vehicle
    this.traffic.gateX = this.phase === 'install' || this.phase === 'prestart' ? Math.min(P.merge.gateX, this.tma.x - this.tma.L / 2 - 25) : P.merge.gateX;
    this.traffic.step(dt);
    if (this.traffic.signal !== this.signal) { this.signal = this.traffic.signal; this.signalSince = this.t; } // world clock (traffic has its own warm-up clock)
    this._watchStop();
    for (const o of this.pendingOrders.filter((q) => q.at <= this.t)) this._apply(o);
    this.pendingOrders = this.pendingOrders.filter((q) => q.at > this.t);
    // equipment relocations
    for (const k of ['vms', 'camera']) {
      const m = this.equip.moving[k];
      if (m && this.t >= m.until) {
        if (k === 'vms') { this.equip.vms = m.to; this.equip.vmsX = P.vms.positions[m.to]; this.equip.vmsOn = true; }
        else { this.equip.camera = m.to; this.equip.cameraX = P.camera.positions[m.to]; this.equip.cameraOn = true; }
        delete this.equip.moving[k];
        this.log(`${k === 'vms' ? 'VMS' : 'Camera'} trailer now at ${m.to}`, 'equipment');
      }
    }
    // shadow vehicle
    const tm = this.tma;
    if (tm.target !== null) {
      const d = tm.target - tm.x;
      const vmax = 1.0;
      const want = Math.sign(d) * Math.min(vmax, Math.abs(d) * 0.5);
      tm.v += Math.max(-0.5 * dt, Math.min(0.5 * dt, want - tm.v));
      tm.x += tm.v * dt;
      if (Math.abs(d) < 0.15 && Math.abs(tm.v) < 0.1) { tm.x = tm.target; tm.v = 0; tm.target = null; this.log('Shadow vehicle stopped at its target', 'equipment'); }
    } else tm.v = 0;
    // install sequence (auto crew)
    if (this.phase === 'install' && this.install) this._stepInstall(dt);
    // people
    for (const p of Object.values(this.people)) {
      const ox = p.x, oy = p.y;
      if (p.mode === 'toRefuge' || p.mode === 'toMarker' || p.mode === 'toWork') {
        const dx = p.target.x - p.x, dy = p.target.y - p.y, d = Math.hypot(dx, dy);
        // leave the lane sideways first, then walk along the verge
        if (d < 0.1) { p.x = p.target.x; p.y = p.target.y; p.mode = p.mode === 'toRefuge' ? 'refuge' : 'work'; p._arrived = true; }
        else { const s = Math.min(d, WALK * dt); p.x += (dx / d) * s; p.y += (dy / d) * s; }
      } else if (p.mode === 'work' && this.phase === 'packdown' && p.id === 'B') {
        const next = this.cones.lane.filter((c) => c.placed && c.x < p.x + 0.5).reduce((m, c) => Math.max(m, c.x), -1e9);
        if (next > P.closure.x0) {
          p.x -= RETRIEVE * dt;
          for (const c of this.cones.lane) if (c.placed && c.x > p.x + 0.8) { c.placed = false; }
        }
      }
      p.vx = (p.x - ox) / dt; p.vy = (p.y - oy) / dt;
      if (p._arrived) { p.vx = 0; p.vy = 0; p._arrived = false; } // standing still once at the spot
    }
    // plant: departs at the announced time unless held; its driver stops for anyone within clearance ahead
    const pl = this.plant;
    if (pl.state === 'requested' && !pl.hold && this.t >= pl.requestAt + P.plant.announceS) { pl.state = 'moving'; this.log('Plant leaves the gate', 'event'); }
    if (pl.state === 'requested' && pl.hold && this.t >= pl.requestAt + P.plant.announceS && !pl._heldLogged) { pl._heldLogged = true; this.log('Plant held at the gate', 'event'); }
    if (pl.state === 'moving') {
      if (pl.hold) { /* hold only applies before departure */ }
      const ahead = plantPoint(P.plant.path, pl.s + 3);
      const blocked = Object.values(this.people).some((q) => Math.hypot(q.x - ahead.x, q.y - ahead.y) < P.plant.clearance - 1);
      pl.blocked = blocked;
      if (!blocked) pl.s += P.plant.speed * dt;
      const pt = plantPoint(P.plant.path, pl.s);
      Object.assign(pl, { x: pt.x, y: pt.y, heading: pt.heading });
      if (pt.end) { pl.state = 'arrived'; this.log('Plant parked in the work area', 'event'); }
    }
  }

  // ground-truth log for the fail-to-stop scenario (never read by the decision logic)
  _watchStop() {
    const tr = this.traffic, A = this.people.A;
    if (tr.flagged != null && !this._flagLogged) { this._flagLogged = true; this.log('A shows STOP - the lead driver keeps going', 'event'); }
    const car = tr.all().find((v) => v.noStop);
    if (car && !this._passLogged && car.x - car.L / 2 >= A.x) {
      this._passLogged = true;
      this.log(`Car ran the STOP at ${Math.round(car.v * 3.6)} km/h, passing A ${(A.y - car.y - car.W / 2).toFixed(1)} m away (A ${A.y > this.plan.road.kerbY + 2.5 ? 'had stepped back' : 'was still at the kerb'})`, 'event');
    }
  }

  _stepInstall(dt) {
    const P = this.plan, ins = this.install, p = this.people;
    if (ins.step === 'signs') {
      ins.progress += dt;
      if (ins.progress > 6) { this.equip.vmsOn = true; this.cones.signs = true; ins.step = 'tma'; this.log('Advance signs placed, VMS on', 'install'); p.A.mode = 'toWork'; p.A.home = { x: -45, y: 8.6 }; p.A.target = { ...p.A.home }; p.A.task = { id: 'control', label: 'Stop/slow at the work-zone entrance' }; }
    } else if (ins.step === 'tma') {
      if (this.tma.target === null && Math.abs(this.tma.x - (P.taper.x0 - 30)) > 0.5) this.tma.target = P.taper.x0 - 30;
      if (this.tma.target === null) { ins.step = 'taper'; ins.i = 0; this.log('Shadow vehicle in position behind the crew', 'install'); }
    } else if (ins.step === 'taper' || ins.step === 'lane') {
      if (p.B.mode !== 'work') return;
      const list = ins.step === 'taper' ? this.cones.taper : this.cones.lane;
      const next = list.find((c) => !c.placed);
      if (!next) {
        if (ins.step === 'taper') { ins.step = 'lane'; this.log('Taper complete', 'install'); }
        else { ins.step = 'done'; this.log('Install complete - ready for works', 'install'); }
        return;
      }
      p.B.x += INSTALL * dt; p.B.y = ins.step === 'taper' ? Math.max(4.1, next.y ?? 4.1) : 4.1;
      this.coneTruck.x = p.B.x - 3; p.C.x = p.B.x - 3;
      if (p.B.x >= next.x) next.placed = true;
      // the shadow-vehicle driver follows ~30 m behind (unless a judge moved it)
      if (!this.tma.frozen) { const want = p.B.x - 30 - this.tma.L / 2; if (want > this.tma.x) this.tma.x = Math.min(want, this.tma.x + 1.8 * dt); }
    }
  }
}

export const plantPoint = pathPoint;
export { pathLength };
