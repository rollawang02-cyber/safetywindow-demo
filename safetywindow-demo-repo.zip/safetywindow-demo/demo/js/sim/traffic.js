// Ground-truth traffic for the demo site (simulation layer - replaced by real detections later).
// Eastbound: two lanes upstream (kerb L1, median L2) merge at a zipper gate into the median lane because the
// kerb lane is closed. Westbound: one free lane. Car following uses the Intelligent Driver Model (IDM).

export function rng(seed) {
  let a = seed >>> 0;
  return () => { a = (a + 0x6d2b79f5) >>> 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

const IDM = { a: 1.4, b: 2.2, s0: 2.0, T: 1.3 };
const JAM = 6.5; // metres per queued vehicle (length + standstill gap)

function idmAcc(v, v0, gap, dv) {
  const sStar = IDM.s0 + Math.max(0, v * IDM.T + (v * dv) / (2 * Math.sqrt(IDM.a * IDM.b)));
  const g = Math.max(0.1, gap);
  return IDM.a * (1 - Math.pow(v / Math.max(0.1, v0), 4) - (sStar / g) ** 2);
}

export class Traffic {
  constructor(plan, { seed = 11, flowVph = 900, speedKmh = 60, wbFlowVph = 450 } = {}) {
    this.plan = plan;
    this.rand = rng(seed);
    this.flowVph = flowVph;
    this.speedKmh = speedKmh;
    this.wbFlowVph = wbFlowVph;
    this.t = 0;
    this.nextId = 1;
    this.up = { L1: [], L2: [] }; // front (largest x) first
    this.down = [];               // merged median lane, front first
    this.wb = [];                 // westbound, front (smallest x) first
    this.lastPass = -99; this.lastLane = 'L2';
    this.gateX = plan.merge.gateX;  // zipper merge point (moves upstream of the shadow vehicle during install)
    this.nextArrival = this._gap(flowVph); this.nextWb = this._gap(wbFlowVph);
    this.passLog = [];            // {t, v} vehicles passing the speed camera
    this.radarLog = [];           // {t} vehicles passing the VMS radar (demand counter, further upstream)
    this.countX = plan.camera.positions.K1 - plan.camera.sightM;
    this.radarX = plan.vms.positions.P1;
    // stop/slow bat at the merge gate: SLOW = zipper as usual; STOP = no one enters (committed vehicles excepted)
    this.signal = 'SLOW'; this.signalSince = 0;
    this.stopRequest = null; // pending "next driver will not stop" scenario
    this.flagged = null;     // id of the vehicle that ignores the STOP (ground truth only)
  }

  // A shows STOP to cars beyond minStopM; closer cars, or cars that could not stop comfortably, are let through
  _commitD(v) { return Math.max(this.plan.stopLine.minStopM, (v.v * v.v) / (2 * this.plan.stopLine.commitDecel) + 5); }

  // Scenario: A shows STOP to the next platoon and its lead driver does not stop. Waits until a lead vehicle is far
  // enough away that it could stop comfortably - otherwise it would simply be a committed vehicle.
  requestFailToStop() { this.stopRequest = { at: this.t }; }
  _tryFailToStop() {
    const gate = this.gateX, cands = [];
    for (const k of ['L1', 'L2']) {
      // the lead driver of a lane (only let-through cars ahead of it), so nothing slow is in its way
      const list = this.up[k], i = list.findIndex((v) => gate - v.x >= this._commitD(v));
      if (i < 0) continue;
      const waited = this.t - this.stopRequest.at;
      const clear = list.slice(0, i).every((u) => (gate - u.x < 12 && u.v > 3) || (waited > 15 && u.v > 8));
      if (clear) cands.push({ v: list[i], d: gate - list[i].x });
    }
    const waited = this.t - this.stopRequest.at;
    const ok = cands.filter((c) => c.d >= (waited > 10 ? 70 : 95) && c.d <= 220 && c.v.v >= 12).sort((a, b) => a.d - b.d);
    if (!ok.length) return;
    const pick = ok[0].v;
    this.signal = 'STOP'; this.signalSince = this.t; this.stopRequest = null;
    for (const k of ['L1', 'L2']) for (const v of this.up[k]) {
      if (v === pick) { v.noStop = true; v.token = false; continue; }
      if (gate - v.x < this._commitD(v)) v.token = true; // too close to stop: let it through
      else v.token = false;                             // everyone else stops at the line
    }
    this.flagged = pick.id;
  }
  setSignal(s) { if (s !== this.signal) { this.signal = s; this.signalSince = this.t; } }

  _gap(vph) { return vph <= 0 ? 1e9 : -Math.log(1 - this.rand()) * (3600 / vph); }
  _v0(x) { const zone = x >= this.plan.speedZone.x ? this.plan.speedZone.kmh : this.speedKmh; return zone / 3.6; }

  _spawn() {
    const lane = this.rand() < 0.5 ? 'L1' : 'L2';
    const list = this.up[lane];
    const x0 = this.plan.road.xMin;
    const last = list[list.length - 1];
    if (last && last.x - x0 < 14) return false; // no room yet; try again next step
    const f = 0.92 + this.rand() * 0.16;
    const v = last ? Math.min(this.speedKmh / 3.6 * f, last.v) : this.speedKmh / 3.6 * f;
    const truck = this.rand() < 0.12;
    list.push({ id: this.nextId++, x: x0, v, lane, f, L: truck ? 9 : 4.6, W: truck ? 2.5 : 1.9, truck, token: false, color: this.rand() });
    return true;
  }

  // A platoon already on the road upstream (e.g. released by a signal): fill gaps so the new demand arrives now.
  prefill(xFrom, xTo) {
    const perLane = this.flowVph / 2, v = this.speedKmh / 3.6;
    const spacing = Math.max(18, (3600 / perLane) * v);
    for (const k of ['L1', 'L2']) {
      const list = this.up[k];
      for (let x = xFrom; x <= xTo; x += spacing) {
        const clash = list.some((o) => Math.abs(o.x - x) < 16);
        if (clash) continue;
        const f = 0.92 + this.rand() * 0.16;
        list.push({ id: this.nextId++, x, v: v * f * 0.95, lane: k, f, L: 4.6, W: 1.9, truck: false, token: false, color: this.rand() });
      }
      list.sort((a, b) => b.x - a.x);
    }
  }

  step(dt) {
    this.t += dt;
    const gate = this.gateX;
    if (this.stopRequest) this._tryFailToStop();
    // back to SLOW once the non-stopping car is well past the line
    if (this.signal === 'STOP' && this.flagged != null) {
      const f = this.down.find((v) => v.id === this.flagged);
      if (f && f.x > gate + 60) { this.flagged = null; this.releaseAt = this.t + 4; }
    }
    if (this.signal === 'STOP' && this.releaseAt != null && this.t >= this.releaseAt) { this.releaseAt = null; this.setSignal('SLOW'); }
    // arrivals
    this.nextArrival -= dt;
    while (this.nextArrival <= 0) {
      if (!this._spawn()) { this.nextArrival = 0.3; break; }
      this.nextArrival += this._gap(this.flowVph);
    }
    this.nextWb -= dt;
    if (this.nextWb <= 0) {
      const last = this.wb[this.wb.length - 1];
      if (!last || this.plan.road.xMax - last.x > 14) {
        this.wb.push({ id: this.nextId++, x: this.plan.road.xMax, v: this.speedKmh / 3.6, f: 0.95 + this.rand() * 0.1, L: 4.6, W: 1.9, color: this.rand() });
        this.nextWb = this._gap(this.wbFlowVph);
      } else this.nextWb = 0.5;
    }
    // zipper tokens: one vehicle per headway, alternating lanes when both are waiting
    const fronts = ['L1', 'L2'].map((k) => this.up[k][0]).filter(Boolean);
    const cand = fronts.filter((v) => !v.token && gate - v.x < Math.max(35, (v.v * v.v) / (2 * IDM.b) + 40));
    if (this.signal !== 'STOP' && cand.length && this.t - this.lastPass >= this.plan.merge.headway && !fronts.some((v) => v.token)) {
      let pick = cand[0];
      if (cand.length === 2) pick = cand.find((v) => v.lane !== this.lastLane) || cand[0];
      pick.token = true; this.lastLane = pick.lane; this.lastPass = this.t;
    }
    // IDM for upstream lanes
    const rearDown = this.down[this.down.length - 1];
    for (const k of ['L1', 'L2']) {
      const list = this.up[k];
      for (let i = 0; i < list.length; i++) {
        const v = list[i];
        let gap, dv;
        if (i > 0) {
          const l = list[i - 1]; gap = l.x - l.L - v.x; dv = v.v - l.v;
          // behind a car that runs the STOP, a normal driver still stops at the line
          // (the car ahead is let through or runs it, so the line - not that car - is what this driver brakes for)
          if (this.signal === 'STOP' && (l.noStop || l.token) && !v.noStop && !v.token) { gap = Math.max(0.1, gate - v.x); dv = v.v; }
        }
        else if (v.token || v.noStop) {
          if (rearDown) { gap = rearDown.x - rearDown.L - v.x; dv = v.v - rearDown.v; } else { gap = 1e4; dv = 0; }
        } else { gap = gate - v.x; dv = v.v; }
        v.acc = Math.max(-9, idmAcc(v.v, (v.noStop ? this.speedKmh / 3.6 : this._v0(v.x)) * v.f, gap, dv));
      }
    }
    for (let i = 0; i < this.down.length; i++) {
      const v = this.down[i];
      const l = this.down[i - 1];
      const v0 = (v.noStop ? this.speedKmh / 3.6 : this._v0(v.x)) * v.f;
      v.acc = l ? idmAcc(v.v, v0, l.x - l.L - v.x, v.v - l.v) : idmAcc(v.v, v0, 1e4, 0);
    }
    for (let i = 0; i < this.wb.length; i++) {
      const v = this.wb[i];
      const l = this.wb[i - 1];
      v.acc = l ? idmAcc(v.v, (this.speedKmh / 3.6) * v.f, v.x - (l.x + l.L), v.v - l.v) : idmAcc(v.v, (this.speedKmh / 3.6) * v.f, 1e4, 0);
    }
    const move = (v, dir = 1) => {
      const nv = Math.max(0, v.v + v.acc * dt);
      v.x += dir * Math.max(0, (v.v + nv) / 2 * dt);
      v.v = nv;
    };
    for (const k of ['L1', 'L2']) for (const v of this.up[k]) move(v);
    for (const v of this.down) move(v);
    for (const v of this.wb) move(v, -1);
    // counting point (upstream camera)
    for (const k of ['L1', 'L2']) for (const v of this.up[k]) {
      if (!v.counted && v.x >= this.countX) { v.counted = true; this.passLog.push({ t: this.t, v: v.v }); }
    }
    for (const k of ['L1', 'L2']) for (const v of this.up[k]) {
      if (!v.radar && v.x >= this.radarX) { v.radar = true; this.radarLog.push({ t: this.t }); }
    }
    this.passLog = this.passLog.filter((p) => this.t - p.t <= 90);
    this.radarLog = this.radarLog.filter((p) => this.t - p.t <= 90);
    // merge: front vehicles with a token that crossed the gate join the downstream lane
    for (const k of ['L1', 'L2']) {
      const f = this.up[k][0];
      if (f && (f.token || f.noStop) && f.x >= gate) { this.up[k].shift(); f.lane = 'D'; this.down.push(f); }
    }
    this.down.sort((a, b) => b.x - a.x);
    this.down = this.down.filter((v) => v.x < this.plan.road.xMax + 20);
    this.wb = this.wb.filter((v) => v.x > this.plan.road.xMin - 20);
  }

  // y position for drawing (kerb-lane vehicles shift across the taper)
  yOf(v) {
    const { lanes, merge } = this.plan;
    if (v.lane === 'L2' || v.lane === 'D') {
      if (v.fromKerb === undefined) return lanes.median;
    }
    if (v.lane === 'L1') {
      const g = this.gateX, from = g - (merge.gateX - merge.shiftFrom);
      const s = Math.min(1, Math.max(0, (v.x - from) / (g - from)));
      return v.token || v.noStop ? lanes.kerb + (lanes.median - lanes.kerb) * s : lanes.kerb + (lanes.median - lanes.kerb) * Math.min(s, 0.35);
    }
    return lanes.median;
  }

  all() {
    const out = [];
    for (const k of ['L1', 'L2']) for (const v of this.up[k]) out.push({ ...v, y: this.yOf(v), dir: 1 });
    for (const v of this.down) out.push({ ...v, y: this.plan.lanes.median, dir: 1 });
    for (const v of this.wb) out.push({ ...v, y: this.plan.lanes.wb, dir: -1 });
    return out;
  }

  // Ground-truth queue: contiguous slow vehicles back from the gate, per upstream lane.
  queue() {
    const gate = this.gateX;
    let tailX = gate, count = 0;
    for (const k of ['L1', 'L2']) {
      const list = this.up[k];
      if (!list.length || gate - list[0].x > 25 || list[0].v > 4) continue;
      let tail = list[0].x - list[0].L;
      count++;
      for (let i = 1; i < list.length; i++) {
        const l = list[i - 1], v = list[i];
        if (l.x - l.L - v.x > 20 || v.v > 5.5) break;
        tail = v.x - v.L; count++;
      }
      tailX = Math.min(tailX, tail);
    }
    return { tailX, lengthM: gate - tailX, vehicles: count };
  }

  // Detector outputs: demand at the VMS radar (last 30 s) and 85th-percentile speed at the camera (last 40 s).
  counts() {
    const span = Math.min(30, this.t);
    const arrivals = this.radarLog.filter((p) => this.t - p.t <= 30).length;
    const recent = this.passLog.filter((p) => this.t - p.t <= 40);
    const speeds = recent.map((p) => p.v).sort((a, b) => a - b);
    const v85 = speeds.length >= 3 ? speeds[Math.min(speeds.length - 1, Math.floor(speeds.length * 0.85))] : null;
    return { inflowVph: span >= 10 ? (arrivals / span) * 3600 : null, v85, nSpeed: recent.length };
  }
}

export const QUEUE_JAM_M = JAM;
