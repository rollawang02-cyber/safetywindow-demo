// Condition rules. Pure functions of an observation (from sensors.js, or a hypothetical one from forecast.js).
// Each phase has its own condition set - pack-down rules are NOT reused for normal works.
//
// Status values: MET · NOT_MET · UNKNOWN (data missing or older than the plan's staleAfter) · NA (not exposed)

export const STATUS_LABEL = {
  MET: 'Monitored conditions met',
  PREDICTED: 'Adjustment likely needed',
  NOT_MET: 'Conditions not met',
  UNKNOWN: 'Cannot confirm',
  NA: 'Not exposed',
};

export const SETS = {
  prestart: { SITE: ['PLAN', 'CHECKIN', 'DEVICES'], A: [], B: [], C: [] },
  install: { A: ['ON_VERGE'], B: ['VMS_ON', 'TMA_IN_LANE', 'GAP', 'ARROW', 'OUT_OF_LANE', 'ORDER_INSTALL'], C: ['IN_CAB'] },
  work: { A: ['WARN_TIME', 'VEH_STOP', 'ON_VERGE', 'QUEUE'], B: ['IN_AREA', 'OUT_OF_LANE', 'PLANT_CLEAR', 'BARRIER'], C: ['IN_AREA', 'OUT_OF_LANE', 'PLANT_CLEAR', 'BARRIER'] },
  packdown: { A: ['WARN_TIME', 'ON_VERGE', 'QUEUE'], B: ['TMA_IN_LANE', 'GAP', 'ARROW', 'OUT_OF_LANE', 'ORDER_PACKDOWN', 'PLANT_CLEAR'], C: ['TMA_IN_LANE', 'GAP', 'ARROW', 'OUT_OF_LANE', 'PLANT_CLEAR'] },
};

// kind groups conditions for forecasts / option matching; onFail says what a failure triggers.
export const COND = {
  PLAN: { name: 'Sample plan loaded', kind: 'setup', onFail: 'notify', src: [] },
  CHECKIN: { name: 'Crew checked in on their phones', kind: 'setup', onFail: 'notify', src: [] },
  DEVICES: { name: 'All site data sources live', kind: 'setup', onFail: 'notify', src: [] },
  TMA_IN_LANE: { name: 'Shadow vehicle in the closed lane, upstream', kind: 'tma', onFail: 'stop', src: ['tmaGps', 'workerCam'] },
  GAP: { name: 'Protection gap within the plan range', kind: 'gap', onFail: 'stop', src: ['tmaGps', 'workerCam'] },
  BARRIER: { name: 'Parked shadow vehicle keeps the roll-ahead distance', kind: 'gap', onFail: 'stop', src: ['tmaGps', 'workerCam'] },
  ARROW: { name: 'Arrow board on', kind: 'arrow', onFail: 'notify', src: ['arrowTele'] },
  OUT_OF_LANE: { name: 'Clear of the open lane', kind: 'lane', onFail: 'stop', src: ['workerCam'] },
  ON_VERGE: { name: 'Standing on the verge, off the carriageway', kind: 'lane', onFail: 'stop', src: ['workerCam'] },
  IN_AREA: { name: 'Inside the configured work area', kind: 'area', onFail: 'stop', src: ['workerCam'] },
  IN_CAB: { name: 'In the cone-truck cab', kind: 'area', onFail: 'notify', src: ['workerCam'] },
  WARN_TIME: { name: 'Camera layout gives enough warning time', kind: 'warning', onFail: 'stop', src: ['upstreamCam', 'workerCam', 'equipGps'] },
  VEH_STOP: { name: 'Approaching cars can stop at A\'s STOP', kind: 'vehicle', onFail: 'stop', src: ['vmsRadar', 'workerCam'] },
  QUEUE: { name: 'Queue tail stays inside the warned range', kind: 'queue', onFail: 'notify', src: ['vmsRadar', 'equipGps'] },
  PLANT_CLEAR: { name: 'Clear of the plant path', kind: 'plant', onFail: 'stop', src: ['plantApp', 'workerCam'] },
  VMS_ON: { name: 'Advance signs placed and VMS on', kind: 'setup', onFail: 'stop', src: ['equipGps'] },
  ORDER_INSTALL: { name: 'Install order: signs, shadow vehicle, taper, lane cones', kind: 'order', onFail: 'notify', src: [] },
  ORDER_PACKDOWN: { name: 'Pack-down order: lane cones, then taper, signs last', kind: 'order', onFail: 'notify', src: [] },
};

const r1 = (v) => Math.round(v * 10) / 10;
const r0 = (v) => Math.round(v);

export function evaluate(obs, plan, ctx = {}) {
  const set = SETS[obs.phase] || SETS.work;
  const S = obs.src;
  const stale = plan.timing.staleAfter;
  const out = { t: obs.t, phase: obs.phase, people: {}, site: null };
  const fresh = (keys) => keys.filter((k) => !S[k] || S[k].age > stale).map((k) => ({ k, age: S[k] ? S[k].age : Infinity }));

  const evalOne = (id, pid) => {
    const def = COND[id];
    const c = { id, name: def.name, kind: def.kind, onFail: def.onFail, src: def.src };
    const missing = fresh(def.src);
    if (missing.length) {
      c.status = 'UNKNOWN';
      c.detail = missing.map(({ k, age }) => `${k === 'tmaGps' ? 'shadow-vehicle GPS' : k === 'workerCam' ? 'worker camera' : k === 'upstreamCam' ? 'upstream camera' : k === 'vmsRadar' ? 'VMS radar' : k === 'arrowTele' ? 'arrow-board telemetry' : k === 'plantApp' ? 'plant app' : k} ${age === Infinity ? 'has no data' : `last update ${age.toFixed(1)} s ago`}`).join('; ');
      c.staleSources = missing.map((m) => m.k);
      return c;
    }
    const me = pid && S.workerCam ? S.workerCam.people[pid] : null;
    const tma = S.tmaGps;
    const front = tma ? tma.x + tma.L / 2 : null;
    const inRefuge = me && me.y >= plan.refuge.y0 - 0.2;
    // people at the verge refuge are not exposed to the lane conditions
    if (inRefuge && ['ARROW', 'OUT_OF_LANE', 'VMS_ON'].includes(id)) { Object.assign(c, { status: 'NA', detail: 'at the refuge - not exposed' }); return c; }
    switch (id) {
      case 'PLAN': Object.assign(c, { status: 'MET', detail: plan.title }); break;
      case 'CHECKIN': {
        const n = Object.values(obs.confirmations.checkins).filter(Boolean).length;
        Object.assign(c, { status: n === 3 ? 'MET' : 'NOT_MET', detail: `${n} of 3 checked in` }); break;
      }
      case 'DEVICES': {
        const keys = ['tmaGps', 'arrowTele', 'workerCam', 'upstreamCam', 'vmsRadar'];
        const bad = keys.filter((k) => !S[k] || S[k].age > stale);
        Object.assign(c, { status: bad.length ? 'NOT_MET' : 'MET', detail: bad.length ? `not live: ${bad.join(', ')}` : '5 of 5 sources live' }); break;
      }
      case 'TMA_IN_LANE': {
        if (inRefuge) { Object.assign(c, { status: 'NA', detail: 'at the refuge - not exposed' }); break; }
        const inLane = Math.abs(tma.y - plan.lanes.kerb) < 1.2;
        const up = front < me.x;
        Object.assign(c, { status: inLane && up ? 'MET' : 'NOT_MET', detail: !inLane ? 'shadow vehicle has left the closed lane' : up ? `in the closed lane, ${r0(me.x - front)} m upstream` : 'shadow vehicle is not upstream of this worker' });
        break;
      }
      case 'GAP': case 'BARRIER': {
        if (inRefuge) { Object.assign(c, { status: 'NA', detail: 'at the refuge - not exposed' }); break; }
        const [lo, hi] = plan.tma.gap;
        const gap = me.x - front;
        const max = id === 'GAP' ? hi : Infinity;
        c.value = gap; c.limit = id === 'GAP' ? [lo, hi] : [lo, null]; c.unit = 'm';
        if (gap < lo) Object.assign(c, { status: 'NOT_MET', detail: `gap ${Math.floor(gap)} m < ${lo} m roll-ahead minimum` });
        else if (gap > max) Object.assign(c, { status: 'NOT_MET', detail: `gap ${Math.ceil(gap)} m > ${hi} m maximum` });
        else Object.assign(c, { status: 'MET', detail: id === 'GAP' ? `gap ${r0(gap)} m (plan ${lo}-${hi} m)` : `gap ${r0(gap)} m (min ${lo} m)` });
        break;
      }
      case 'ARROW': Object.assign(c, { status: S.arrowTele.on ? 'MET' : 'NOT_MET', detail: S.arrowTele.on ? 'arrow board on' : 'arrow board off' }); break;
      case 'OUT_OF_LANE': {
        const edge = plan.openLaneEdge + plan.openLaneMargin;
        c.value = me.y - plan.openLaneEdge; c.unit = 'm';
        Object.assign(c, { status: me.y >= edge ? 'MET' : 'NOT_MET', detail: me.y >= edge ? `${r1(me.y - plan.openLaneEdge)} m from the open lane` : me.y >= plan.openLaneEdge ? 'within 0.3 m of the open lane' : 'in the open lane' });
        break;
      }
      case 'ON_VERGE': Object.assign(c, { status: me.y >= plan.road.kerbY ? 'MET' : 'NOT_MET', detail: me.y >= plan.road.kerbY ? 'on the verge' : 'on the carriageway' }); break;
      case 'IN_AREA': {
        const w = plan.workArea;
        const inside = me.x >= w.x0 && me.x <= w.x1 && me.y >= w.y0 && me.y <= w.y1;
        Object.assign(c, { status: inside || inRefuge ? 'MET' : 'NOT_MET', detail: inRefuge ? 'at the refuge' : inside ? 'inside the work area' : `outside the work area (x ${r0(me.x)} m, y ${r1(me.y)} m)` });
        break;
      }
      case 'IN_CAB': Object.assign(c, { status: 'MET', detail: 'in the cab - no lane exposure' }); break;
      case 'WARN_TIME': {
        const cam = S.upstreamCam, eq = S.equipGps;
        const assumed = cam.v85 == null;
        const v = assumed ? 60 / 3.6 : Math.max(1, cam.v85);
        const sightEnd = eq.cameraX - plan.camera.sightM;
        const avail = (me.x - sightEnd) / v;
        const need = plan.timing.responseS[me.posture === 'bend' ? 'bend' : 'stand'] + plan.timing.latency + plan.timing.buffer;
        Object.assign(c, { value: avail, limit: [need, null], unit: 's', status: avail >= need ? 'MET' : 'NOT_MET',
          detail: assumed ? `assumed, not measured: ${avail.toFixed(1)} s at the 60 km/h posted limit (no vehicles measured yet), ${need.toFixed(1)} s needed` : `${avail.toFixed(1)} s available, ${need.toFixed(1)} s needed (${r0(v * 3.6)} km/h measured)`, assumed });
        break;
      }
      case 'VEH_STOP': {
        const sig = obs.signal || { state: 'SLOW' };
        if (sig.state !== 'STOP') { Object.assign(c, { status: 'MET', detail: 'showing SLOW - no STOP to enforce' }); break; }
        const rd = S.vmsRadar, gate = rd.gateX, K = plan.stopLine.flagDecel;
        // drivers need about a second to react to the STOP before they can be expected to brake
        if (obs.t - sig.since < plan.stopLine.reactS) { Object.assign(c, { status: 'MET', detail: 'STOP just shown - giving drivers time to react' }); break; }
        let worstCar = null;
        for (const r of rd.tracks || []) {
          if (r.committed || r.v < 1.5 || r.a == null) continue;
          const d = Math.max(0.5, gate - r.x), need = (r.v * r.v) / (2 * d), braking = Math.max(0, -Math.min(r.a, r.aRaw ?? r.a));
          // flagged: it needs more than flagDecel to stop at the line and is braking at less than half of that,
          // or (closer in) it needs more than commitDecel and its current braking would carry it past the line
          const overrun = need > plan.stopLine.commitDecel && (r.v * r.v) / (2 * Math.max(braking, 0.1)) > d + 2;
          if (r.v > 6 && need > K && (braking < 0.5 * need || overrun)) {
            const tA = Math.max(0, (me.x - r.x) / r.v);
            if (!worstCar || tA < worstCar.tA) worstCar = { ...r, d, need, braking, tA };
            c.carId = worstCar.id;
          }
        }
        if (worstCar) Object.assign(c, { status: 'NOT_MET', value: worstCar.tA, unit: 's',
          detail: `car at ${r0(worstCar.v * 3.6)} km/h, ${r0(worstCar.d)} m from the STOP line, not braking enough (needs ${worstCar.need.toFixed(1)} m/s², braking ${worstCar.braking.toFixed(1)}) - reaches A in ${worstCar.tA.toFixed(1)} s` });
        else Object.assign(c, { status: 'MET', detail: `showing STOP; ${(rd.tracks || []).filter((r) => !r.committed).length} approaching car(s) can stop in time` });
        break;
      }
      case 'QUEUE': {
        const rd = S.vmsRadar, eq = S.equipGps;
        if (rd.beyondVms) { Object.assign(c, { status: 'NOT_MET', detail: 'queue tail is beyond the VMS - approaching drivers are not warned', value: -1, limit: [plan.vms.leadM, null], unit: 'm' }); break; }
        const past = rd.queueTailX - eq.vmsX;
        Object.assign(c, { value: past, limit: [plan.vms.leadM, null], unit: 'm', status: past >= plan.vms.leadM ? 'MET' : 'NOT_MET',
          detail: rd.queueVehicles ? `queue ${r0(rd.queueLengthM)} m; tail ${r0(past)} m past the VMS (needs ≥ ${plan.vms.leadM} m)` : `no queue; VMS ${r0(plan.merge.gateX - eq.vmsX)} m before the merge` });
        break;
      }
      case 'PLANT_CLEAR': {
        const pl = S.plantApp;
        if (pl.state !== 'moving') { Object.assign(c, { status: 'MET', detail: pl.state === 'requested' ? 'plant waiting at the gate' : pl.state === 'arrived' ? 'plant parked' : 'plant parked at the gate' }); break; }
        const d = Math.hypot(pl.x - me.x, pl.y - me.y);
        c.value = d; c.limit = [plan.plant.clearance, null]; c.unit = 'm';
        Object.assign(c, { status: d >= plan.plant.clearance ? 'MET' : 'NOT_MET', detail: `plant ${r0(d)} m away (keep ≥ ${plan.plant.clearance} m)` });
        break;
      }
      case 'VMS_ON': Object.assign(c, { status: S.equipGps.vmsOn && obs.cones.signs ? 'MET' : 'NOT_MET', detail: S.equipGps.vmsOn && obs.cones.signs ? 'advance signs placed, VMS on' : 'advance warning not yet in place' }); break;
      case 'ORDER_INSTALL': {
        const st = obs.install ? obs.install.step : 'done';
        const ok = !(st === 'lane' && !obs.cones.taperDone);
        Object.assign(c, { status: ok ? 'MET' : 'NOT_MET', detail: { signs: 'step 1/4: advance signs', tma: 'step 2/4: shadow vehicle', taper: 'step 3/4: taper', lane: 'step 4/4: lane-line cones', done: 'install complete' }[st] || st });
        break;
      }
      case 'ORDER_PACKDOWN': {
        const ok = !(obs.cones.laneLeft > 0 && obs.cones.taperLeft < 9);
        Object.assign(c, { status: ok ? 'MET' : 'NOT_MET', detail: ok ? `${obs.cones.laneLeft} lane-line cones left; taper and signs stay until last` : 'taper removed before lane-line cones' });
        break;
      }
      default: Object.assign(c, { status: 'UNKNOWN', detail: 'no rule' });
    }
    return c;
  };

  for (const pid of ['A', 'B', 'C']) {
    const conditions = (set[pid] || []).map((id) => evalOne(id, pid));
    const me = S.workerCam && S.workerCam.age <= stale ? S.workerCam.people[pid] : null;
    out.people[pid] = { id: pid, task: obs.tasks[pid], conditions, status: worst(conditions), stop: conditions.filter((c) => c.onFail === 'stop' && (c.status === 'NOT_MET' || c.status === 'UNKNOWN')), atRefuge: !!(me && me.y >= plan.refuge.y0 - 0.2), paused: !!(ctx.paused && ctx.paused[pid]) };
  }
  if (set.SITE) { const conditions = set.SITE.map((id) => evalOne(id, null)); out.site = { conditions, status: worst(conditions) }; }
  return out;
}

export function worst(conds) {
  if (conds.some((c) => c.status === 'NOT_MET')) return 'NOT_MET';
  if (conds.some((c) => c.status === 'UNKNOWN')) return 'UNKNOWN';
  if (!conds.length || conds.every((c) => c.status === 'NA')) return conds.length ? 'NA' : 'MET';
  return 'MET';
}
