// Phone notifications through ntfy (https://ntfy.sh) - free, no account, iOS + Android apps.
// Each person (and the supervisor) subscribes to their own topic: <prefix>-A, <prefix>-B, <prefix>-C, <prefix>-SUP.
// A topic works like a password - keep the prefix long and random.
//
// Note: HTTP header values must be plain ASCII, so titles avoid symbols like "≤" or "→".

const KEY = 'safetywindow.ntfy';

export function loadSettings() {
  let s = null;
  try { s = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { s = null; }
  if (!s) s = { enabled: false, server: 'https://ntfy.sh', prefix: 'sw-' + Math.random().toString(36).slice(2, 10), bound: { A: true, B: true, C: true, SUP: true } };
  return s;
}
export function saveSettings(s) {
  try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* private window: settings last for this session only */ }
}
export function topicFor(s, who) {
  return `${s.prefix}-${who}`;
}

const ascii = (x) => String(x).replace(/[^\x20-\x7E]/g, '-');

export async function push(s, who, { title, message, priority = 4, tags = 'warning' }) {
  if (!s.enabled || !s.bound[who]) return { skipped: true };
  const t0 = performance.now();
  try {
    const r = await fetch(`${s.server.replace(/\/$/, '')}/${topicFor(s, who)}`, {
      method: 'POST',
      body: message,
      headers: { Title: ascii(title), Priority: String(priority), Tags: ascii(tags) },
    });
    return { ok: r.ok, status: r.status, ms: Math.round(performance.now() - t0) };
  } catch (e) {
    return { ok: false, error: String(e), ms: Math.round(performance.now() - t0) };
  }
}

// Turn an engine notification into phone text.
export function formatNotification(n, people) {
  const r = n.reason || {};
  const name = (id) => (people.find((p) => p.id === id) || { name: id }).name;
  if (n.level === 'COVERAGE') {
    return {
      title: `SafetyWindow: protection unavailable for ${name(n.about)}`,
      message: `Camera cannot see far enough: ${name(n.about)} would get ${r.available.toFixed(1)} s of warning but needs ${r.need.toFixed(1)} s. Check the camera view / layout.`,
      priority: 3, tags: 'eyes,warning',
    };
  }
  if (n.to === 'SUP') {
    return {
      title: `SafetyWindow CRITICAL: ${name(r.about || n.about)}`,
      message: `${name(r.about)} may not have enough time: ${r.type || 'vehicle'} ${r.vehicle} at ${r.speedKmh} km/h, arrival ${r.arrival}s, needs ${r.response}s.`,
      priority: 5, tags: 'rotating_light',
    };
  }
  if (n.level === 'BROADCAST') {
    return { title: 'Site alert: vehicle approaching', message: 'Vehicle within 50 m of the site.', priority: 4, tags: 'warning' };
  }
  if (n.level === 'ALERT') {
    return { title: 'Vehicle conflict', message: `Predicted arrival ${r.tau !== undefined ? r.tau.toFixed(1) : '?'} s (${r.rule}).`, priority: 4, tags: 'warning' };
  }
  return {
    title: n.level === 'CRITICAL' ? 'MOVE NOW - vehicle coming' : 'Move to refuge now',
    message: `${r.type === 'truck' ? 'Truck' : 'Car'} ${r.vehicle}, ${r.speedKmh} km/h, ${r.distance} m away. Arrives in ${r.arrival}s; you need ${r.response}s. Go to the refuge.`,
    priority: 5, tags: n.level === 'CRITICAL' ? 'rotating_light' : 'warning',
  };
}
