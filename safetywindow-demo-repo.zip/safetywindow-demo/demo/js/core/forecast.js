// Short-horizon forecast: roll the OBSERVED state forward with explicit kinematic and queue rules,
// then run the same condition rules on each hypothetical future snapshot.
// It only receives an observation from sensors.js - it has no access to the simulator or to scripted events.
import { evaluate, COND } from './rules.js';
import { pathLength, pathPoint } from './geom.js';

const WALK = 1.4, REACT = 1.5;

const plantPoint = pathPoint;

// Which sources each forecast kind depends on.
const NEEDS = { gap: ['tmaGps', 'workerCam'], tma: ['tmaGps', 'workerCam'], queue: ['vmsRadar'], plant: ['plantApp', 'workerCam'], warning: ['upstreamCam', 'workerCam'], lane: ['workerCam'], area: ['workerCam'] };

export function forecast(obs, plan, { horizon = 30, option = null, paused = {}, dt = 1 } = {}) {
  const S = obs.src, stale = plan.timing.staleAfter;
  const ok = (k) => S[k] && S[k].age <= stale;
  const unreliable = Object.entries(NEEDS).filter(([, ks]) => ks.some((k) => !ok(k))).map(([kind, ks]) => ({ kind, sources: ks.filter((k) => !ok(k)) }));

  // --- initial state from the observation (values may be stale; rules will flag them)
  const st = {
    tma: S.tmaGps ? { x: S.tmaGps.x, y: S.tmaGps.y, v: ok('tmaGps') ? S.tmaGps.v : 0, L: S.tmaGps.L } : null,
    people: S.workerCam ? JSON.parse(JSON.stringify(S.workerCam.people)) : null,
    queue: null, plantS: S.plantApp ? S.plantApp.s : 0,
    vmsX: S.equipGps ? S.equipGps.vmsX : plan.vms.positions.P1, vmsOn: S.equipGps ? S.equipGps.vmsOn : true,
    cameraX: S.equipGps ? S.equipGps.cameraX : plan.camera.positions.K1, cameraOn: S.equipGps ? S.equipGps.cameraOn : true,
    plantHold: S.plantApp ? S.plantApp.hold : false,
  };
  const capacity = 3600 / plan.merge.headway;
  let spacing = 9;
  if (S.vmsRadar) {
    const rd = S.vmsRadar;
    if (rd.queueVehicles >= 4 && rd.queueLengthM > 0) spacing = Math.min(14, Math.max(6.5, rd.queueLengthM / (rd.queueVehicles / 2)));
    st.queue = { N: rd.queueVehicles, inflow: rd.inflowVph };
  }
  const assumptions = {
    gap: ['Shadow vehicle keeps its current GPS speed and direction', 'Each worker keeps their current pace and direction'],
    tma: ['Shadow vehicle keeps its current GPS speed and direction'],
    queue: [`Arrivals stay at the VMS-radar rate of the last 30 s (${st.queue && st.queue.inflow != null ? Math.round(st.queue.inflow) : '?'} veh/h)`,
      `Merge capacity ${Math.round(capacity)} veh/h from ${plan.id} (demo value)`, `Queue density as observed now (${spacing.toFixed(1)} m per vehicle per lane)`],
    plant: ['Plant follows its announced path and departure time', 'Workers keep their current position and pace'],
    warning: ['Approach speed stays at the measured 85th percentile'],
    lane: ['Each worker keeps their current pace and direction'], area: ['Each worker keeps their current pace and direction'],
  };

  // --- option effects (scheduled changes)
  const pauseSet = new Set([...Object.keys(paused).filter((k) => paused[k]), ...(option ? option.pause : [])]);
  let tmaStopX = null, relocate = null;
  if (option) {
    if (option.id === 'HANDOVER') tmaStopX = plan.tma.positions.T2;
    if (option.id === 'VMS_P2') relocate = { kind: 'vms', until: 20, to: plan.vms.positions.P2 };
    if (option.id === 'CAM_K2') relocate = { kind: 'camera', until: 15, to: plan.camera.positions.K2 };
    if (option.id === 'HOLD_PLANT' || option.id === 'PAUSE_C') st.plantHold = option.id === 'HOLD_PLANT';
  }
  const departAt = S.plantApp && S.plantApp.departAt != null ? S.plantApp.departAt : null;
  const plantLen = pathLength(plan.plant.path);

  const steps = [];
  for (let tau = 0; tau <= horizon + 1e-9; tau += dt) {
    // ---- hypothetical observation at obs.t + tau
    const age = (k) => (S[k] ? (ok(k) ? 0 : S[k].age + tau) : Infinity);
    const q = st.queue;
    const tailX = q ? plan.merge.gateX - (q.N * spacing) / 2 : null;
    let plantState = S.plantApp ? S.plantApp.state : 'parked', px = S.plantApp ? S.plantApp.x : 0, py = S.plantApp ? S.plantApp.y : 0;
    const tAbs = obs.t + tau;
    if (plantState === 'requested' && !st.plantHold && departAt != null && tAbs >= departAt) plantState = 'moving';
    if (plantState === 'moving') {
      const moved = S.plantApp.state === 'moving' ? st.plantS : (tAbs - departAt) * plan.plant.speed;
      if (moved >= plantLen) plantState = 'arrived';
      const pt = plantPoint(plan.plant.path, Math.min(moved, plantLen)); px = pt.x; py = pt.y;
    }
    const hobs = {
      t: tAbs, phase: obs.phase, tasks: obs.tasks, confirmations: obs.confirmations, install: obs.install, cones: obs.cones,
      src: {
        tmaGps: st.tma ? { ...st.tma, age: age('tmaGps') } : null,
        arrowTele: S.arrowTele ? { ...S.arrowTele, age: age('arrowTele') } : null,
        workerCam: st.people ? { people: st.people, age: age('workerCam') } : null,
        upstreamCam: S.upstreamCam ? { ...S.upstreamCam, age: relocate && relocate.kind === 'camera' && tau < relocate.until ? 99 : age('upstreamCam') } : null,
        vmsRadar: S.vmsRadar ? { ...S.vmsRadar, age: relocate && relocate.kind === 'vms' && tau < relocate.until ? 99 : age('vmsRadar'), queueVehicles: q ? Math.round(q.N) : 0, queueLengthM: q ? (q.N * spacing) / 2 : 0, queueTailX: tailX != null && tailX >= st.vmsX ? tailX : null, beyondVms: tailX != null && tailX < st.vmsX && q.N > 0 } : null,
        plantApp: S.plantApp ? { ...S.plantApp, state: plantState, x: px, y: py, age: age('plantApp') } : null,
        equipGps: S.equipGps ? { ...S.equipGps, vmsX: st.vmsX, cameraX: st.cameraX, age: age('equipGps') } : null,
      },
    };
    const ev = evaluate(hobs, plan, { paused: Object.fromEntries([...pauseSet].map((k) => [k, true])) });
    steps.push({ tau, ev, tailX, vmsX: st.vmsX, queueM: q ? (q.N * spacing) / 2 : 0, tma: st.tma ? { ...st.tma } : null, people: st.people ? JSON.parse(JSON.stringify(st.people)) : null, plant: { state: plantState, x: px, y: py } });

    // ---- advance the state by dt
    if (st.tma) {
      if (tmaStopX !== null) {
        const d = tmaStopX - st.tma.x;
        const v = Math.abs(st.tma.v) > 0.05 ? st.tma.v : Math.sign(d) * 1.0;
        if (Math.abs(d) <= Math.abs(v * dt) || Math.sign(d) !== Math.sign(v)) { st.tma.x = tmaStopX; st.tma.v = 0; } else st.tma.x += v * dt;
      } else st.tma.x += st.tma.v * dt;
    }
    if (st.people) for (const [id, p] of Object.entries(st.people)) {
      if (pauseSet.has(id) && tau + dt > REACT) {
        const ty = 8.9, tx = Math.min(plan.refuge.x1, Math.max(plan.refuge.x0, p.x));
        const dx = tx - p.x, dy = ty - p.y, d = Math.hypot(dx, dy);
        if (d > 0.05) { const s = Math.min(d, WALK * dt); p.x += (dx / d) * s; p.y += (dy / d) * s; }
        p.vx = 0; p.vy = 0;
      } else if (!pauseSet.has(id)) {
        // people walking to an announced spot (instruction on their phone) stop there; others keep their observed velocity
        const task = obs.tasks[id] || {};
        const nearHome = task.mode === 'work' && task.home && Math.hypot(p.x - task.home.x, p.y - task.home.y) < 0.6; // just arrived: stays put
        const target = (task.mode === 'toWork' || nearHome) && task.home ? task.home : task.mode === 'toRefuge' ? { x: p.x, y: 8.9 } : null;
        if (target) {
          const dx = target.x - p.x, dy = target.y - p.y, d = Math.hypot(dx, dy), sp = Math.max(0.5, Math.hypot(p.vx, p.vy));
          if (d > 0.05) { const s = Math.min(d, sp * dt); p.x += (dx / d) * s; p.y += (dy / d) * s; }
        } else { p.x += p.vx * dt; p.y = Math.min(8.9, p.y + p.vy * dt); }
      }
    }
    if (q && q.inflow != null) q.N = Math.max(0, q.N + ((q.inflow - capacity) / 3600) * dt * 1);
    if (relocate && tau + dt >= relocate.until) { if (relocate.kind === 'vms') st.vmsX = relocate.to; else st.cameraX = relocate.to; }
  }

  // --- compile: predicted issues = conditions MET now that turn NOT_MET within the horizon
  const first = steps[0].ev;
  const issues = [], conflicts = [], unmet = new Map(), unknown = new Map();
  for (const pid of ['A', 'B', 'C']) {
    for (const c0 of first.people[pid].conditions) {
      let from = null, to = null, at = null, unk = null;
      for (const s of steps) {
        const c = s.ev.people[pid].conditions.find((x) => x.id === c0.id);
        if (c.status === 'NOT_MET') { if (from === null) { from = s.tau; at = c; } to = s.tau; }
        if (c.status === 'UNKNOWN' && unk === null) unk = { tau: s.tau, detail: c.detail };
      }
      if (from !== null) {
        conflicts.push({ pid, cond: c0.id, name: c0.name, from, to, detail: at.detail });
        unmet.set(c0.id, c0.name);
        if (c0.status === 'MET' && from > 0) issues.push({ pid, cond: c0.id, kind: COND[c0.id].kind, name: c0.name, inS: from, detail: at.detail });
      }
      if (unk) unknown.set(c0.id, { name: c0.name, tau: unk.tau, detail: unk.detail });
    }
  }
  // group issues by kind for the supervisor
  const byKind = {};
  for (const i of issues) (byKind[i.kind] = byKind[i.kind] || []).push(i);
  const grouped = Object.entries(byKind).map(([kind, list]) => ({
    kind, inS: Math.min(...list.map((i) => i.inS)), people: [...new Set(list.map((i) => i.pid))], items: list,
    reason: reasonFor(kind, list, obs, plan, { spacing, capacity }), assumptions: assumptions[kind] || [],
  })).sort((a, b) => a.inS - b.inS);

  const series = steps.map((s) => ({ tau: s.tau, queueM: s.queueM, tailPastVms: s.tailX != null ? s.tailX - s.vmsX : null,
    gap: Object.fromEntries(['B', 'C'].map((pid) => [pid, s.tma && s.people ? s.people[pid].x - (s.tma.x + s.tma.L / 2) : null])),
    plantDist: Object.fromEntries(['B', 'C'].map((pid) => [pid, s.plant.state === 'moving' && s.people ? Math.hypot(s.plant.x - s.people[pid].x, s.plant.y - s.people[pid].y) : null])),
    status: Object.fromEntries(['A', 'B', 'C'].map((pid) => [pid, s.ev.people[pid].status])) }));
  return {
    t: obs.t, horizon, option: option ? option.id : null,
    reliable: unreliable.length === 0, unreliable,
    issues: grouped,
    conflicts, unmet: [...unmet.entries()].map(([id, name]) => ({ id, name })), unknown: [...unknown.entries()].map(([id, u]) => ({ id, ...u })),
    queueMaxM: Math.max(...steps.map((s) => s.queueM)), series, steps,
  };
}

function reasonFor(kind, list, obs, plan, { capacity }) {
  const S = obs.src;
  const who = [...new Set(list.map((i) => i.pid))].join(', ');
  const t = Math.round(Math.min(...list.map((i) => i.inS)));
  if (kind === 'gap' || kind === 'tma') {
    const v = S.tmaGps ? S.tmaGps.v : 0;
    const dir = v < -0.05 ? 'upstream (away from the crew)' : v > 0.05 ? 'towards the crew' : 'stationary';
    return `Shadow vehicle moving ${dir} at ${Math.abs(v).toFixed(1)} m/s (GPS). Protection for ${who}: ${list[0].detail} in ~${t} s.`;
  }
  if (kind === 'queue') {
    const inflow = S.vmsRadar ? S.vmsRadar.inflowVph : null;
    return `Arrivals ${inflow != null ? Math.round(inflow) : '?'} veh/h vs merge capacity ${Math.round(capacity)} veh/h: the queue tail passes the warned range in ~${t} s.`;
  }
  if (kind === 'plant') return `Plant departs ${S.plantApp && S.plantApp.departAt != null ? `in ${Math.max(0, Math.round(S.plantApp.departAt - obs.t))} s` : 'soon'} on its announced path, which comes within ${plan.plant.clearance} m of ${who} in ~${t} s.`;
  if (kind === 'warning') return `Approach speed ${S.upstreamCam && S.upstreamCam.v85 ? Math.round(S.upstreamCam.v85 * 3.6) : '?'} km/h: warning time for ${who} drops below the need in ~${t} s.`;
  if (kind === 'lane') return `${who} moving towards the open lane - reaches the 0.3 m margin in ~${t} s.`;
  if (kind === 'area') return `${who} moving out of the configured work area in ~${t} s.`;
  return `${list[0].name} fails for ${who} in ~${t} s.`;
}
