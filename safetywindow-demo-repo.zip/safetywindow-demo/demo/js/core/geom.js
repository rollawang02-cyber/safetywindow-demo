// Small geometry helpers shared by the simulator and the decision logic.
export function pathPoint(path, s) {
  let acc = 0;
  for (let i = 1; i < path.length; i++) {
    const [x0, y0] = path[i - 1], [x1, y1] = path[i];
    const L = Math.hypot(x1 - x0, y1 - y0);
    if (acc + L >= s) { const u = (s - acc) / L; return { x: x0 + (x1 - x0) * u, y: y0 + (y1 - y0) * u, heading: Math.atan2(y1 - y0, x1 - x0), end: false }; }
    acc += L;
  }
  const [xa, ya] = path[path.length - 2], [xb, yb] = path[path.length - 1];
  return { x: xb, y: yb, heading: Math.atan2(yb - ya, xb - xa), end: true };
}
export function pathLength(path) { let L = 0; for (let i = 1; i < path.length; i++) L += Math.hypot(path[i][0] - path[i - 1][0], path[i][1] - path[i - 1][1]); return L; }
