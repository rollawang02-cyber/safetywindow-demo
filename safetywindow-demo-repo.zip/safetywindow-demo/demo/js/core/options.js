// Candidate adjustments: filter the plan's pre-configured options, forecast each one with the SAME
// observation and horizon as "keep current", and report what would still be unmet afterwards.
import { forecast } from './forecast.js';
import { evaluate } from './rules.js';

export function issueKinds(fc, ev) {
  const kinds = new Set(fc.issues.map((i) => i.kind));
  for (const p of Object.values(ev.people)) for (const c of p.conditions) if (c.status === 'NOT_MET') kinds.add(c.kind);
  return kinds;
}

export function candidates(options, kinds, phase, obs = null) {
  return options.filter((o) => o.phases.includes(phase) && o.for.some((k) => kinds.has(k)) && applicable(o, obs));
}

// An option is only offered if it would change something (e.g. the VMS is not already at P2).
function applicable(o, obs) {
  if (!obs) return true;
  const eq = obs.src.equipGps, pl = obs.src.plantApp, g = obs.src.tmaGps;
  if (o.id === 'VMS_P2') return !eq || (eq.vms !== 'P2' && !(eq.moving && eq.moving.vms));
  if (o.id === 'CAM_K2') return !eq || (eq.camera !== 'K2' && !(eq.moving && eq.moving.camera));
  if (o.id === 'HOLD_PLANT' || o.id === 'PAUSE_C') return !!pl && pl.state === 'requested' && !pl.hold;
  if (o.id === 'HANDOVER') return true; // restart point and handover checks still apply even if the vehicle is already at T2
  return true;
}

// Evaluate the conditions that will apply once the option is fully carried out and paused people are back at work.
export function postCheck(option, fc, obs, plan) {
  const last = fc.steps[fc.steps.length - 1];
  if (!last.people || !last.tma) return [{ id: 'DATA', name: 'Positions unavailable', detail: 'cannot check the end state' }];
  const people = JSON.parse(JSON.stringify(last.people));
  const tma = { ...last.tma, v: 0 };
  if (option.id === 'HANDOVER') {
    tma.x = plan.tma.positions.T2;
    if (people.B) Object.assign(people.B, { x: plan.resumeMarkerX, y: 4.15 });
    if (people.C) Object.assign(people.C, { x: plan.resumeMarkerX + 4, y: 6.3 });
  }
  if (option.id === 'PAUSE_C' && obs.src.workerCam) Object.assign(people.C, { x: obs.src.workerCam.people.C.x, y: obs.src.workerCam.people.C.y });
  const src = last.ev ? null : null; void src;
  const hobs = {
    ...obs, t: obs.t + fc.horizon,
    src: {
      ...obs.src,
      tmaGps: obs.src.tmaGps ? { ...obs.src.tmaGps, ...tma, age: 0 } : null,
      workerCam: obs.src.workerCam ? { ...obs.src.workerCam, people, age: 0 } : null,
      plantApp: obs.src.plantApp ? { ...obs.src.plantApp, state: option.id === 'HOLD_PLANT' ? 'requested' : option.id === 'PAUSE_C' ? 'arrived' : last.plant.state, x: last.plant.x, y: last.plant.y, age: 0 } : null,
      vmsRadar: obs.src.vmsRadar ? { ...obs.src.vmsRadar, age: 0, queueTailX: last.tailX != null && last.tailX >= last.vmsX ? last.tailX : null, beyondVms: last.tailX != null && last.tailX < last.vmsX && last.queueM > 0, queueLengthM: last.queueM, queueVehicles: last.queueM > 0 ? obs.src.vmsRadar.queueVehicles : 0 } : null,
      equipGps: obs.src.equipGps ? { ...obs.src.equipGps, vmsX: last.vmsX, cameraX: option.id === 'CAM_K2' ? plan.camera.positions.K2 : obs.src.equipGps.cameraX, age: 0 } : null,
      upstreamCam: obs.src.upstreamCam ? { ...obs.src.upstreamCam, age: 0 } : null,
    },
    confirmations: { ...obs.confirmations, driverInPosition: true },
  };
  const ev = evaluate(hobs, plan, {});
  const out = [];
  for (const p of Object.values(ev.people)) for (const c of p.conditions) if (c.status === 'NOT_MET' || c.status === 'UNKNOWN') out.push({ pid: p.id, id: c.id, name: c.name, detail: c.detail, status: c.status });
  return out;
}

export function compareOptions(obs, plan, options, ev, { horizon = 30, paused = {} } = {}) {
  const keep = forecast(obs, plan, { horizon, paused });
  const kinds = issueKinds(keep, ev);
  const list = candidates(options, kinds, obs.phase, obs).map((opt) => {
    const fc = forecast(obs, plan, { horizon, option: opt, paused });
    const exposedConflicts = fc.conflicts.filter((c) => !isPausedAtRefuge(fc, c, opt, paused));
    const after = postCheck(opt, fc, obs, plan);
    const people = new Set([...Object.keys(opt.instructionFor), ...opt.pause]);
    people.add('SUP');
    return {
      option: opt, fc, conflicts: exposedConflicts, after,
      feasible: exposedConflicts.length === 0 && after.length === 0,
      ops: { moves: opt.moves.length, people: [...people], confirmations: opt.confirmations.length, total: opt.moves.length + opt.confirmations.length },
      unknownWhile: fc.unknown.filter((u) => u.id === 'QUEUE' || u.id === 'WARN_TIME'),
    };
  });
  return {
    keep, kinds: [...kinds], options: list,
    reassess: list.length > 0 && !list.some((o) => o.feasible),
    noCandidates: (keep.issues.length > 0 || kinds.size > 0) && list.length === 0,
    horizon, t: obs.t,
  };
}

function isPausedAtRefuge(fc, conflict, opt, paused) {
  const pausedHere = opt.pause.includes(conflict.pid) || paused[conflict.pid];
  if (!pausedHere) return false;
  // count only the part of the conflict while the person was still exposed (not yet at the refuge)
  for (const s of fc.steps) {
    if (s.tau < conflict.from || s.tau > conflict.to) continue;
    const p = s.ev.people[conflict.pid];
    const c = p.conditions.find((x) => x.id === conflict.cond);
    if (c.status === 'NOT_MET' && !p.atRefuge) return false;
  }
  return true;
}
