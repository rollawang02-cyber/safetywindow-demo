// Incidents, targeted notifications and the confirm -> notify -> re-verify -> resume loop.
//  * a FORECAST goes to the supervisor only (review and compare options)
//  * a condition that is NOT MET now (or CANNOT BE CONFIRMED) goes immediately to the affected people + supervisor
//  * one push per incident and recipient; a worsening incident escalates once
//  * "acknowledged" is recorded separately and never resumes work by itself
//  * a task resumes only when its conditions hold at the resume position AND the required people have confirmed
import { evaluate, COND } from './rules.js';
import { ROLES } from '../plan.js';

let seq = 1;

export class Workflow {
  constructor(plan, options, { send = () => {} } = {}) {
    this.plan = plan; this.options = options; this.send = send;
    this.incidents = [];
    this.tasks = { A: { state: 'ACTIVE' }, B: { state: 'ACTIVE' }, C: { state: 'ACTIVE' } };
    this.messages = [];
    this.pendingCommands = [];   // equipment moves released when the responsible person acknowledges
    this.lastEventAt = null; this.lastEventText = null;
    this.fcSeen = {};             // forecast issues must persist for 2 decision ticks before anyone is notified
  }

  noteEvent(t, text) { this.lastEventAt = t; this.lastEventText = text; }
  open() { return this.incidents.filter((i) => i.status === 'open'); }
  find(key) { return this.incidents.find((i) => i.key === key && i.status === 'open'); }
  paused() { return Object.fromEntries(Object.entries(this.tasks).map(([k, v]) => [k, v.state !== 'ACTIVE'])); }

  _create(key, t, fields) {
    const inc = { id: seq++, key, status: 'open', detectedAt: t, occurredAt: this.lastEventAt, occurredText: this.lastEventText,
      recipients: {}, escalated: false, option: null, confirmedAt: null, restoredAt: null, resumedAt: null, resolvedAt: null, history: [], ...fields };
    inc.history.push({ t, text: `Detected: ${inc.title}` });
    this.incidents.push(inc);
    return inc;
  }
  _msg(inc, to, t, { title, body, level, ack = true }) {
    const dup = this.messages.find((m) => m.incidentId === inc.id && m.to === to && m.level === level);
    if (dup) return null; // de-duplicate: one message per incident, recipient and level
    const m = { id: seq++, t, to, title, body, level, incidentId: inc.id, needsAck: ack, ackAt: null };
    this.messages.push(m);
    inc.recipients[to] = inc.recipients[to] || { sentAt: t, ackAt: null };
    inc.history.push({ t, text: `Sent to ${ROLES[to].short}: ${title}` });
    this.send(m);
    return m;
  }

  // Called every decision tick with the current evaluation and the keep-current forecast.
  update(obs, ev, fc, t) {
    // 1) conditions failing NOW -> stop the affected task, tell that person and the supervisor
    for (const p of Object.values(ev.people)) {
      const task = this.tasks[p.id];
      if (task.state !== 'ACTIVE') continue;
      if (!p.stop.length) continue; // exposure conditions are NA at the refuge, so what remains here really fails
      const unk = p.stop.every((c) => c.status === 'UNKNOWN');
      const key = `now:${p.id}`;
      let inc = this.find(key);
      const why = p.stop.map((c) => `${c.name}: ${c.detail}`).join('; ');
      if (!inc) {
        const fcInc = this.open().find((i) => i.type === 'forecast' && i.people.includes(p.id) && p.stop.some((c) => c.kind === i.kind));
        inc = this._create(key, t, { type: unk ? 'unknown' : 'current', kind: p.stop[0].kind, people: [p.id], title: unk ? `Cannot confirm ${ROLES[p.id].short}'s protection` : `${ROLES[p.id].short}: conditions not met`, reason: why, conds: p.stop.map((c) => c.id), fromForecast: fcInc ? fcInc.id : null });
        if (fcInc) { fcInc.history.push({ t, text: 'Forecast came true - handled as a current failure' }); fcInc.becameCurrent = t; }
        task.state = 'PAUSED'; task.incident = inc.id; task.resumeAt = null;
        const me = obs.src.workerCam ? obs.src.workerCam.people[p.id] : null;
        task.workPos = me && me.y < this.plan.refuge.y0 - 0.2 ? { x: me.x, y: Math.max(me.y, this.plan.openLaneEdge + 0.65) } : null;
        const code = p.stop.some((c) => c.kind === 'vehicle' && c.status === 'NOT_MET') ? 'STOP-3' : p.stop.every((c) => c.kind === 'warning') ? 'STOP-2' : 'STOP-1';
        this._msg(inc, p.id, t, { level: 'stop', title: unk ? 'PAUSE - protection cannot be confirmed' : code === 'STOP-3' ? 'STEP BACK NOW - car not stopping' : 'STOP - protection not met',
          body: `${this.plan.instructions[code]} Reason: ${why}.` });
        this._msg(inc, 'SUP', t, { level: 'stop', title: `${ROLES[p.id].short} stopped (${unk ? 'cannot confirm' : 'not met'})`, body: `${why}. Resume needs: conditions back at the work position + your confirmation.` });
      }
    }
    // escalate an UNKNOWN stop that turns into NOT MET
    for (const inc of this.open().filter((i) => i.type === 'unknown')) {
      const p = ev.people[inc.people[0]];
      const hard = p.conditions.filter((c) => c.onFail === 'stop' && c.status === 'NOT_MET');
      if (hard.length && !inc.escalated) {
        inc.escalated = true; inc.type = 'current';
        this._msg(inc, 'SUP', t, { level: 'escalate', title: `Escalation: ${ROLES[p.id].short} now NOT MET`, body: hard.map((c) => `${c.name}: ${c.detail}`).join('; ') });
      }
    }
    // 2) site notices (queue, arrow board, order) -> supervisor (+ controller for the queue)
    const notices = new Map();
    for (const p of Object.values(ev.people)) for (const c of p.conditions) if (c.onFail === 'notify' && c.status === 'NOT_MET') notices.set(c.id, c);
    for (const [id, c] of notices) {
      const key = `notice:${id}`;
      if (this.find(key)) continue;
      const fcInc = this.open().find((i) => i.type === 'forecast' && i.kind === c.kind);
      const inc = this._create(key, t, { type: 'current', kind: c.kind, people: [], title: `${c.name}: not met`, reason: c.detail, conds: [id], fromForecast: fcInc ? fcInc.id : null });
      if (fcInc) { fcInc.becameCurrent = t; fcInc.history.push({ t, text: 'Forecast came true' }); }
      this._msg(inc, 'SUP', t, { level: 'notice', title: `Not met: ${c.name}`, body: c.detail });
      if (c.kind === 'queue') this._msg(inc, 'A', t, { level: 'notice', title: 'Queue beyond warned range', body: `${c.detail}. Watch the queue tail; wait for the supervisor's decision.` });
    }
    for (const inc of this.open().filter((i) => i.key.startsWith('notice:') && i.kind !== 'fatigue')) {
      const id = inc.conds[0];
      if (!notices.has(id)) this._restore(inc, t, 'Condition met again');
    }
    // 2b) fatigue (sample plan): remind the supervisor - not the controller - before A's relief is due
    const onBat = obs.tasks.A && obs.tasks.A.onBatS;
    const F = this.plan.fatigue;
    if (obs.phase === 'work' && onBat != null) {
      const due = onBat >= F.reliefAfterS - F.remindBeforeS;
      const inc = this.find('notice:FATIGUE');
      if (due && !obs.confirmations.reliefArranged && !inc && !this.incidents.some((i) => i.key === 'notice:FATIGUE')) {
        const mins = Math.round(onBat / 60), left = Math.max(0, Math.round((F.reliefAfterS - onBat) / 60));
        const n = this._create('notice:FATIGUE', t, { type: 'notice', kind: 'fatigue', people: [], title: 'Relief due for Controller A', reason: `A has been on the stop/slow bat for ${Math.floor(mins / 60)} h ${mins % 60} min; the sample fatigue plan needs a relief within ${left} min.`, conds: [] });
        this._msg(n, 'SUP', t, { level: 'notice', title: 'Relief due for Controller A', body: `${n.reason} Plan the swap; A is not interrupted.` });
      }
      if (inc && obs.confirmations.reliefArranged) this._restore(inc, t, 'Relief arranged by the supervisor');
    }
    // 3) forecasts -> supervisor only
    if (fc) {
      const seenNow = {};
      for (const is of fc.issues) seenNow[is.kind] = (this.fcSeen[is.kind] || 0) + 1;
      this.fcSeen = seenNow;
      for (const is of fc.issues) {
        if (seenNow[is.kind] < 2 && !this.find(`fc:${is.kind}`)) continue;
        const people = is.people.filter((pid) => this.tasks[pid].state === 'ACTIVE');
        if (!people.length && is.kind !== 'queue') continue;
        const key = `fc:${is.kind}`;
        let inc = this.find(key);
        if (!inc) {
          inc = this._create(key, t, { type: 'forecast', kind: is.kind, people, title: `Forecast: ${COND[is.items[0].cond].name} fails in ~${Math.round(is.inS)} s`, reason: is.reason, assumptions: is.assumptions, inS: is.inS, horizon: fc.horizon });
          this._msg(inc, 'SUP', t, { level: 'forecast', title: `Forecast (${fc.horizon} s): adjustment likely needed`, body: `${is.reason} Review and compare the options.` });
        } else {
          inc.inS = is.inS; inc.reason = is.reason;
          if (!inc.escalated && is.inS <= 10 && !inc.option) {
            inc.escalated = true;
            this._msg(inc, 'SUP', t, { level: 'escalate', title: `Escalation: ~${Math.round(is.inS)} s left`, body: `${is.reason} No option confirmed yet.` });
          }
        }
      }
      // a forecast that no longer shows up (and has no option in progress) is cleared
      for (const inc of this.open().filter((i) => i.type === 'forecast' && !i.option)) {
        if (!fc.issues.some((i) => `fc:${i.kind}` === inc.key) && fc.reliable && !inc.becameCurrent) this._restore(inc, t, 'Forecast no longer shows the issue', true);
        if (inc.becameCurrent && !this.open().some((i) => i.fromForecast === inc.id)) this._restore(inc, t, 'Handled by the current-failure record', true);
      }
      // unreliable forecast -> tell the supervisor once per kind
      for (const u of fc.unreliable) {
        if (!['gap', 'queue', 'plant', 'warning'].includes(u.kind)) continue;
        const key = `unrel:${u.kind}`;
        if (this.find(key)) continue;
        const inc = this._create(key, t, { type: 'notice', kind: u.kind, people: [], title: `Cannot reliably forecast (${u.kind})`, reason: `stale: ${u.sources.join(', ')}`, conds: [] });
        this._msg(inc, 'SUP', t, { level: 'notice', title: 'Forecast unavailable', body: `Cannot reliably forecast ${u.kind}: ${u.sources.join(', ')} not current. Normal judgements are suspended for affected conditions.`, ack: false });
      }
      for (const inc of this.open().filter((i) => i.key.startsWith('unrel:'))) {
        if (!fc.unreliable.some((u) => `unrel:${u.kind}` === inc.key)) this._restore(inc, t, 'Data current again', true);
      }
    }
    // 4) re-verification: mark READY when conditions hold at the resume position and confirmations are in
    for (const [pid, task] of Object.entries(this.tasks)) {
      if (task.state === 'ACTIVE') continue;
      const chk = this.canResume(pid, obs);
      task.check = chk;
      if (chk.ok && task.state === 'PAUSED') { task.state = 'READY'; task.readyAt = t; const inc = this.incidents.find((i) => i.id === task.incident); if (inc && !inc.restoredAt) { inc.restoredAt = t; inc.history.push({ t, text: `Conditions restored for ${ROLES[pid].short} - waiting for supervisor` }); } }
      if (!chk.ok && task.state === 'READY') task.state = 'PAUSED';
    }
    // an option without paused tasks (e.g. VMS move) is restored when its conditions hold
    for (const inc of this.open().filter((i) => i.option && !i.option.pause.length)) {
      if (this.optionRestored(inc, ev, obs)) { if (!inc.restoredAt) inc.restoredAt = t; this._restore(inc, t, 'Adjusted conditions verified'); }
    }
  }

  _restore(inc, t, text, cleared = false) {
    if (inc.status !== 'open') return;
    inc.status = cleared ? 'cleared' : 'resolved';
    inc.resolvedAt = t; inc.history.push({ t, text });
  }

  optionRestored(inc, ev, obs) {
    const opt = inc.option;
    if (opt.id === 'VMS_P2') return obs.src.equipGps && obs.src.equipGps.vms === 'P2' && ev.people.A.conditions.find((c) => c.id === 'QUEUE')?.status === 'MET';
    if (opt.id === 'CAM_K2') return obs.src.equipGps && obs.src.equipGps.camera === 'K2' && ev.people.A.conditions.find((c) => c.id === 'WARN_TIME')?.status === 'MET';
    if (opt.id === 'HOLD_PLANT') return ['B', 'C'].every((pid) => ev.people[pid].conditions.every((c) => c.id !== 'PLANT_CLEAR' || c.status === 'MET'));
    return false;
  }

  // Conditions at the resume position + required human confirmations.
  canResume(pid, obs) {
    const task = this.tasks[pid];
    const inc = this.incidents.find((i) => i.id === task.incident) || null;
    const opt = task.option || (inc && inc.option) || null;
    const missing = [];
    const cam = obs.src.workerCam;
    if (!cam || cam.age > this.plan.timing.staleAfter) return { ok: false, missing: ['worker positions not current'] };
    const people = JSON.parse(JSON.stringify(cam.people));
    const pos = this.resumePosition(pid, obs, opt);
    Object.assign(people[pid], { x: pos.x, y: pos.y, vx: 0, vy: 0 });
    const hobs = { ...obs, src: { ...obs.src, workerCam: { ...cam, people } } };
    const ev = evaluate(hobs, this.plan, {});
    for (const c of ev.people[pid].conditions) if (c.status !== 'MET') missing.push(`${c.name}: ${c.detail}`);
    if (opt && opt.id === 'HANDOVER') {
      const g = obs.src.tmaGps;
      if (!g || g.age > this.plan.timing.staleAfter) missing.push('shadow-vehicle GPS not current');
      else {
        if (Math.abs(g.v) > 0.05) missing.push('shadow vehicle still moving');
        if (Math.abs(g.x - this.plan.tma.positions.T2) > 1.5) missing.push(`shadow vehicle not yet at T2 (${Math.round(g.x - this.plan.tma.positions.T2)} m away)`);
      }
      if (!obs.confirmations.driverInPosition) missing.push('driver has not confirmed "In position"');
    }
    if (opt && opt.id === 'CAM_K2') {
      const g = obs.src.equipGps;
      if (!g || g.camera !== 'K2') missing.push('camera trailer not yet at K2');
      else if (!obs.confirmations.cameraChecked) missing.push('supervisor has not checked the camera view (aim and calibration)');
    }
    const rec = inc ? inc.recipients[pid] : null;
    if (inc && rec && !rec.ackAt) missing.push(`${ROLES[pid].short} has not acknowledged`);
    const optInc = task.optionIncident ? this.incidents.find((i) => i.id === task.optionIncident) : null;
    if (optInc && optInc !== inc && optInc.recipients[pid] && !optInc.recipients[pid].ackAt) missing.push(`${ROLES[pid].short} has not acknowledged the instruction`);
    return { ok: missing.length === 0, missing, pos };
  }

  resumePosition(pid, obs, opt) {
    const home = obs.tasks[pid].home || { x: 0, y: 0 };
    if (opt && opt.id === 'HANDOVER' && obs.phase === 'packdown') {
      if (pid === 'B') return { x: this.plan.resumeMarkerX, y: 4.15 };
      if (pid === 'C') return { x: this.plan.resumeMarkerX + 4, y: 6.3 };
    }
    const task = this.tasks[pid];
    return (task && task.workPos) || home;
  }

  // Supervisor confirms a pre-configured option for an incident.
  confirmOption(incId, optId, t, obs = null) {
    const inc = this.incidents.find((i) => i.id === incId);
    const opt = this.options.find((o) => o.id === optId);
    if (!inc || !opt || inc.status !== 'open') return [];
    inc.option = opt; inc.confirmedAt = t;
    inc.history.push({ t, text: `Supervisor confirmed option: ${opt.title}` });
    const cmds = [];
    for (const [role, code] of Object.entries(opt.instructionFor)) {
      this._msg(inc, role, t, { level: 'plan', title: role === 'TMA' ? 'Confirmed vehicle adjustment' : role === 'PLANT' ? 'Plant instruction' : code.startsWith('EQ') ? 'Equipment instruction' : code.startsWith('HOLD') ? 'Hold - stay stepped back' : 'Task affected - follow instruction', body: this.plan.instructions[code], ack: role !== 'SUP' });
    }
    for (const pid of opt.pause) {
      const task = this.tasks[pid];
      if (task.state === 'ACTIVE') { task.state = 'PAUSED'; task.incident = inc.id; const me = obs && obs.src.workerCam ? obs.src.workerCam.people[pid] : null; task.workPos = me ? { x: me.x, y: me.y } : null; }
      task.option = opt; task.optionIncident = inc.id;
      if (!opt.instructionFor[pid]) this._msg(inc, pid, t, { level: 'plan', title: 'Task paused', body: 'Your task is paused by the supervisor. Wait at the refuge.' });
      if (pid !== 'A') cmds.push({ who: pid, action: 'refuge', when: 'receipt' });
    }
    const pending = [...opt.confirmations, ...opt.pause.map((p) => `${ROLES[p].short}: acknowledge`), ...(opt.pause.length ? ['Conditions verified at the restart position'] : ['Adjusted conditions verified'])];
    this._msg(inc, 'SUP', t, { level: 'plan-sup', title: 'Option confirmed - pending items', body: pending.join(' · '), ack: false });
    if (opt.id === 'HANDOVER') cmds.push({ who: 'TMA', action: 'tmaTo', arg: 'T2', when: 'ack:TMA' });
    if (opt.id === 'VMS_P2') cmds.push({ action: 'moveVms', arg: 'P2', when: 'ack:A' });
    if (opt.id === 'CAM_K2') cmds.push({ action: 'moveCamera', arg: 'K2', when: 'receipt' }); // the supervisor tows it; starts on confirmation
    if (opt.id === 'HOLD_PLANT' || opt.id === 'PAUSE_C') cmds.push({ action: 'plantHold', when: 'receipt' });
    const now = cmds.filter((c) => c.when === 'receipt');
    this.pendingCommands.push(...cmds.filter((c) => c.when !== 'receipt').map((c) => ({ ...c, incidentId: inc.id })));
    return now;
  }

  // A person taps "Acknowledge" on their phone. Returns commands that this releases.
  ack(role, t) {
    let n = 0;
    for (const m of this.messages) if (m.to === role && m.needsAck && !m.ackAt) { m.ackAt = t; n++; const inc = this.incidents.find((i) => i.id === m.incidentId); if (inc && inc.recipients[role] && !inc.recipients[role].ackAt) { inc.recipients[role].ackAt = t; inc.history.push({ t, text: `${ROLES[role].short} acknowledged` }); } }
    const rel = this.pendingCommands.filter((c) => c.when === `ack:${role}`);
    this.pendingCommands = this.pendingCommands.filter((c) => c.when !== `ack:${role}`);
    return { acked: n, commands: rel };
  }

  // Supervisor resumes a task. Refused unless canResume() passes.
  resume(pid, obs, t) {
    const task = this.tasks[pid];
    if (task.state === 'ACTIVE') return { ok: false, missing: ['task is already active'] };
    const chk = this.canResume(pid, obs);
    if (!chk.ok) return chk;
    const incId = task.incident, opt = task.option;
    task.state = 'ACTIVE'; task.incident = null; task.option = null; task.optionIncident = null;
    const cmds = [{ who: pid, action: 'resume', arg: chk.pos }];
    for (const inc of this.incidents.filter((i) => i.status === 'open' && (i.id === incId || (opt && i.option === opt)))) {
      this._msg(inc, pid, t, { level: 'resume', title: 'Resume work', body: opt && opt.id === 'HANDOVER' ? `Supervisor confirmed. Restart at marker S2 (x ${this.plan.resumeMarkerX} m).` : 'Supervisor confirmed. You may resume.', ack: false });
      const stillPaused = Object.entries(this.tasks).some(([k, v]) => v.state !== 'ACTIVE' && (v.incident === inc.id || v.optionIncident === inc.id));
      if (!stillPaused) { inc.resumedAt = t; if (!inc.restoredAt) inc.restoredAt = t; this._restore(inc, t, 'Task(s) resumed by the supervisor'); }
    }
    // resolve linked incidents (e.g. the forecast that led to this)
    for (const inc of this.open()) if (inc.type === 'forecast' && inc.option && !Object.values(this.tasks).some((v) => v.state !== 'ACTIVE' && v.optionIncident === inc.id)) { inc.resumedAt = t; this._restore(inc, t, 'All affected tasks resumed'); }
    return { ok: true, commands: cmds };
  }

  progress(inc) {
    const recips = Object.entries(inc.recipients).filter(([r]) => r !== 'SUP');
    const acked = recips.filter(([, v]) => v.ackAt != null);
    const ackAll = recips.length && acked.length === recips.length ? Math.max(...acked.map(([, v]) => v.ackAt)) : null;
    return {
      occurred: inc.occurredAt, detected: inc.detectedAt, confirmed: inc.confirmedAt, acked: ackAll, restored: inc.restoredAt, resumed: inc.resumedAt,
      pendingAcks: recips.filter(([, v]) => v.ackAt == null).map(([r]) => r), involved: recips.length + 1,
    };
  }
}
