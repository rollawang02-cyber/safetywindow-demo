// Sensor adapter: the ONLY bridge from the simulated world to the decision logic.
// Each source samples the ground truth at its own rate while online and keeps its last sample with a timestamp.
// Replace this file's sample() with real feeds (camera detections, TMA GPS, arrow-board telemetry, VMS radar)
// and the rules, forecast and workflow modules keep working unchanged.

const RATE = { tmaGps: 5, arrowTele: 1, workerCam: 5, upstreamCam: 2, vmsRadar: 4, plantApp: 1, equipGps: 1 };

export class Sensors {
  constructor() { this.last = {}; this.nextAt = {}; this.prevTrack = {}; this.committed = null; }

  sample(world) {
    const t = world.t;
    const due = (k) => { if ((this.nextAt[k] ?? -1) <= t) { this.nextAt[k] = t + 1 / RATE[k] - 1e-9; return true; } return false; };
    const s = world.sensors, P = world.plan;
    if (s.tmaGps && due('tmaGps')) this.last.tmaGps = { t, x: world.tma.x, y: world.tma.y, v: world.tma.v, L: world.tma.L };
    if (s.arrowTele && due('arrowTele')) this.last.arrowTele = { t, on: world.tma.arrow };
    if (s.workerCam && due('workerCam')) {
      const people = {};
      for (const p of Object.values(world.people)) people[p.id] = { x: p.x, y: p.y, vx: p.vx, vy: p.vy, posture: p.posture, inCab: !!p.inCab };
      this.last.workerCam = { t, people };
    }
    if (s.upstreamCam && world.equip.cameraOn && due('upstreamCam')) {
      const v85 = world.traffic.counts().v85;
      // keep the last measured speed when no vehicle passed recently (reported with the time it was measured)
      if (v85 != null) this.lastSpeed = { v85, at: t };
      this.last.upstreamCam = { t, v85: this.lastSpeed ? this.lastSpeed.v85 : null, speedAge: this.lastSpeed ? t - this.lastSpeed.at : null, x: world.equip.cameraX };
    }
    if (s.vmsRadar && !world.equip.moving.vms && due('vmsRadar')) {
      const q = world.traffic.queue();
      const c = world.traffic.counts();
      // the radar can measure the queue tail only between the VMS and the merge
      const tailSeen = q.tailX >= world.equip.vmsX;
      // per-vehicle tracks between the VMS and the STOP line (speed from the radar, deceleration from successive samples)
      const gate = world.traffic.gateX, tracks = [];
      for (const v of world.traffic.all()) {
        if (v.dir !== 1 || v.lane === 'D' || v.x < world.equip.vmsX || v.x > gate + 1) continue;
        const pr = this.prevTrack[v.id];
        const a = pr && t - pr.t > 0.05 ? (v.v - pr.v) / (t - pr.t) : null;
        const aS = a == null ? null : pr.a == null ? a : 0.5 * a + 0.5 * pr.a;
        this.prevTrack[v.id] = { t, v: v.v, a: aS };
        tracks.push({ id: v.id, x: v.x, v: v.v, a: aS, aRaw: a });
      }
      // when A shows STOP, vehicles already too close to stop comfortably are allowed through (committed)
      if (world.signal === 'STOP' && (!this.committed || this.committed.since !== world.signalSince)) {
        const k = P.stopLine.commitDecel;
        this.committed = { since: world.signalSince, ids: tracks.filter((r) => gate - r.x < Math.max(P.stopLine.minStopM, (r.v * r.v) / (2 * k) + 5)).map((r) => r.id) };
      }
      for (const r of tracks) r.committed = !!(this.committed && world.signal === 'STOP' && this.committed.ids.includes(r.id));
      this.last.vmsRadar = { t, inflowVph: c.inflowVph, queueTailX: tailSeen ? q.tailX : null, beyondVms: !tailSeen, queueVehicles: q.vehicles, queueLengthM: q.lengthM, x: world.equip.vmsX, tracks, gateX: gate };
    }
    if (due('plantApp')) {
      const pl = world.plant;
      this.last.plantApp = { t, state: pl.state, hold: pl.hold, departAt: pl.requestAt === null ? null : pl.requestAt + P.plant.announceS, s: pl.s, x: pl.x, y: pl.y };
    }
    if (due('equipGps')) this.last.equipGps = { t, vmsX: world.equip.vmsX, vmsOn: world.equip.vmsOn, vms: world.equip.vms, cameraX: world.equip.cameraX, cameraOn: world.equip.cameraOn, camera: world.equip.camera, moving: { ...world.equip.moving } };
  }

  // What the decision logic is allowed to know right now.
  observe(world) {
    const t = world.t;
    const age = (k) => (this.last[k] ? t - this.last[k].t : Infinity);
    return {
      t,
      phase: world.phase,
      // task assignments and confirmations come from the supervisor / crew apps, not from sensors
      tasks: Object.fromEntries(Object.values(world.people).map((p) => [p.id, { ...p.task, posture: p.posture, mode: p.mode, home: { ...p.home }, onBatS: p.onBatSince == null ? null : t - p.onBatSince }])),
      // A's stop/slow bat state comes from A's device (demo: the simulated bat), not from a camera
      signal: { state: world.signal, since: world.signalSince },
      confirmations: { driverInPosition: world.driverConfirmed, cameraChecked: world.cameraChecked, reliefArranged: world.reliefArranged, checkins: { ...world.checkins } },
      install: world.install ? { ...world.install } : null,
      cones: { signs: world.cones.signs, taperDone: world.cones.taper.every((c) => c.placed), laneLeft: world.cones.lane.filter((c) => c.placed).length, taperLeft: world.cones.taper.filter((c) => c.placed).length },
      src: {
        tmaGps: this.last.tmaGps ? { ...this.last.tmaGps, age: age('tmaGps') } : null,
        arrowTele: this.last.arrowTele ? { ...this.last.arrowTele, age: age('arrowTele') } : null,
        workerCam: this.last.workerCam ? { ...this.last.workerCam, age: age('workerCam') } : null,
        upstreamCam: this.last.upstreamCam ? { ...this.last.upstreamCam, age: age('upstreamCam') } : null,
        vmsRadar: this.last.vmsRadar ? { ...this.last.vmsRadar, age: age('vmsRadar') } : null,
        plantApp: this.last.plantApp ? { ...this.last.plantApp, age: age('plantApp') } : null,
        equipGps: this.last.equipGps ? { ...this.last.equipGps, age: age('equipGps') } : null,
      },
    };
  }
}

export const SOURCE_NAMES = {
  tmaGps: 'Shadow-vehicle GPS', arrowTele: 'Arrow-board telemetry', workerCam: 'Worker-position camera',
  upstreamCam: 'Upstream speed camera', vmsRadar: 'VMS radar (queue, demand, approaching cars)', plantApp: 'Plant driver app', equipGps: 'Equipment GPS',
};
