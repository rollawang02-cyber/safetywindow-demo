# SafetyWindow

Live safety margins for stop/slow traffic controllers.
FEIT Hackathon 2026 · RPM Hire challenge "Future Work: Smart Safety for Traffic Controllers" · Team Machine not Learning (Yuan Wang, Ruizhen Zhang, Chenyue Jin).

**Live demo:** https://rollawang02-cyber.github.io/safetywindow-demo/SafetyWindow-v2.html (best on a laptop, works on phones)

> Simulation prototype. All sensor data is simulated, and every threshold comes from a sample traffic plan that no road authority has reviewed. Decision support, not a safety guarantee.

## What it does

Every 0.5 s, SafetyWindow checks the controller's own conditions from the approved traffic plan:

- Does the camera layout give enough warning time at the measured approach speed (v85)?
- Is each approaching car braking enough for the STOP (radar tracks)?
- Is the controller on the verge, and is the queue inside the warned range?

When a condition fails, only the person who has to act is told: the controller gets "step back now", and the supervisor gets the reason and the preset options from the plan. Work restarts only when fresh data re-verifies the conditions (acknowledged ≠ restored ≠ resumed). The supervisor also gets a relief reminder based on time on the bat.

## Repository layout

```
SafetyWindow-v2.html   built single-file demo. GitHub Pages serves this file and the QR code in the deck
                       points to it, so keep it at the repository root.
demo/                  source of the simulator and the decision logic
  js/sim/              simulation only (IDM car-following, zipper merge, people, equipment)
  js/core/sensors.js   the only bridge to the logic: timestamped sampling per source; data older than 2 s = "cannot confirm"
  js/core/rules.js     per-role conditions (pure functions)
  js/core/forecast.js  short rule-based rollout; it cannot see scripted events
  js/core/options.js   preset options from the plan, compared on the same inputs
  js/core/workflow.js  incidents, role-targeted messages, acknowledge / re-verify / resume
  js/plan.js           all thresholds and presets (sample values)
  js/ui/story.js       the two guided stories: controller (main) and crew (extension)
  tests/core.test.mjs  14 unit and scenario tests
  tests/e2e_story.py   browser test that clicks through both guided stories
  tools/build.mjs      esbuild single-file build
evaluation/            fail-to-stop evaluation behind the numbers in the pitch, with results
yolo/                  YOLO11n CPU timing
```

## How to run

| What | Command |
|---|---|
| Open the demo | double-click `SafetyWindow-v2.html` (works offline) |
| Development server | `cd demo && npm install && npm run serve`, then open http://127.0.0.1:8766 |
| Unit tests | `cd demo && npm test` |
| Rebuild the single file | `cd demo && npm run build:pages` (builds `demo/dist/` and copies the file to the root) |
| Evaluation | `node evaluation/fail_to_stop_eval.mjs` (about 2 s) |
| Browser test | from the root: `python3 -m http.server 8766`, then `python demo/tests/e2e_story.py` (add `--mobile` for a phone viewport). Needs `pip install playwright` and `playwright install chromium` |
| YOLO timing | `pip install ultralytics opencv-python`, then `python yolo/yolo_timing.py --model yolo11n.pt --video <clip.mp4>` |

## What has been tested (30 Sep 2026)

| Check | How | Result |
|---|---|---|
| Unit and scenario tests | `npm test` | 14 / 14 pass |
| Fail-to-stop evaluation | `evaluation/fail_to_stop_eval.mjs`: 20 traffic seeds + 19 injection times, at 60 and 90 km/h | 78 runs, scenario started in 77, all 77 flagged, 0 runs with false alarms. Median 4.9 s before the car reaches the controller at 90 km/h (range 2.2–5.5 s), 3.8 s at 60 km/h |
| Both guided stories, end to end | `demo/tests/e2e_story.py`, desktop 1440×900 and phone 390×844 | all 14 + 13 steps complete, no page errors |
| Build reproducibility | `npm run build` | byte-identical to the deployed `SafetyWindow-v2.html` (SHA-256 `0f52c262…`) |
| Perception prototype | YOLO11n on the team's AI-generated CAM 02 test video | controller and car found and tracked 6 times a second; cones read as "bottle" (COCO has no cone class) |
| YOLO speed | `yolo/yolo_timing.py`, 2 cloud CPU cores, after warm-up | about 0.2 s per frame at 1280 px, 0.05 s at 640 px |

## Limitations

- Sensors are simulated and there is no RPM data yet. Thresholds are sample values.
- At 90 km/h the flag comes about 5 s before the car reaches the controller, which is about what a controller needs to step back. The lasting fix is taking the controller out of live traffic (a Portaboom or portable lights).
- Not measured yet: real sensor accuracy, alert delivery time to a phone or wearable, and any effect on fatigue.
- Perception is a prototype on an AI-generated test video: no camera calibration, no RPM footage.

## Third-party software

- Demo: three.js (MIT), esbuild (MIT).
- Ultralytics YOLO11 (AGPL-3.0) is used only by `yolo/`. The model weights are not in this repository.
- Not included: the team's v3.4 video-walkthrough pack (Pexels stock footage, COCO-SSD) and the Risk Engine pack (YOLO11n detection and tracking on the AI-generated CAM 02 test video).

No licence file is included yet. Add one (for example MIT) if others should be able to reuse the code.
