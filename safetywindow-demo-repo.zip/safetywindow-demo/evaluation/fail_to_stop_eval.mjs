// Reproduces the "What the simulation shows" numbers in the final deck (slide 6):
//   how many simulated drivers who do not brake for the STOP are flagged, false alarms on drivers who did stop,
//   and how many seconds before reaching controller A the flag comes.
//
// Two batches, both at 60 and 90 km/h, camera trailer at K2:
//   A. 20 traffic seeds, driver fails to stop 10 s into the run
//   B. seed 11, the failure injected at T = 20, 30, ... 200 s (T = 10 s is already covered by batch A)
// A run only counts if the scenario actually started (a non-stopping car was picked).
//
// Usage (from the repo root):  node evaluation/fail_to_stop_eval.mjs
// Writes evaluation/results/fail_to_stop_eval.json
import { writeFileSync, mkdirSync } from 'node:fs';
import { PLAN } from '../demo/js/plan.js';
import { World } from '../demo/js/sim/world.js';
import { Sensors } from '../demo/js/core/sensors.js';
import { evaluate } from '../demo/js/core/rules.js';

function oneRun({ speed, seed, injectAt }) {
  const w = new World(PLAN, { phase: 'work', seed, speedKmh: speed });
  w.equip.camera = 'K2'; w.equip.cameraX = PLAN.camera.positions.K2;
  const s = new Sensors();
  let target = null, lead = null; const falseIds = new Set();
  const run = (sec) => {
    for (let i = 0; i < sec * 10; i++) {
      w.step(0.1); s.sample(w);
      if (w.traffic.flagged != null && target == null) target = w.traffic.flagged;   // ground truth: the car that will not stop
      if (i % 5 === 4) {                                                            // rules run every 0.5 s
        const c = evaluate(s.observe(w), PLAN).people.A.conditions.find((x) => x.id === 'VEH_STOP');
        if (c.status === 'NOT_MET') {
          if (c.carId === target) { if (lead === null) lead = c.value; }            // seconds until the car reaches A
          else falseIds.add(c.carId);                                               // flagged a driver who did stop
        }
      }
    }
  };
  run(injectAt); w.inject('failToStop'); run(45);
  return { speed, seed, injectAt, started: target != null, flagged: lead != null, leadS: lead, falseAlarms: falseIds.size };
}

const runs = [];
for (const speed of [60, 90]) {
  for (let seed = 1; seed <= 20; seed++) runs.push({ batch: 'A', ...oneRun({ speed, seed, injectAt: 10 }) });
  for (let T = 20; T <= 200; T += 10) runs.push({ batch: 'B', ...oneRun({ speed, seed: 11, injectAt: T }) });
}

const started = runs.filter((r) => r.started);
const median = (xs) => { const a = [...xs].sort((p, q) => p - q); return a.length ? a[Math.floor(a.length / 2)] : null; };
const bySpeed = Object.fromEntries([60, 90].map((sp) => {
  const leads = started.filter((r) => r.speed === sp && r.flagged).map((r) => r.leadS);
  return [sp, { started: started.filter((r) => r.speed === sp).length, medianLeadS: median(leads), minLeadS: Math.min(...leads), maxLeadS: Math.max(...leads) }];
}));
const summary = {
  runs: runs.length,
  started: started.length,
  flagged: started.filter((r) => r.flagged).length,
  runsWithFalseAlarms: runs.filter((r) => r.falseAlarms > 0).length,
  bySpeed,
  note: 'Simulated inputs and a sample plan (A needs 5.0 s). Not field data.',
};
mkdirSync(new URL('./results/', import.meta.url), { recursive: true });
writeFileSync(new URL('./results/fail_to_stop_eval.json', import.meta.url), JSON.stringify({ summary, runs }, null, 2));
const f = (x) => (x == null ? '-' : x.toFixed(1));
console.log(`runs ${summary.runs}, scenario started in ${summary.started}, flagged ${summary.flagged}/${summary.started}, runs with false alarms ${summary.runsWithFalseAlarms}`);
for (const sp of [60, 90]) console.log(`${sp} km/h: median ${f(bySpeed[sp].medianLeadS)} s before the car reaches A (range ${f(bySpeed[sp].minLeadS)}-${f(bySpeed[sp].maxLeadS)} s, ${bySpeed[sp].started} runs)`);
