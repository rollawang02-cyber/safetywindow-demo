"""CPU speed of YOLO11n per frame, after a warm-up call (the numbers on the "How fast is it?" Q&A card).

  python yolo/yolo_timing.py --model yolo11n.pt --video sample.mp4
Measured on 2 cloud CPU cores: ~0.21 s per frame at 1280 px, ~0.05 s at 640 px.
Needs: pip install ultralytics opencv-python   (YOLO11 is AGPL-3.0; weights are not included in this repo)
"""
import argparse, time
import cv2
from ultralytics import YOLO

ap = argparse.ArgumentParser()
ap.add_argument("--model", default="yolo11n.pt")
ap.add_argument("--video", required=True)
ap.add_argument("--frames", type=int, default=12, help="number of frames to time (every 4th frame is used)")
a = ap.parse_args()

m = YOLO(a.model)
cap = cv2.VideoCapture(a.video); frames = []; i = 0
while len(frames) < a.frames:
    ok, f = cap.read()
    if not ok: break
    if i % 4 == 0: frames.append(f)
    i += 1
for sz in (1280, 640):
    m.predict(frames[0], imgsz=sz, device="cpu", verbose=False)          # warm-up: model load and first call are not timed
    t = time.perf_counter()
    for f in frames: r = m.predict(f, imgsz=sz, conf=0.25, device="cpu", verbose=False)[0]
    dt = (time.perf_counter() - t) / len(frames)
    names = [(r.names[int(b.cls[0])], round(float(b.conf[0]), 2)) for b in r.boxes]
    print(f"{sz} px: {dt:.3f} s/frame  last-frame detections: {names}")
